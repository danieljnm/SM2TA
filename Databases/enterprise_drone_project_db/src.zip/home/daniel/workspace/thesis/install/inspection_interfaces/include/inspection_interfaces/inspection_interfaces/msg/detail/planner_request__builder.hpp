// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from inspection_interfaces:msg/PlannerRequest.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_REQUEST__BUILDER_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_REQUEST__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "inspection_interfaces/msg/detail/planner_request__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace inspection_interfaces
{

namespace msg
{

namespace builder
{

class Init_PlannerRequest_hub_center_px_y
{
public:
  explicit Init_PlannerRequest_hub_center_px_y(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  ::inspection_interfaces::msg::PlannerRequest hub_center_px_y(::inspection_interfaces::msg::PlannerRequest::_hub_center_px_y_type arg)
  {
    msg_.hub_center_px_y = std::move(arg);
    return std::move(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_hub_center_px_x
{
public:
  explicit Init_PlannerRequest_hub_center_px_x(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  Init_PlannerRequest_hub_center_px_y hub_center_px_x(::inspection_interfaces::msg::PlannerRequest::_hub_center_px_x_type arg)
  {
    msg_.hub_center_px_x = std::move(arg);
    return Init_PlannerRequest_hub_center_px_y(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_vertical_safety
{
public:
  explicit Init_PlannerRequest_vertical_safety(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  Init_PlannerRequest_hub_center_px_x vertical_safety(::inspection_interfaces::msg::PlannerRequest::_vertical_safety_type arg)
  {
    msg_.vertical_safety = std::move(arg);
    return Init_PlannerRequest_hub_center_px_x(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_hub_offset
{
public:
  explicit Init_PlannerRequest_hub_offset(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  Init_PlannerRequest_vertical_safety hub_offset(::inspection_interfaces::msg::PlannerRequest::_hub_offset_type arg)
  {
    msg_.hub_offset = std::move(arg);
    return Init_PlannerRequest_vertical_safety(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_overlap_procentage
{
public:
  explicit Init_PlannerRequest_overlap_procentage(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  Init_PlannerRequest_hub_offset overlap_procentage(::inspection_interfaces::msg::PlannerRequest::_overlap_procentage_type arg)
  {
    msg_.overlap_procentage = std::move(arg);
    return Init_PlannerRequest_hub_offset(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_inspect_targets
{
public:
  explicit Init_PlannerRequest_inspect_targets(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  Init_PlannerRequest_overlap_procentage inspect_targets(::inspection_interfaces::msg::PlannerRequest::_inspect_targets_type arg)
  {
    msg_.inspect_targets = std::move(arg);
    return Init_PlannerRequest_overlap_procentage(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_first_blade
{
public:
  explicit Init_PlannerRequest_first_blade(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  Init_PlannerRequest_inspect_targets first_blade(::inspection_interfaces::msg::PlannerRequest::_first_blade_type arg)
  {
    msg_.first_blade = std::move(arg);
    return Init_PlannerRequest_inspect_targets(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_first_blade_rotation
{
public:
  explicit Init_PlannerRequest_first_blade_rotation(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  Init_PlannerRequest_first_blade first_blade_rotation(::inspection_interfaces::msg::PlannerRequest::_first_blade_rotation_type arg)
  {
    msg_.first_blade_rotation = std::move(arg);
    return Init_PlannerRequest_first_blade(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_blade_length
{
public:
  explicit Init_PlannerRequest_blade_length(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  Init_PlannerRequest_first_blade_rotation blade_length(::inspection_interfaces::msg::PlannerRequest::_blade_length_type arg)
  {
    msg_.blade_length = std::move(arg);
    return Init_PlannerRequest_first_blade_rotation(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_dist_blade_target
{
public:
  explicit Init_PlannerRequest_dist_blade_target(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  Init_PlannerRequest_blade_length dist_blade_target(::inspection_interfaces::msg::PlannerRequest::_dist_blade_target_type arg)
  {
    msg_.dist_blade_target = std::move(arg);
    return Init_PlannerRequest_blade_length(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_dist_blade_current
{
public:
  explicit Init_PlannerRequest_dist_blade_current(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  Init_PlannerRequest_dist_blade_target dist_blade_current(::inspection_interfaces::msg::PlannerRequest::_dist_blade_current_type arg)
  {
    msg_.dist_blade_current = std::move(arg);
    return Init_PlannerRequest_dist_blade_target(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_current_pos_global
{
public:
  explicit Init_PlannerRequest_current_pos_global(::inspection_interfaces::msg::PlannerRequest & msg)
  : msg_(msg)
  {}
  Init_PlannerRequest_dist_blade_current current_pos_global(::inspection_interfaces::msg::PlannerRequest::_current_pos_global_type arg)
  {
    msg_.current_pos_global = std::move(arg);
    return Init_PlannerRequest_dist_blade_current(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

class Init_PlannerRequest_current_pose
{
public:
  Init_PlannerRequest_current_pose()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PlannerRequest_current_pos_global current_pose(::inspection_interfaces::msg::PlannerRequest::_current_pose_type arg)
  {
    msg_.current_pose = std::move(arg);
    return Init_PlannerRequest_current_pos_global(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerRequest msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::inspection_interfaces::msg::PlannerRequest>()
{
  return inspection_interfaces::msg::builder::Init_PlannerRequest_current_pose();
}

}  // namespace inspection_interfaces

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_REQUEST__BUILDER_HPP_
