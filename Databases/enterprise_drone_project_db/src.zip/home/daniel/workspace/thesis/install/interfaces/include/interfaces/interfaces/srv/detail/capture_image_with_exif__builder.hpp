// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:srv/CaptureImageWithExif.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__SRV__DETAIL__CAPTURE_IMAGE_WITH_EXIF__BUILDER_HPP_
#define INTERFACES__SRV__DETAIL__CAPTURE_IMAGE_WITH_EXIF__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/srv/detail/capture_image_with_exif__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace srv
{

namespace builder
{

class Init_CaptureImageWithExif_Request_exif_data
{
public:
  explicit Init_CaptureImageWithExif_Request_exif_data(::interfaces::srv::CaptureImageWithExif_Request & msg)
  : msg_(msg)
  {}
  ::interfaces::srv::CaptureImageWithExif_Request exif_data(::interfaces::srv::CaptureImageWithExif_Request::_exif_data_type arg)
  {
    msg_.exif_data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::srv::CaptureImageWithExif_Request msg_;
};

class Init_CaptureImageWithExif_Request_focal_distance
{
public:
  explicit Init_CaptureImageWithExif_Request_focal_distance(::interfaces::srv::CaptureImageWithExif_Request & msg)
  : msg_(msg)
  {}
  Init_CaptureImageWithExif_Request_exif_data focal_distance(::interfaces::srv::CaptureImageWithExif_Request::_focal_distance_type arg)
  {
    msg_.focal_distance = std::move(arg);
    return Init_CaptureImageWithExif_Request_exif_data(msg_);
  }

private:
  ::interfaces::srv::CaptureImageWithExif_Request msg_;
};

class Init_CaptureImageWithExif_Request_name
{
public:
  explicit Init_CaptureImageWithExif_Request_name(::interfaces::srv::CaptureImageWithExif_Request & msg)
  : msg_(msg)
  {}
  Init_CaptureImageWithExif_Request_focal_distance name(::interfaces::srv::CaptureImageWithExif_Request::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_CaptureImageWithExif_Request_focal_distance(msg_);
  }

private:
  ::interfaces::srv::CaptureImageWithExif_Request msg_;
};

class Init_CaptureImageWithExif_Request_cmd
{
public:
  explicit Init_CaptureImageWithExif_Request_cmd(::interfaces::srv::CaptureImageWithExif_Request & msg)
  : msg_(msg)
  {}
  Init_CaptureImageWithExif_Request_name cmd(::interfaces::srv::CaptureImageWithExif_Request::_cmd_type arg)
  {
    msg_.cmd = std::move(arg);
    return Init_CaptureImageWithExif_Request_name(msg_);
  }

private:
  ::interfaces::srv::CaptureImageWithExif_Request msg_;
};

class Init_CaptureImageWithExif_Request_header
{
public:
  Init_CaptureImageWithExif_Request_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CaptureImageWithExif_Request_cmd header(::interfaces::srv::CaptureImageWithExif_Request::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_CaptureImageWithExif_Request_cmd(msg_);
  }

private:
  ::interfaces::srv::CaptureImageWithExif_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::srv::CaptureImageWithExif_Request>()
{
  return interfaces::srv::builder::Init_CaptureImageWithExif_Request_header();
}

}  // namespace interfaces


namespace interfaces
{

namespace srv
{

namespace builder
{

class Init_CaptureImageWithExif_Response_path
{
public:
  explicit Init_CaptureImageWithExif_Response_path(::interfaces::srv::CaptureImageWithExif_Response & msg)
  : msg_(msg)
  {}
  ::interfaces::srv::CaptureImageWithExif_Response path(::interfaces::srv::CaptureImageWithExif_Response::_path_type arg)
  {
    msg_.path = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::srv::CaptureImageWithExif_Response msg_;
};

class Init_CaptureImageWithExif_Response_result
{
public:
  Init_CaptureImageWithExif_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CaptureImageWithExif_Response_path result(::interfaces::srv::CaptureImageWithExif_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_CaptureImageWithExif_Response_path(msg_);
  }

private:
  ::interfaces::srv::CaptureImageWithExif_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::srv::CaptureImageWithExif_Response>()
{
  return interfaces::srv::builder::Init_CaptureImageWithExif_Response_result();
}

}  // namespace interfaces

#endif  // INTERFACES__SRV__DETAIL__CAPTURE_IMAGE_WITH_EXIF__BUILDER_HPP_
