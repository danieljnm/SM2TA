// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from smacc2_msgs:msg/SmaccOrthogonal.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_ORTHOGONAL__STRUCT_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_ORTHOGONAL__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__smacc2_msgs__msg__SmaccOrthogonal __attribute__((deprecated))
#else
# define DEPRECATED__smacc2_msgs__msg__SmaccOrthogonal __declspec(deprecated)
#endif

namespace smacc2_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SmaccOrthogonal_
{
  using Type = SmaccOrthogonal_<ContainerAllocator>;

  explicit SmaccOrthogonal_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
    }
  }

  explicit SmaccOrthogonal_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
    }
  }

  // field types and members
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;
  using _client_behavior_names_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _client_behavior_names_type client_behavior_names;
  using _client_names_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _client_names_type client_names;

  // setters for named parameter idiom
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__client_behavior_names(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->client_behavior_names = _arg;
    return *this;
  }
  Type & set__client_names(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->client_names = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator> *;
  using ConstRawPtr =
    const smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__smacc2_msgs__msg__SmaccOrthogonal
    std::shared_ptr<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__smacc2_msgs__msg__SmaccOrthogonal
    std::shared_ptr<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SmaccOrthogonal_ & other) const
  {
    if (this->name != other.name) {
      return false;
    }
    if (this->client_behavior_names != other.client_behavior_names) {
      return false;
    }
    if (this->client_names != other.client_names) {
      return false;
    }
    return true;
  }
  bool operator!=(const SmaccOrthogonal_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SmaccOrthogonal_

// alias to use template instance with default allocator
using SmaccOrthogonal =
  smacc2_msgs::msg::SmaccOrthogonal_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_ORTHOGONAL__STRUCT_HPP_
