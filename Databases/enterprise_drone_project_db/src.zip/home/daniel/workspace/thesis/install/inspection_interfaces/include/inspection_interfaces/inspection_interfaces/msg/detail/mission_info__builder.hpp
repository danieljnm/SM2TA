// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from inspection_interfaces:msg/MissionInfo.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__MISSION_INFO__BUILDER_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__MISSION_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "inspection_interfaces/msg/detail/mission_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace inspection_interfaces
{

namespace msg
{

namespace builder
{

class Init_MissionInfo_vertical_safety
{
public:
  explicit Init_MissionInfo_vertical_safety(::inspection_interfaces::msg::MissionInfo & msg)
  : msg_(msg)
  {}
  ::inspection_interfaces::msg::MissionInfo vertical_safety(::inspection_interfaces::msg::MissionInfo::_vertical_safety_type arg)
  {
    msg_.vertical_safety = std::move(arg);
    return std::move(msg_);
  }

private:
  ::inspection_interfaces::msg::MissionInfo msg_;
};

class Init_MissionInfo_hub_offset
{
public:
  explicit Init_MissionInfo_hub_offset(::inspection_interfaces::msg::MissionInfo & msg)
  : msg_(msg)
  {}
  Init_MissionInfo_vertical_safety hub_offset(::inspection_interfaces::msg::MissionInfo::_hub_offset_type arg)
  {
    msg_.hub_offset = std::move(arg);
    return Init_MissionInfo_vertical_safety(msg_);
  }

private:
  ::inspection_interfaces::msg::MissionInfo msg_;
};

class Init_MissionInfo_overlap_procentage
{
public:
  explicit Init_MissionInfo_overlap_procentage(::inspection_interfaces::msg::MissionInfo & msg)
  : msg_(msg)
  {}
  Init_MissionInfo_hub_offset overlap_procentage(::inspection_interfaces::msg::MissionInfo::_overlap_procentage_type arg)
  {
    msg_.overlap_procentage = std::move(arg);
    return Init_MissionInfo_hub_offset(msg_);
  }

private:
  ::inspection_interfaces::msg::MissionInfo msg_;
};

class Init_MissionInfo_inspect_targets
{
public:
  explicit Init_MissionInfo_inspect_targets(::inspection_interfaces::msg::MissionInfo & msg)
  : msg_(msg)
  {}
  Init_MissionInfo_overlap_procentage inspect_targets(::inspection_interfaces::msg::MissionInfo::_inspect_targets_type arg)
  {
    msg_.inspect_targets = std::move(arg);
    return Init_MissionInfo_overlap_procentage(msg_);
  }

private:
  ::inspection_interfaces::msg::MissionInfo msg_;
};

class Init_MissionInfo_first_blade
{
public:
  explicit Init_MissionInfo_first_blade(::inspection_interfaces::msg::MissionInfo & msg)
  : msg_(msg)
  {}
  Init_MissionInfo_inspect_targets first_blade(::inspection_interfaces::msg::MissionInfo::_first_blade_type arg)
  {
    msg_.first_blade = std::move(arg);
    return Init_MissionInfo_inspect_targets(msg_);
  }

private:
  ::inspection_interfaces::msg::MissionInfo msg_;
};

class Init_MissionInfo_blade_length
{
public:
  explicit Init_MissionInfo_blade_length(::inspection_interfaces::msg::MissionInfo & msg)
  : msg_(msg)
  {}
  Init_MissionInfo_first_blade blade_length(::inspection_interfaces::msg::MissionInfo::_blade_length_type arg)
  {
    msg_.blade_length = std::move(arg);
    return Init_MissionInfo_first_blade(msg_);
  }

private:
  ::inspection_interfaces::msg::MissionInfo msg_;
};

class Init_MissionInfo_dist_blade_target
{
public:
  Init_MissionInfo_dist_blade_target()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MissionInfo_blade_length dist_blade_target(::inspection_interfaces::msg::MissionInfo::_dist_blade_target_type arg)
  {
    msg_.dist_blade_target = std::move(arg);
    return Init_MissionInfo_blade_length(msg_);
  }

private:
  ::inspection_interfaces::msg::MissionInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::inspection_interfaces::msg::MissionInfo>()
{
  return inspection_interfaces::msg::builder::Init_MissionInfo_dist_blade_target();
}

}  // namespace inspection_interfaces

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__MISSION_INFO__BUILDER_HPP_
