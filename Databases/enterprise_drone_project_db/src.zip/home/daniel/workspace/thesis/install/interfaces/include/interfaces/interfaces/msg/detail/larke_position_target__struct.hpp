// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from interfaces:msg/LarkePositionTarget.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__DETAIL__LARKE_POSITION_TARGET__STRUCT_HPP_
#define INTERFACES__MSG__DETAIL__LARKE_POSITION_TARGET__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'position'
#include "geometry_msgs/msg/detail/point__struct.hpp"
// Member 'velocity'
// Member 'acceleration_or_force'
#include "geometry_msgs/msg/detail/vector3__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__interfaces__msg__LarkePositionTarget __attribute__((deprecated))
#else
# define DEPRECATED__interfaces__msg__LarkePositionTarget __declspec(deprecated)
#endif

namespace interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LarkePositionTarget_
{
  using Type = LarkePositionTarget_<ContainerAllocator>;

  explicit LarkePositionTarget_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    position(_init),
    velocity(_init),
    acceleration_or_force(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->coordinate_frame = 0;
      this->type_mask = 0;
      this->yaw = 0.0f;
      this->yaw_rate = 0.0f;
      this->option_rotating_search = 0;
    }
  }

  explicit LarkePositionTarget_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    position(_alloc, _init),
    velocity(_alloc, _init),
    acceleration_or_force(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->coordinate_frame = 0;
      this->type_mask = 0;
      this->yaw = 0.0f;
      this->yaw_rate = 0.0f;
      this->option_rotating_search = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _coordinate_frame_type =
    uint8_t;
  _coordinate_frame_type coordinate_frame;
  using _type_mask_type =
    uint16_t;
  _type_mask_type type_mask;
  using _position_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _position_type position;
  using _velocity_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _velocity_type velocity;
  using _acceleration_or_force_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _acceleration_or_force_type acceleration_or_force;
  using _yaw_type =
    float;
  _yaw_type yaw;
  using _yaw_rate_type =
    float;
  _yaw_rate_type yaw_rate;
  using _option_rotating_search_type =
    uint16_t;
  _option_rotating_search_type option_rotating_search;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__coordinate_frame(
    const uint8_t & _arg)
  {
    this->coordinate_frame = _arg;
    return *this;
  }
  Type & set__type_mask(
    const uint16_t & _arg)
  {
    this->type_mask = _arg;
    return *this;
  }
  Type & set__position(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->position = _arg;
    return *this;
  }
  Type & set__velocity(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->velocity = _arg;
    return *this;
  }
  Type & set__acceleration_or_force(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->acceleration_or_force = _arg;
    return *this;
  }
  Type & set__yaw(
    const float & _arg)
  {
    this->yaw = _arg;
    return *this;
  }
  Type & set__yaw_rate(
    const float & _arg)
  {
    this->yaw_rate = _arg;
    return *this;
  }
  Type & set__option_rotating_search(
    const uint16_t & _arg)
  {
    this->option_rotating_search = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    interfaces::msg::LarkePositionTarget_<ContainerAllocator> *;
  using ConstRawPtr =
    const interfaces::msg::LarkePositionTarget_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<interfaces::msg::LarkePositionTarget_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<interfaces::msg::LarkePositionTarget_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::LarkePositionTarget_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::LarkePositionTarget_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::LarkePositionTarget_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::LarkePositionTarget_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<interfaces::msg::LarkePositionTarget_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<interfaces::msg::LarkePositionTarget_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__interfaces__msg__LarkePositionTarget
    std::shared_ptr<interfaces::msg::LarkePositionTarget_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__interfaces__msg__LarkePositionTarget
    std::shared_ptr<interfaces::msg::LarkePositionTarget_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LarkePositionTarget_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->coordinate_frame != other.coordinate_frame) {
      return false;
    }
    if (this->type_mask != other.type_mask) {
      return false;
    }
    if (this->position != other.position) {
      return false;
    }
    if (this->velocity != other.velocity) {
      return false;
    }
    if (this->acceleration_or_force != other.acceleration_or_force) {
      return false;
    }
    if (this->yaw != other.yaw) {
      return false;
    }
    if (this->yaw_rate != other.yaw_rate) {
      return false;
    }
    if (this->option_rotating_search != other.option_rotating_search) {
      return false;
    }
    return true;
  }
  bool operator!=(const LarkePositionTarget_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LarkePositionTarget_

// alias to use template instance with default allocator
using LarkePositionTarget =
  interfaces::msg::LarkePositionTarget_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__LARKE_POSITION_TARGET__STRUCT_HPP_
