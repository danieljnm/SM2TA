// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from smacc2_msgs:msg/SmaccTransitionLogEntry.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION_LOG_ENTRY__BUILDER_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION_LOG_ENTRY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "smacc2_msgs/msg/detail/smacc_transition_log_entry__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace smacc2_msgs
{

namespace msg
{

namespace builder
{

class Init_SmaccTransitionLogEntry_transition
{
public:
  explicit Init_SmaccTransitionLogEntry_transition(::smacc2_msgs::msg::SmaccTransitionLogEntry & msg)
  : msg_(msg)
  {}
  ::smacc2_msgs::msg::SmaccTransitionLogEntry transition(::smacc2_msgs::msg::SmaccTransitionLogEntry::_transition_type arg)
  {
    msg_.transition = std::move(arg);
    return std::move(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccTransitionLogEntry msg_;
};

class Init_SmaccTransitionLogEntry_timestamp
{
public:
  Init_SmaccTransitionLogEntry_timestamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SmaccTransitionLogEntry_transition timestamp(::smacc2_msgs::msg::SmaccTransitionLogEntry::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_SmaccTransitionLogEntry_transition(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccTransitionLogEntry msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::smacc2_msgs::msg::SmaccTransitionLogEntry>()
{
  return smacc2_msgs::msg::builder::Init_SmaccTransitionLogEntry_timestamp();
}

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION_LOG_ENTRY__BUILDER_HPP_
