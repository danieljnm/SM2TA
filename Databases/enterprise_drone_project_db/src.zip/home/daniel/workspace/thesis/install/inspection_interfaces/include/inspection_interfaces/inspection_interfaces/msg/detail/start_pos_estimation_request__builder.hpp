// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from inspection_interfaces:msg/StartPosEstimationRequest.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__START_POS_ESTIMATION_REQUEST__BUILDER_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__START_POS_ESTIMATION_REQUEST__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "inspection_interfaces/msg/detail/start_pos_estimation_request__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace inspection_interfaces
{

namespace msg
{

namespace builder
{

class Init_StartPosEstimationRequest_current_lidar_distance
{
public:
  explicit Init_StartPosEstimationRequest_current_lidar_distance(::inspection_interfaces::msg::StartPosEstimationRequest & msg)
  : msg_(msg)
  {}
  ::inspection_interfaces::msg::StartPosEstimationRequest current_lidar_distance(::inspection_interfaces::msg::StartPosEstimationRequest::_current_lidar_distance_type arg)
  {
    msg_.current_lidar_distance = std::move(arg);
    return std::move(msg_);
  }

private:
  ::inspection_interfaces::msg::StartPosEstimationRequest msg_;
};

class Init_StartPosEstimationRequest_filepath
{
public:
  Init_StartPosEstimationRequest_filepath()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_StartPosEstimationRequest_current_lidar_distance filepath(::inspection_interfaces::msg::StartPosEstimationRequest::_filepath_type arg)
  {
    msg_.filepath = std::move(arg);
    return Init_StartPosEstimationRequest_current_lidar_distance(msg_);
  }

private:
  ::inspection_interfaces::msg::StartPosEstimationRequest msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::inspection_interfaces::msg::StartPosEstimationRequest>()
{
  return inspection_interfaces::msg::builder::Init_StartPosEstimationRequest_filepath();
}

}  // namespace inspection_interfaces

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__START_POS_ESTIMATION_REQUEST__BUILDER_HPP_
