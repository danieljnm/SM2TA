// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from inspection_interfaces:msg/StartPosEstimationRequest.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__START_POS_ESTIMATION_REQUEST__TRAITS_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__START_POS_ESTIMATION_REQUEST__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "inspection_interfaces/msg/detail/start_pos_estimation_request__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace inspection_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const StartPosEstimationRequest & msg,
  std::ostream & out)
{
  out << "{";
  // member: filepath
  {
    out << "filepath: ";
    rosidl_generator_traits::value_to_yaml(msg.filepath, out);
    out << ", ";
  }

  // member: current_lidar_distance
  {
    out << "current_lidar_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.current_lidar_distance, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const StartPosEstimationRequest & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: filepath
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "filepath: ";
    rosidl_generator_traits::value_to_yaml(msg.filepath, out);
    out << "\n";
  }

  // member: current_lidar_distance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "current_lidar_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.current_lidar_distance, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const StartPosEstimationRequest & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace inspection_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use inspection_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const inspection_interfaces::msg::StartPosEstimationRequest & msg,
  std::ostream & out, size_t indentation = 0)
{
  inspection_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use inspection_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const inspection_interfaces::msg::StartPosEstimationRequest & msg)
{
  return inspection_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<inspection_interfaces::msg::StartPosEstimationRequest>()
{
  return "inspection_interfaces::msg::StartPosEstimationRequest";
}

template<>
inline const char * name<inspection_interfaces::msg::StartPosEstimationRequest>()
{
  return "inspection_interfaces/msg/StartPosEstimationRequest";
}

template<>
struct has_fixed_size<inspection_interfaces::msg::StartPosEstimationRequest>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<inspection_interfaces::msg::StartPosEstimationRequest>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<inspection_interfaces::msg::StartPosEstimationRequest>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__START_POS_ESTIMATION_REQUEST__TRAITS_HPP_
