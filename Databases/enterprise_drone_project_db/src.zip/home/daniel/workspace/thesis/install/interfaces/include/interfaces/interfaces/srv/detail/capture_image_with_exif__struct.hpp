// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from interfaces:srv/CaptureImageWithExif.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__SRV__DETAIL__CAPTURE_IMAGE_WITH_EXIF__STRUCT_HPP_
#define INTERFACES__SRV__DETAIL__CAPTURE_IMAGE_WITH_EXIF__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'exif_data'
#include "interfaces/msg/detail/image_exif__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__interfaces__srv__CaptureImageWithExif_Request __attribute__((deprecated))
#else
# define DEPRECATED__interfaces__srv__CaptureImageWithExif_Request __declspec(deprecated)
#endif

namespace interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct CaptureImageWithExif_Request_
{
  using Type = CaptureImageWithExif_Request_<ContainerAllocator>;

  explicit CaptureImageWithExif_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    exif_data(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0;
      this->name = "";
      this->focal_distance = 0.0;
    }
  }

  explicit CaptureImageWithExif_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    name(_alloc),
    exif_data(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0;
      this->name = "";
      this->focal_distance = 0.0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _cmd_type =
    int8_t;
  _cmd_type cmd;
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;
  using _focal_distance_type =
    double;
  _focal_distance_type focal_distance;
  using _exif_data_type =
    interfaces::msg::ImageExif_<ContainerAllocator>;
  _exif_data_type exif_data;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__cmd(
    const int8_t & _arg)
  {
    this->cmd = _arg;
    return *this;
  }
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__focal_distance(
    const double & _arg)
  {
    this->focal_distance = _arg;
    return *this;
  }
  Type & set__exif_data(
    const interfaces::msg::ImageExif_<ContainerAllocator> & _arg)
  {
    this->exif_data = _arg;
    return *this;
  }

  // constant declarations
  static constexpr int8_t CAPTURE_IMAGE =
    1;
  static constexpr int8_t CAPTURE_LIVE_IMAGE =
    2;
  static constexpr int8_t TOGGLE_LIVE_STREAM =
    3;

  // pointer types
  using RawPtr =
    interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__interfaces__srv__CaptureImageWithExif_Request
    std::shared_ptr<interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__interfaces__srv__CaptureImageWithExif_Request
    std::shared_ptr<interfaces::srv::CaptureImageWithExif_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CaptureImageWithExif_Request_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->cmd != other.cmd) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    if (this->focal_distance != other.focal_distance) {
      return false;
    }
    if (this->exif_data != other.exif_data) {
      return false;
    }
    return true;
  }
  bool operator!=(const CaptureImageWithExif_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CaptureImageWithExif_Request_

// alias to use template instance with default allocator
using CaptureImageWithExif_Request =
  interfaces::srv::CaptureImageWithExif_Request_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t CaptureImageWithExif_Request_<ContainerAllocator>::CAPTURE_IMAGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t CaptureImageWithExif_Request_<ContainerAllocator>::CAPTURE_LIVE_IMAGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t CaptureImageWithExif_Request_<ContainerAllocator>::TOGGLE_LIVE_STREAM;
#endif  // __cplusplus < 201703L

}  // namespace srv

}  // namespace interfaces


#ifndef _WIN32
# define DEPRECATED__interfaces__srv__CaptureImageWithExif_Response __attribute__((deprecated))
#else
# define DEPRECATED__interfaces__srv__CaptureImageWithExif_Response __declspec(deprecated)
#endif

namespace interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct CaptureImageWithExif_Response_
{
  using Type = CaptureImageWithExif_Response_<ContainerAllocator>;

  explicit CaptureImageWithExif_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = false;
      this->path = "";
    }
  }

  explicit CaptureImageWithExif_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : path(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = false;
      this->path = "";
    }
  }

  // field types and members
  using _result_type =
    bool;
  _result_type result;
  using _path_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _path_type path;

  // setters for named parameter idiom
  Type & set__result(
    const bool & _arg)
  {
    this->result = _arg;
    return *this;
  }
  Type & set__path(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->path = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__interfaces__srv__CaptureImageWithExif_Response
    std::shared_ptr<interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__interfaces__srv__CaptureImageWithExif_Response
    std::shared_ptr<interfaces::srv::CaptureImageWithExif_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CaptureImageWithExif_Response_ & other) const
  {
    if (this->result != other.result) {
      return false;
    }
    if (this->path != other.path) {
      return false;
    }
    return true;
  }
  bool operator!=(const CaptureImageWithExif_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CaptureImageWithExif_Response_

// alias to use template instance with default allocator
using CaptureImageWithExif_Response =
  interfaces::srv::CaptureImageWithExif_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace interfaces

namespace interfaces
{

namespace srv
{

struct CaptureImageWithExif
{
  using Request = interfaces::srv::CaptureImageWithExif_Request;
  using Response = interfaces::srv::CaptureImageWithExif_Response;
};

}  // namespace srv

}  // namespace interfaces

#endif  // INTERFACES__SRV__DETAIL__CAPTURE_IMAGE_WITH_EXIF__STRUCT_HPP_
