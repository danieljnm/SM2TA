// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__SMACC_TRANSITION_HPP_
#define SMACC2_MSGS__MSG__SMACC_TRANSITION_HPP_

#include "smacc2_msgs/msg/detail/smacc_transition__struct.hpp"
#include "smacc2_msgs/msg/detail/smacc_transition__builder.hpp"
#include "smacc2_msgs/msg/detail/smacc_transition__traits.hpp"
#include "smacc2_msgs/msg/detail/smacc_transition__type_support.hpp"

#endif  // SMACC2_MSGS__MSG__SMACC_TRANSITION_HPP_
