// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from inspection_interfaces:msg/PlannerResult.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_RESULT__STRUCT_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_RESULT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'plan'
#include "inspection_interfaces/msg/detail/planner_point__struct.hpp"
// Member 'local_hub_init_pose'
#include "geometry_msgs/msg/detail/pose__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__inspection_interfaces__msg__PlannerResult __attribute__((deprecated))
#else
# define DEPRECATED__inspection_interfaces__msg__PlannerResult __declspec(deprecated)
#endif

namespace inspection_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct PlannerResult_
{
  using Type = PlannerResult_<ContainerAllocator>;

  explicit PlannerResult_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : local_hub_init_pose(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->global_init_lat = 0.0;
      this->global_init_lon = 0.0;
      this->global_init_alt = 0.0;
    }
  }

  explicit PlannerResult_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : local_hub_init_pose(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->global_init_lat = 0.0;
      this->global_init_lon = 0.0;
      this->global_init_alt = 0.0;
    }
  }

  // field types and members
  using _plan_type =
    std::vector<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator>>>;
  _plan_type plan;
  using _local_hub_init_pose_type =
    geometry_msgs::msg::Pose_<ContainerAllocator>;
  _local_hub_init_pose_type local_hub_init_pose;
  using _global_init_lat_type =
    double;
  _global_init_lat_type global_init_lat;
  using _global_init_lon_type =
    double;
  _global_init_lon_type global_init_lon;
  using _global_init_alt_type =
    double;
  _global_init_alt_type global_init_alt;

  // setters for named parameter idiom
  Type & set__plan(
    const std::vector<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator>>> & _arg)
  {
    this->plan = _arg;
    return *this;
  }
  Type & set__local_hub_init_pose(
    const geometry_msgs::msg::Pose_<ContainerAllocator> & _arg)
  {
    this->local_hub_init_pose = _arg;
    return *this;
  }
  Type & set__global_init_lat(
    const double & _arg)
  {
    this->global_init_lat = _arg;
    return *this;
  }
  Type & set__global_init_lon(
    const double & _arg)
  {
    this->global_init_lon = _arg;
    return *this;
  }
  Type & set__global_init_alt(
    const double & _arg)
  {
    this->global_init_alt = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    inspection_interfaces::msg::PlannerResult_<ContainerAllocator> *;
  using ConstRawPtr =
    const inspection_interfaces::msg::PlannerResult_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<inspection_interfaces::msg::PlannerResult_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<inspection_interfaces::msg::PlannerResult_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      inspection_interfaces::msg::PlannerResult_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<inspection_interfaces::msg::PlannerResult_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      inspection_interfaces::msg::PlannerResult_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<inspection_interfaces::msg::PlannerResult_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<inspection_interfaces::msg::PlannerResult_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<inspection_interfaces::msg::PlannerResult_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__inspection_interfaces__msg__PlannerResult
    std::shared_ptr<inspection_interfaces::msg::PlannerResult_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__inspection_interfaces__msg__PlannerResult
    std::shared_ptr<inspection_interfaces::msg::PlannerResult_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PlannerResult_ & other) const
  {
    if (this->plan != other.plan) {
      return false;
    }
    if (this->local_hub_init_pose != other.local_hub_init_pose) {
      return false;
    }
    if (this->global_init_lat != other.global_init_lat) {
      return false;
    }
    if (this->global_init_lon != other.global_init_lon) {
      return false;
    }
    if (this->global_init_alt != other.global_init_alt) {
      return false;
    }
    return true;
  }
  bool operator!=(const PlannerResult_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PlannerResult_

// alias to use template instance with default allocator
using PlannerResult =
  inspection_interfaces::msg::PlannerResult_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace inspection_interfaces

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_RESULT__STRUCT_HPP_
