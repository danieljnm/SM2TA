// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from cv_interfaces:srv/EstimateStartPosition.idl
// generated code does not contain a copyright notice

#ifndef CV_INTERFACES__SRV__DETAIL__ESTIMATE_START_POSITION__BUILDER_HPP_
#define CV_INTERFACES__SRV__DETAIL__ESTIMATE_START_POSITION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "cv_interfaces/srv/detail/estimate_start_position__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace cv_interfaces
{

namespace srv
{

namespace builder
{

class Init_EstimateStartPosition_Request_target_width
{
public:
  explicit Init_EstimateStartPosition_Request_target_width(::cv_interfaces::srv::EstimateStartPosition_Request & msg)
  : msg_(msg)
  {}
  ::cv_interfaces::srv::EstimateStartPosition_Request target_width(::cv_interfaces::srv::EstimateStartPosition_Request::_target_width_type arg)
  {
    msg_.target_width = std::move(arg);
    return std::move(msg_);
  }

private:
  ::cv_interfaces::srv::EstimateStartPosition_Request msg_;
};

class Init_EstimateStartPosition_Request_target_height
{
public:
  explicit Init_EstimateStartPosition_Request_target_height(::cv_interfaces::srv::EstimateStartPosition_Request & msg)
  : msg_(msg)
  {}
  Init_EstimateStartPosition_Request_target_width target_height(::cv_interfaces::srv::EstimateStartPosition_Request::_target_height_type arg)
  {
    msg_.target_height = std::move(arg);
    return Init_EstimateStartPosition_Request_target_width(msg_);
  }

private:
  ::cv_interfaces::srv::EstimateStartPosition_Request msg_;
};

class Init_EstimateStartPosition_Request_frame_jpeg
{
public:
  Init_EstimateStartPosition_Request_frame_jpeg()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EstimateStartPosition_Request_target_height frame_jpeg(::cv_interfaces::srv::EstimateStartPosition_Request::_frame_jpeg_type arg)
  {
    msg_.frame_jpeg = std::move(arg);
    return Init_EstimateStartPosition_Request_target_height(msg_);
  }

private:
  ::cv_interfaces::srv::EstimateStartPosition_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::cv_interfaces::srv::EstimateStartPosition_Request>()
{
  return cv_interfaces::srv::builder::Init_EstimateStartPosition_Request_frame_jpeg();
}

}  // namespace cv_interfaces


namespace cv_interfaces
{

namespace srv
{

namespace builder
{

class Init_EstimateStartPosition_Response_error_msg
{
public:
  explicit Init_EstimateStartPosition_Response_error_msg(::cv_interfaces::srv::EstimateStartPosition_Response & msg)
  : msg_(msg)
  {}
  ::cv_interfaces::srv::EstimateStartPosition_Response error_msg(::cv_interfaces::srv::EstimateStartPosition_Response::_error_msg_type arg)
  {
    msg_.error_msg = std::move(arg);
    return std::move(msg_);
  }

private:
  ::cv_interfaces::srv::EstimateStartPosition_Response msg_;
};

class Init_EstimateStartPosition_Response_rotation_deg
{
public:
  explicit Init_EstimateStartPosition_Response_rotation_deg(::cv_interfaces::srv::EstimateStartPosition_Response & msg)
  : msg_(msg)
  {}
  Init_EstimateStartPosition_Response_error_msg rotation_deg(::cv_interfaces::srv::EstimateStartPosition_Response::_rotation_deg_type arg)
  {
    msg_.rotation_deg = std::move(arg);
    return Init_EstimateStartPosition_Response_error_msg(msg_);
  }

private:
  ::cv_interfaces::srv::EstimateStartPosition_Response msg_;
};

class Init_EstimateStartPosition_Response_center_px_y
{
public:
  explicit Init_EstimateStartPosition_Response_center_px_y(::cv_interfaces::srv::EstimateStartPosition_Response & msg)
  : msg_(msg)
  {}
  Init_EstimateStartPosition_Response_rotation_deg center_px_y(::cv_interfaces::srv::EstimateStartPosition_Response::_center_px_y_type arg)
  {
    msg_.center_px_y = std::move(arg);
    return Init_EstimateStartPosition_Response_rotation_deg(msg_);
  }

private:
  ::cv_interfaces::srv::EstimateStartPosition_Response msg_;
};

class Init_EstimateStartPosition_Response_center_px_x
{
public:
  explicit Init_EstimateStartPosition_Response_center_px_x(::cv_interfaces::srv::EstimateStartPosition_Response & msg)
  : msg_(msg)
  {}
  Init_EstimateStartPosition_Response_center_px_y center_px_x(::cv_interfaces::srv::EstimateStartPosition_Response::_center_px_x_type arg)
  {
    msg_.center_px_x = std::move(arg);
    return Init_EstimateStartPosition_Response_center_px_y(msg_);
  }

private:
  ::cv_interfaces::srv::EstimateStartPosition_Response msg_;
};

class Init_EstimateStartPosition_Response_is_valid
{
public:
  Init_EstimateStartPosition_Response_is_valid()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EstimateStartPosition_Response_center_px_x is_valid(::cv_interfaces::srv::EstimateStartPosition_Response::_is_valid_type arg)
  {
    msg_.is_valid = std::move(arg);
    return Init_EstimateStartPosition_Response_center_px_x(msg_);
  }

private:
  ::cv_interfaces::srv::EstimateStartPosition_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::cv_interfaces::srv::EstimateStartPosition_Response>()
{
  return cv_interfaces::srv::builder::Init_EstimateStartPosition_Response_is_valid();
}

}  // namespace cv_interfaces

#endif  // CV_INTERFACES__SRV__DETAIL__ESTIMATE_START_POSITION__BUILDER_HPP_
