// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/LarkePositionTarget.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__DETAIL__LARKE_POSITION_TARGET__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__LARKE_POSITION_TARGET__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/larke_position_target__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_LarkePositionTarget_option_rotating_search
{
public:
  explicit Init_LarkePositionTarget_option_rotating_search(::interfaces::msg::LarkePositionTarget & msg)
  : msg_(msg)
  {}
  ::interfaces::msg::LarkePositionTarget option_rotating_search(::interfaces::msg::LarkePositionTarget::_option_rotating_search_type arg)
  {
    msg_.option_rotating_search = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::LarkePositionTarget msg_;
};

class Init_LarkePositionTarget_yaw_rate
{
public:
  explicit Init_LarkePositionTarget_yaw_rate(::interfaces::msg::LarkePositionTarget & msg)
  : msg_(msg)
  {}
  Init_LarkePositionTarget_option_rotating_search yaw_rate(::interfaces::msg::LarkePositionTarget::_yaw_rate_type arg)
  {
    msg_.yaw_rate = std::move(arg);
    return Init_LarkePositionTarget_option_rotating_search(msg_);
  }

private:
  ::interfaces::msg::LarkePositionTarget msg_;
};

class Init_LarkePositionTarget_yaw
{
public:
  explicit Init_LarkePositionTarget_yaw(::interfaces::msg::LarkePositionTarget & msg)
  : msg_(msg)
  {}
  Init_LarkePositionTarget_yaw_rate yaw(::interfaces::msg::LarkePositionTarget::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_LarkePositionTarget_yaw_rate(msg_);
  }

private:
  ::interfaces::msg::LarkePositionTarget msg_;
};

class Init_LarkePositionTarget_acceleration_or_force
{
public:
  explicit Init_LarkePositionTarget_acceleration_or_force(::interfaces::msg::LarkePositionTarget & msg)
  : msg_(msg)
  {}
  Init_LarkePositionTarget_yaw acceleration_or_force(::interfaces::msg::LarkePositionTarget::_acceleration_or_force_type arg)
  {
    msg_.acceleration_or_force = std::move(arg);
    return Init_LarkePositionTarget_yaw(msg_);
  }

private:
  ::interfaces::msg::LarkePositionTarget msg_;
};

class Init_LarkePositionTarget_velocity
{
public:
  explicit Init_LarkePositionTarget_velocity(::interfaces::msg::LarkePositionTarget & msg)
  : msg_(msg)
  {}
  Init_LarkePositionTarget_acceleration_or_force velocity(::interfaces::msg::LarkePositionTarget::_velocity_type arg)
  {
    msg_.velocity = std::move(arg);
    return Init_LarkePositionTarget_acceleration_or_force(msg_);
  }

private:
  ::interfaces::msg::LarkePositionTarget msg_;
};

class Init_LarkePositionTarget_position
{
public:
  explicit Init_LarkePositionTarget_position(::interfaces::msg::LarkePositionTarget & msg)
  : msg_(msg)
  {}
  Init_LarkePositionTarget_velocity position(::interfaces::msg::LarkePositionTarget::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_LarkePositionTarget_velocity(msg_);
  }

private:
  ::interfaces::msg::LarkePositionTarget msg_;
};

class Init_LarkePositionTarget_type_mask
{
public:
  explicit Init_LarkePositionTarget_type_mask(::interfaces::msg::LarkePositionTarget & msg)
  : msg_(msg)
  {}
  Init_LarkePositionTarget_position type_mask(::interfaces::msg::LarkePositionTarget::_type_mask_type arg)
  {
    msg_.type_mask = std::move(arg);
    return Init_LarkePositionTarget_position(msg_);
  }

private:
  ::interfaces::msg::LarkePositionTarget msg_;
};

class Init_LarkePositionTarget_coordinate_frame
{
public:
  explicit Init_LarkePositionTarget_coordinate_frame(::interfaces::msg::LarkePositionTarget & msg)
  : msg_(msg)
  {}
  Init_LarkePositionTarget_type_mask coordinate_frame(::interfaces::msg::LarkePositionTarget::_coordinate_frame_type arg)
  {
    msg_.coordinate_frame = std::move(arg);
    return Init_LarkePositionTarget_type_mask(msg_);
  }

private:
  ::interfaces::msg::LarkePositionTarget msg_;
};

class Init_LarkePositionTarget_header
{
public:
  Init_LarkePositionTarget_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LarkePositionTarget_coordinate_frame header(::interfaces::msg::LarkePositionTarget::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_LarkePositionTarget_coordinate_frame(msg_);
  }

private:
  ::interfaces::msg::LarkePositionTarget msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::LarkePositionTarget>()
{
  return interfaces::msg::builder::Init_LarkePositionTarget_header();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__LARKE_POSITION_TARGET__BUILDER_HPP_
