// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__GLOBAL_POS_HPP_
#define INTERFACES__MSG__GLOBAL_POS_HPP_

#include "interfaces/msg/detail/global_pos__struct.hpp"
#include "interfaces/msg/detail/global_pos__builder.hpp"
#include "interfaces/msg/detail/global_pos__traits.hpp"
#include "interfaces/msg/detail/global_pos__type_support.hpp"

#endif  // INTERFACES__MSG__GLOBAL_POS_HPP_
