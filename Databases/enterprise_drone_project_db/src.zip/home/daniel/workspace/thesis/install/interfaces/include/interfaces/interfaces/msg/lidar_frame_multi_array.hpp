// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__LIDAR_FRAME_MULTI_ARRAY_HPP_
#define INTERFACES__MSG__LIDAR_FRAME_MULTI_ARRAY_HPP_

#include "interfaces/msg/detail/lidar_frame_multi_array__struct.hpp"
#include "interfaces/msg/detail/lidar_frame_multi_array__builder.hpp"
#include "interfaces/msg/detail/lidar_frame_multi_array__traits.hpp"
#include "interfaces/msg/detail/lidar_frame_multi_array__type_support.hpp"

#endif  // INTERFACES__MSG__LIDAR_FRAME_MULTI_ARRAY_HPP_
