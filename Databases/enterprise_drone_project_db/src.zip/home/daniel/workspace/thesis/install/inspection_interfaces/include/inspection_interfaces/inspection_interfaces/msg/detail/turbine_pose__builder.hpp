// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from inspection_interfaces:msg/TurbinePose.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__TURBINE_POSE__BUILDER_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__TURBINE_POSE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "inspection_interfaces/msg/detail/turbine_pose__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace inspection_interfaces
{

namespace msg
{

namespace builder
{

class Init_TurbinePose_current_distance_lidar
{
public:
  explicit Init_TurbinePose_current_distance_lidar(::inspection_interfaces::msg::TurbinePose & msg)
  : msg_(msg)
  {}
  ::inspection_interfaces::msg::TurbinePose current_distance_lidar(::inspection_interfaces::msg::TurbinePose::_current_distance_lidar_type arg)
  {
    msg_.current_distance_lidar = std::move(arg);
    return std::move(msg_);
  }

private:
  ::inspection_interfaces::msg::TurbinePose msg_;
};

class Init_TurbinePose_pixel_center_y
{
public:
  explicit Init_TurbinePose_pixel_center_y(::inspection_interfaces::msg::TurbinePose & msg)
  : msg_(msg)
  {}
  Init_TurbinePose_current_distance_lidar pixel_center_y(::inspection_interfaces::msg::TurbinePose::_pixel_center_y_type arg)
  {
    msg_.pixel_center_y = std::move(arg);
    return Init_TurbinePose_current_distance_lidar(msg_);
  }

private:
  ::inspection_interfaces::msg::TurbinePose msg_;
};

class Init_TurbinePose_pixel_center_x
{
public:
  explicit Init_TurbinePose_pixel_center_x(::inspection_interfaces::msg::TurbinePose & msg)
  : msg_(msg)
  {}
  Init_TurbinePose_pixel_center_y pixel_center_x(::inspection_interfaces::msg::TurbinePose::_pixel_center_x_type arg)
  {
    msg_.pixel_center_x = std::move(arg);
    return Init_TurbinePose_pixel_center_y(msg_);
  }

private:
  ::inspection_interfaces::msg::TurbinePose msg_;
};

class Init_TurbinePose_first_blade_rotation
{
public:
  Init_TurbinePose_first_blade_rotation()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TurbinePose_pixel_center_x first_blade_rotation(::inspection_interfaces::msg::TurbinePose::_first_blade_rotation_type arg)
  {
    msg_.first_blade_rotation = std::move(arg);
    return Init_TurbinePose_pixel_center_x(msg_);
  }

private:
  ::inspection_interfaces::msg::TurbinePose msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::inspection_interfaces::msg::TurbinePose>()
{
  return inspection_interfaces::msg::builder::Init_TurbinePose_first_blade_rotation();
}

}  // namespace inspection_interfaces

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__TURBINE_POSE__BUILDER_HPP_
