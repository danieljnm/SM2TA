// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from smacc2_msgs:msg/SmaccOrthogonal.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_ORTHOGONAL__TRAITS_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_ORTHOGONAL__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "smacc2_msgs/msg/detail/smacc_orthogonal__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace smacc2_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SmaccOrthogonal & msg,
  std::ostream & out)
{
  out << "{";
  // member: name
  {
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << ", ";
  }

  // member: client_behavior_names
  {
    if (msg.client_behavior_names.size() == 0) {
      out << "client_behavior_names: []";
    } else {
      out << "client_behavior_names: [";
      size_t pending_items = msg.client_behavior_names.size();
      for (auto item : msg.client_behavior_names) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: client_names
  {
    if (msg.client_names.size() == 0) {
      out << "client_names: []";
    } else {
      out << "client_names: [";
      size_t pending_items = msg.client_names.size();
      for (auto item : msg.client_names) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SmaccOrthogonal & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << "\n";
  }

  // member: client_behavior_names
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.client_behavior_names.size() == 0) {
      out << "client_behavior_names: []\n";
    } else {
      out << "client_behavior_names:\n";
      for (auto item : msg.client_behavior_names) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: client_names
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.client_names.size() == 0) {
      out << "client_names: []\n";
    } else {
      out << "client_names:\n";
      for (auto item : msg.client_names) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SmaccOrthogonal & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace smacc2_msgs

namespace rosidl_generator_traits
{

[[deprecated("use smacc2_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const smacc2_msgs::msg::SmaccOrthogonal & msg,
  std::ostream & out, size_t indentation = 0)
{
  smacc2_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use smacc2_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const smacc2_msgs::msg::SmaccOrthogonal & msg)
{
  return smacc2_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<smacc2_msgs::msg::SmaccOrthogonal>()
{
  return "smacc2_msgs::msg::SmaccOrthogonal";
}

template<>
inline const char * name<smacc2_msgs::msg::SmaccOrthogonal>()
{
  return "smacc2_msgs/msg/SmaccOrthogonal";
}

template<>
struct has_fixed_size<smacc2_msgs::msg::SmaccOrthogonal>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<smacc2_msgs::msg::SmaccOrthogonal>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<smacc2_msgs::msg::SmaccOrthogonal>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_ORTHOGONAL__TRAITS_HPP_
