// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from inspection_interfaces:msg/PlannerPoint.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_POINT__TRAITS_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_POINT__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "inspection_interfaces/msg/detail/planner_point__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'pose'
// Member 'gimbal_map_pose'
#include "geometry_msgs/msg/detail/pose_stamped__traits.hpp"
// Member 'gimbal_pose'
#include "geometry_msgs/msg/detail/quaternion_stamped__traits.hpp"

namespace inspection_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const PlannerPoint & msg,
  std::ostream & out)
{
  out << "{";
  // member: pose
  {
    out << "pose: ";
    to_flow_style_yaml(msg.pose, out);
    out << ", ";
  }

  // member: gimbal_pose
  {
    out << "gimbal_pose: ";
    to_flow_style_yaml(msg.gimbal_pose, out);
    out << ", ";
  }

  // member: gimbal_map_pose
  {
    out << "gimbal_map_pose: ";
    to_flow_style_yaml(msg.gimbal_map_pose, out);
    out << ", ";
  }

  // member: roll_clamp_difference
  {
    out << "roll_clamp_difference: ";
    rosidl_generator_traits::value_to_yaml(msg.roll_clamp_difference, out);
    out << ", ";
  }

  // member: action
  {
    out << "action: ";
    rosidl_generator_traits::value_to_yaml(msg.action, out);
    out << ", ";
  }

  // member: local_corrections
  {
    out << "local_corrections: ";
    rosidl_generator_traits::value_to_yaml(msg.local_corrections, out);
    out << ", ";
  }

  // member: blade_side
  {
    out << "blade_side: ";
    rosidl_generator_traits::value_to_yaml(msg.blade_side, out);
    out << ", ";
  }

  // member: motion_dir
  {
    out << "motion_dir: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_dir, out);
    out << ", ";
  }

  // member: blade_id
  {
    out << "blade_id: ";
    rosidl_generator_traits::value_to_yaml(msg.blade_id, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const PlannerPoint & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pose:\n";
    to_block_style_yaml(msg.pose, out, indentation + 2);
  }

  // member: gimbal_pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gimbal_pose:\n";
    to_block_style_yaml(msg.gimbal_pose, out, indentation + 2);
  }

  // member: gimbal_map_pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gimbal_map_pose:\n";
    to_block_style_yaml(msg.gimbal_map_pose, out, indentation + 2);
  }

  // member: roll_clamp_difference
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "roll_clamp_difference: ";
    rosidl_generator_traits::value_to_yaml(msg.roll_clamp_difference, out);
    out << "\n";
  }

  // member: action
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "action: ";
    rosidl_generator_traits::value_to_yaml(msg.action, out);
    out << "\n";
  }

  // member: local_corrections
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "local_corrections: ";
    rosidl_generator_traits::value_to_yaml(msg.local_corrections, out);
    out << "\n";
  }

  // member: blade_side
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "blade_side: ";
    rosidl_generator_traits::value_to_yaml(msg.blade_side, out);
    out << "\n";
  }

  // member: motion_dir
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motion_dir: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_dir, out);
    out << "\n";
  }

  // member: blade_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "blade_id: ";
    rosidl_generator_traits::value_to_yaml(msg.blade_id, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const PlannerPoint & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace inspection_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use inspection_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const inspection_interfaces::msg::PlannerPoint & msg,
  std::ostream & out, size_t indentation = 0)
{
  inspection_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use inspection_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const inspection_interfaces::msg::PlannerPoint & msg)
{
  return inspection_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<inspection_interfaces::msg::PlannerPoint>()
{
  return "inspection_interfaces::msg::PlannerPoint";
}

template<>
inline const char * name<inspection_interfaces::msg::PlannerPoint>()
{
  return "inspection_interfaces/msg/PlannerPoint";
}

template<>
struct has_fixed_size<inspection_interfaces::msg::PlannerPoint>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<inspection_interfaces::msg::PlannerPoint>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<inspection_interfaces::msg::PlannerPoint>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_POINT__TRAITS_HPP_
