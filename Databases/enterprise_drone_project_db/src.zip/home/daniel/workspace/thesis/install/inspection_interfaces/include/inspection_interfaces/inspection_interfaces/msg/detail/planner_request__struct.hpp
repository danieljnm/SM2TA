// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from inspection_interfaces:msg/PlannerRequest.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_REQUEST__STRUCT_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_REQUEST__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'current_pose'
#include "geometry_msgs/msg/detail/pose__struct.hpp"
// Member 'current_pos_global'
#include "sensor_msgs/msg/detail/nav_sat_fix__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__inspection_interfaces__msg__PlannerRequest __attribute__((deprecated))
#else
# define DEPRECATED__inspection_interfaces__msg__PlannerRequest __declspec(deprecated)
#endif

namespace inspection_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct PlannerRequest_
{
  using Type = PlannerRequest_<ContainerAllocator>;

  explicit PlannerRequest_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : current_pose(_init),
    current_pos_global(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->dist_blade_current = 0.0;
      this->dist_blade_target = 0.0;
      this->blade_length = 0.0;
      this->first_blade_rotation = 0.0;
      this->first_blade = 0;
      this->overlap_procentage = 0.0;
      this->hub_offset = 0.0;
      this->vertical_safety = 0.0;
      this->hub_center_px_x = 0ul;
      this->hub_center_px_y = 0ul;
    }
  }

  explicit PlannerRequest_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : current_pose(_alloc, _init),
    current_pos_global(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->dist_blade_current = 0.0;
      this->dist_blade_target = 0.0;
      this->blade_length = 0.0;
      this->first_blade_rotation = 0.0;
      this->first_blade = 0;
      this->overlap_procentage = 0.0;
      this->hub_offset = 0.0;
      this->vertical_safety = 0.0;
      this->hub_center_px_x = 0ul;
      this->hub_center_px_y = 0ul;
    }
  }

  // field types and members
  using _current_pose_type =
    geometry_msgs::msg::Pose_<ContainerAllocator>;
  _current_pose_type current_pose;
  using _current_pos_global_type =
    sensor_msgs::msg::NavSatFix_<ContainerAllocator>;
  _current_pos_global_type current_pos_global;
  using _dist_blade_current_type =
    double;
  _dist_blade_current_type dist_blade_current;
  using _dist_blade_target_type =
    double;
  _dist_blade_target_type dist_blade_target;
  using _blade_length_type =
    double;
  _blade_length_type blade_length;
  using _first_blade_rotation_type =
    double;
  _first_blade_rotation_type first_blade_rotation;
  using _first_blade_type =
    uint8_t;
  _first_blade_type first_blade;
  using _inspect_targets_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _inspect_targets_type inspect_targets;
  using _overlap_procentage_type =
    double;
  _overlap_procentage_type overlap_procentage;
  using _hub_offset_type =
    double;
  _hub_offset_type hub_offset;
  using _vertical_safety_type =
    double;
  _vertical_safety_type vertical_safety;
  using _hub_center_px_x_type =
    uint32_t;
  _hub_center_px_x_type hub_center_px_x;
  using _hub_center_px_y_type =
    uint32_t;
  _hub_center_px_y_type hub_center_px_y;

  // setters for named parameter idiom
  Type & set__current_pose(
    const geometry_msgs::msg::Pose_<ContainerAllocator> & _arg)
  {
    this->current_pose = _arg;
    return *this;
  }
  Type & set__current_pos_global(
    const sensor_msgs::msg::NavSatFix_<ContainerAllocator> & _arg)
  {
    this->current_pos_global = _arg;
    return *this;
  }
  Type & set__dist_blade_current(
    const double & _arg)
  {
    this->dist_blade_current = _arg;
    return *this;
  }
  Type & set__dist_blade_target(
    const double & _arg)
  {
    this->dist_blade_target = _arg;
    return *this;
  }
  Type & set__blade_length(
    const double & _arg)
  {
    this->blade_length = _arg;
    return *this;
  }
  Type & set__first_blade_rotation(
    const double & _arg)
  {
    this->first_blade_rotation = _arg;
    return *this;
  }
  Type & set__first_blade(
    const uint8_t & _arg)
  {
    this->first_blade = _arg;
    return *this;
  }
  Type & set__inspect_targets(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->inspect_targets = _arg;
    return *this;
  }
  Type & set__overlap_procentage(
    const double & _arg)
  {
    this->overlap_procentage = _arg;
    return *this;
  }
  Type & set__hub_offset(
    const double & _arg)
  {
    this->hub_offset = _arg;
    return *this;
  }
  Type & set__vertical_safety(
    const double & _arg)
  {
    this->vertical_safety = _arg;
    return *this;
  }
  Type & set__hub_center_px_x(
    const uint32_t & _arg)
  {
    this->hub_center_px_x = _arg;
    return *this;
  }
  Type & set__hub_center_px_y(
    const uint32_t & _arg)
  {
    this->hub_center_px_y = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    inspection_interfaces::msg::PlannerRequest_<ContainerAllocator> *;
  using ConstRawPtr =
    const inspection_interfaces::msg::PlannerRequest_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<inspection_interfaces::msg::PlannerRequest_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<inspection_interfaces::msg::PlannerRequest_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      inspection_interfaces::msg::PlannerRequest_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<inspection_interfaces::msg::PlannerRequest_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      inspection_interfaces::msg::PlannerRequest_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<inspection_interfaces::msg::PlannerRequest_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<inspection_interfaces::msg::PlannerRequest_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<inspection_interfaces::msg::PlannerRequest_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__inspection_interfaces__msg__PlannerRequest
    std::shared_ptr<inspection_interfaces::msg::PlannerRequest_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__inspection_interfaces__msg__PlannerRequest
    std::shared_ptr<inspection_interfaces::msg::PlannerRequest_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PlannerRequest_ & other) const
  {
    if (this->current_pose != other.current_pose) {
      return false;
    }
    if (this->current_pos_global != other.current_pos_global) {
      return false;
    }
    if (this->dist_blade_current != other.dist_blade_current) {
      return false;
    }
    if (this->dist_blade_target != other.dist_blade_target) {
      return false;
    }
    if (this->blade_length != other.blade_length) {
      return false;
    }
    if (this->first_blade_rotation != other.first_blade_rotation) {
      return false;
    }
    if (this->first_blade != other.first_blade) {
      return false;
    }
    if (this->inspect_targets != other.inspect_targets) {
      return false;
    }
    if (this->overlap_procentage != other.overlap_procentage) {
      return false;
    }
    if (this->hub_offset != other.hub_offset) {
      return false;
    }
    if (this->vertical_safety != other.vertical_safety) {
      return false;
    }
    if (this->hub_center_px_x != other.hub_center_px_x) {
      return false;
    }
    if (this->hub_center_px_y != other.hub_center_px_y) {
      return false;
    }
    return true;
  }
  bool operator!=(const PlannerRequest_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PlannerRequest_

// alias to use template instance with default allocator
using PlannerRequest =
  inspection_interfaces::msg::PlannerRequest_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace inspection_interfaces

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_REQUEST__STRUCT_HPP_
