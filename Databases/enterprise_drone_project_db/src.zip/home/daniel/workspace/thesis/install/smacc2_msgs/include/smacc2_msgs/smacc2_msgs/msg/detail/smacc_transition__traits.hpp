// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from smacc2_msgs:msg/SmaccTransition.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION__TRAITS_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "smacc2_msgs/msg/detail/smacc_transition__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'event'
#include "smacc2_msgs/msg/detail/smacc_event__traits.hpp"

namespace smacc2_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SmaccTransition & msg,
  std::ostream & out)
{
  out << "{";
  // member: index
  {
    out << "index: ";
    rosidl_generator_traits::value_to_yaml(msg.index, out);
    out << ", ";
  }

  // member: transition_name
  {
    out << "transition_name: ";
    rosidl_generator_traits::value_to_yaml(msg.transition_name, out);
    out << ", ";
  }

  // member: transition_type
  {
    out << "transition_type: ";
    rosidl_generator_traits::value_to_yaml(msg.transition_type, out);
    out << ", ";
  }

  // member: destiny_state_name
  {
    out << "destiny_state_name: ";
    rosidl_generator_traits::value_to_yaml(msg.destiny_state_name, out);
    out << ", ";
  }

  // member: source_state_name
  {
    out << "source_state_name: ";
    rosidl_generator_traits::value_to_yaml(msg.source_state_name, out);
    out << ", ";
  }

  // member: history_node
  {
    out << "history_node: ";
    rosidl_generator_traits::value_to_yaml(msg.history_node, out);
    out << ", ";
  }

  // member: event
  {
    out << "event: ";
    to_flow_style_yaml(msg.event, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SmaccTransition & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: index
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "index: ";
    rosidl_generator_traits::value_to_yaml(msg.index, out);
    out << "\n";
  }

  // member: transition_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "transition_name: ";
    rosidl_generator_traits::value_to_yaml(msg.transition_name, out);
    out << "\n";
  }

  // member: transition_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "transition_type: ";
    rosidl_generator_traits::value_to_yaml(msg.transition_type, out);
    out << "\n";
  }

  // member: destiny_state_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "destiny_state_name: ";
    rosidl_generator_traits::value_to_yaml(msg.destiny_state_name, out);
    out << "\n";
  }

  // member: source_state_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "source_state_name: ";
    rosidl_generator_traits::value_to_yaml(msg.source_state_name, out);
    out << "\n";
  }

  // member: history_node
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "history_node: ";
    rosidl_generator_traits::value_to_yaml(msg.history_node, out);
    out << "\n";
  }

  // member: event
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "event:\n";
    to_block_style_yaml(msg.event, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SmaccTransition & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace smacc2_msgs

namespace rosidl_generator_traits
{

[[deprecated("use smacc2_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const smacc2_msgs::msg::SmaccTransition & msg,
  std::ostream & out, size_t indentation = 0)
{
  smacc2_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use smacc2_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const smacc2_msgs::msg::SmaccTransition & msg)
{
  return smacc2_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<smacc2_msgs::msg::SmaccTransition>()
{
  return "smacc2_msgs::msg::SmaccTransition";
}

template<>
inline const char * name<smacc2_msgs::msg::SmaccTransition>()
{
  return "smacc2_msgs/msg/SmaccTransition";
}

template<>
struct has_fixed_size<smacc2_msgs::msg::SmaccTransition>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<smacc2_msgs::msg::SmaccTransition>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<smacc2_msgs::msg::SmaccTransition>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION__TRAITS_HPP_
