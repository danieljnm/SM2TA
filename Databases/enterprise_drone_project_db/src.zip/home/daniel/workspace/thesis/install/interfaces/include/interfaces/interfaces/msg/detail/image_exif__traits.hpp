// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from interfaces:msg/ImageExif.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__DETAIL__IMAGE_EXIF__TRAITS_HPP_
#define INTERFACES__MSG__DETAIL__IMAGE_EXIF__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "interfaces/msg/detail/image_exif__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'drone_pose'
#include "geometry_msgs/msg/detail/pose__traits.hpp"
// Member 'gimbal_orientation'
#include "geometry_msgs/msg/detail/quaternion__traits.hpp"
// Member 'hub_location'
#include "geometry_msgs/msg/detail/point__traits.hpp"
// Member 'lidar_frames'
#include "interfaces/msg/detail/lidar_frame_multi_array__traits.hpp"

namespace interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const ImageExif & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: file_name
  {
    out << "file_name: ";
    rosidl_generator_traits::value_to_yaml(msg.file_name, out);
    out << ", ";
  }

  // member: latitude
  {
    out << "latitude: ";
    rosidl_generator_traits::value_to_yaml(msg.latitude, out);
    out << ", ";
  }

  // member: longitude
  {
    out << "longitude: ";
    rosidl_generator_traits::value_to_yaml(msg.longitude, out);
    out << ", ";
  }

  // member: altitude_msl
  {
    out << "altitude_msl: ";
    rosidl_generator_traits::value_to_yaml(msg.altitude_msl, out);
    out << ", ";
  }

  // member: drone_pose
  {
    out << "drone_pose: ";
    to_flow_style_yaml(msg.drone_pose, out);
    out << ", ";
  }

  // member: gimbal_orientation
  {
    out << "gimbal_orientation: ";
    to_flow_style_yaml(msg.gimbal_orientation, out);
    out << ", ";
  }

  // member: hub_location
  {
    out << "hub_location: ";
    to_flow_style_yaml(msg.hub_location, out);
    out << ", ";
  }

  // member: sequence_direction
  {
    out << "sequence_direction: ";
    rosidl_generator_traits::value_to_yaml(msg.sequence_direction, out);
    out << ", ";
  }

  // member: blade_side
  {
    out << "blade_side: ";
    rosidl_generator_traits::value_to_yaml(msg.blade_side, out);
    out << ", ";
  }

  // member: blade_abc
  {
    out << "blade_abc: ";
    rosidl_generator_traits::value_to_yaml(msg.blade_abc, out);
    out << ", ";
  }

  // member: turbine_name
  {
    out << "turbine_name: ";
    rosidl_generator_traits::value_to_yaml(msg.turbine_name, out);
    out << ", ";
  }

  // member: inspection_id
  {
    out << "inspection_id: ";
    rosidl_generator_traits::value_to_yaml(msg.inspection_id, out);
    out << ", ";
  }

  // member: lidar_frames
  {
    out << "lidar_frames: ";
    to_flow_style_yaml(msg.lidar_frames, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ImageExif & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: file_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "file_name: ";
    rosidl_generator_traits::value_to_yaml(msg.file_name, out);
    out << "\n";
  }

  // member: latitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "latitude: ";
    rosidl_generator_traits::value_to_yaml(msg.latitude, out);
    out << "\n";
  }

  // member: longitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "longitude: ";
    rosidl_generator_traits::value_to_yaml(msg.longitude, out);
    out << "\n";
  }

  // member: altitude_msl
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "altitude_msl: ";
    rosidl_generator_traits::value_to_yaml(msg.altitude_msl, out);
    out << "\n";
  }

  // member: drone_pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "drone_pose:\n";
    to_block_style_yaml(msg.drone_pose, out, indentation + 2);
  }

  // member: gimbal_orientation
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gimbal_orientation:\n";
    to_block_style_yaml(msg.gimbal_orientation, out, indentation + 2);
  }

  // member: hub_location
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "hub_location:\n";
    to_block_style_yaml(msg.hub_location, out, indentation + 2);
  }

  // member: sequence_direction
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sequence_direction: ";
    rosidl_generator_traits::value_to_yaml(msg.sequence_direction, out);
    out << "\n";
  }

  // member: blade_side
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "blade_side: ";
    rosidl_generator_traits::value_to_yaml(msg.blade_side, out);
    out << "\n";
  }

  // member: blade_abc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "blade_abc: ";
    rosidl_generator_traits::value_to_yaml(msg.blade_abc, out);
    out << "\n";
  }

  // member: turbine_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "turbine_name: ";
    rosidl_generator_traits::value_to_yaml(msg.turbine_name, out);
    out << "\n";
  }

  // member: inspection_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "inspection_id: ";
    rosidl_generator_traits::value_to_yaml(msg.inspection_id, out);
    out << "\n";
  }

  // member: lidar_frames
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lidar_frames:\n";
    to_block_style_yaml(msg.lidar_frames, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ImageExif & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace interfaces

namespace rosidl_generator_traits
{

[[deprecated("use interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const interfaces::msg::ImageExif & msg,
  std::ostream & out, size_t indentation = 0)
{
  interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const interfaces::msg::ImageExif & msg)
{
  return interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<interfaces::msg::ImageExif>()
{
  return "interfaces::msg::ImageExif";
}

template<>
inline const char * name<interfaces::msg::ImageExif>()
{
  return "interfaces/msg/ImageExif";
}

template<>
struct has_fixed_size<interfaces::msg::ImageExif>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<interfaces::msg::ImageExif>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<interfaces::msg::ImageExif>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // INTERFACES__MSG__DETAIL__IMAGE_EXIF__TRAITS_HPP_
