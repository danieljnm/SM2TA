// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/GlobalPos.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__DETAIL__GLOBAL_POS__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__GLOBAL_POS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/global_pos__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_GlobalPos_gps_alt
{
public:
  explicit Init_GlobalPos_gps_alt(::interfaces::msg::GlobalPos & msg)
  : msg_(msg)
  {}
  ::interfaces::msg::GlobalPos gps_alt(::interfaces::msg::GlobalPos::_gps_alt_type arg)
  {
    msg_.gps_alt = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::GlobalPos msg_;
};

class Init_GlobalPos_lon
{
public:
  explicit Init_GlobalPos_lon(::interfaces::msg::GlobalPos & msg)
  : msg_(msg)
  {}
  Init_GlobalPos_gps_alt lon(::interfaces::msg::GlobalPos::_lon_type arg)
  {
    msg_.lon = std::move(arg);
    return Init_GlobalPos_gps_alt(msg_);
  }

private:
  ::interfaces::msg::GlobalPos msg_;
};

class Init_GlobalPos_lat
{
public:
  explicit Init_GlobalPos_lat(::interfaces::msg::GlobalPos & msg)
  : msg_(msg)
  {}
  Init_GlobalPos_lon lat(::interfaces::msg::GlobalPos::_lat_type arg)
  {
    msg_.lat = std::move(arg);
    return Init_GlobalPos_lon(msg_);
  }

private:
  ::interfaces::msg::GlobalPos msg_;
};

class Init_GlobalPos_header
{
public:
  Init_GlobalPos_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GlobalPos_lat header(::interfaces::msg::GlobalPos::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_GlobalPos_lat(msg_);
  }

private:
  ::interfaces::msg::GlobalPos msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::GlobalPos>()
{
  return interfaces::msg::builder::Init_GlobalPos_header();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__GLOBAL_POS__BUILDER_HPP_
