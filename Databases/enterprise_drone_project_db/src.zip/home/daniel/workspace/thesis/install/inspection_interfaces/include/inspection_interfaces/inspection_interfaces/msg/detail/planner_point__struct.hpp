// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from inspection_interfaces:msg/PlannerPoint.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_POINT__STRUCT_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_POINT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'pose'
// Member 'gimbal_map_pose'
#include "geometry_msgs/msg/detail/pose_stamped__struct.hpp"
// Member 'gimbal_pose'
#include "geometry_msgs/msg/detail/quaternion_stamped__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__inspection_interfaces__msg__PlannerPoint __attribute__((deprecated))
#else
# define DEPRECATED__inspection_interfaces__msg__PlannerPoint __declspec(deprecated)
#endif

namespace inspection_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct PlannerPoint_
{
  using Type = PlannerPoint_<ContainerAllocator>;

  explicit PlannerPoint_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pose(_init),
    gimbal_pose(_init),
    gimbal_map_pose(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->local_corrections = true;
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->roll_clamp_difference = 0.0;
      this->action = 0l;
      this->local_corrections = false;
      this->blade_side = "";
      this->motion_dir = "";
      this->blade_id = "";
    }
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->roll_clamp_difference = 0.0;
      this->action = 0l;
      this->blade_side = "";
      this->motion_dir = "";
      this->blade_id = "";
    }
  }

  explicit PlannerPoint_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pose(_alloc, _init),
    gimbal_pose(_alloc, _init),
    gimbal_map_pose(_alloc, _init),
    blade_side(_alloc),
    motion_dir(_alloc),
    blade_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->local_corrections = true;
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->roll_clamp_difference = 0.0;
      this->action = 0l;
      this->local_corrections = false;
      this->blade_side = "";
      this->motion_dir = "";
      this->blade_id = "";
    }
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->roll_clamp_difference = 0.0;
      this->action = 0l;
      this->blade_side = "";
      this->motion_dir = "";
      this->blade_id = "";
    }
  }

  // field types and members
  using _pose_type =
    geometry_msgs::msg::PoseStamped_<ContainerAllocator>;
  _pose_type pose;
  using _gimbal_pose_type =
    geometry_msgs::msg::QuaternionStamped_<ContainerAllocator>;
  _gimbal_pose_type gimbal_pose;
  using _gimbal_map_pose_type =
    geometry_msgs::msg::PoseStamped_<ContainerAllocator>;
  _gimbal_map_pose_type gimbal_map_pose;
  using _roll_clamp_difference_type =
    double;
  _roll_clamp_difference_type roll_clamp_difference;
  using _action_type =
    int32_t;
  _action_type action;
  using _local_corrections_type =
    bool;
  _local_corrections_type local_corrections;
  using _blade_side_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _blade_side_type blade_side;
  using _motion_dir_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _motion_dir_type motion_dir;
  using _blade_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _blade_id_type blade_id;

  // setters for named parameter idiom
  Type & set__pose(
    const geometry_msgs::msg::PoseStamped_<ContainerAllocator> & _arg)
  {
    this->pose = _arg;
    return *this;
  }
  Type & set__gimbal_pose(
    const geometry_msgs::msg::QuaternionStamped_<ContainerAllocator> & _arg)
  {
    this->gimbal_pose = _arg;
    return *this;
  }
  Type & set__gimbal_map_pose(
    const geometry_msgs::msg::PoseStamped_<ContainerAllocator> & _arg)
  {
    this->gimbal_map_pose = _arg;
    return *this;
  }
  Type & set__roll_clamp_difference(
    const double & _arg)
  {
    this->roll_clamp_difference = _arg;
    return *this;
  }
  Type & set__action(
    const int32_t & _arg)
  {
    this->action = _arg;
    return *this;
  }
  Type & set__local_corrections(
    const bool & _arg)
  {
    this->local_corrections = _arg;
    return *this;
  }
  Type & set__blade_side(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->blade_side = _arg;
    return *this;
  }
  Type & set__motion_dir(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->motion_dir = _arg;
    return *this;
  }
  Type & set__blade_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->blade_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    inspection_interfaces::msg::PlannerPoint_<ContainerAllocator> *;
  using ConstRawPtr =
    const inspection_interfaces::msg::PlannerPoint_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      inspection_interfaces::msg::PlannerPoint_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      inspection_interfaces::msg::PlannerPoint_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__inspection_interfaces__msg__PlannerPoint
    std::shared_ptr<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__inspection_interfaces__msg__PlannerPoint
    std::shared_ptr<inspection_interfaces::msg::PlannerPoint_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PlannerPoint_ & other) const
  {
    if (this->pose != other.pose) {
      return false;
    }
    if (this->gimbal_pose != other.gimbal_pose) {
      return false;
    }
    if (this->gimbal_map_pose != other.gimbal_map_pose) {
      return false;
    }
    if (this->roll_clamp_difference != other.roll_clamp_difference) {
      return false;
    }
    if (this->action != other.action) {
      return false;
    }
    if (this->local_corrections != other.local_corrections) {
      return false;
    }
    if (this->blade_side != other.blade_side) {
      return false;
    }
    if (this->motion_dir != other.motion_dir) {
      return false;
    }
    if (this->blade_id != other.blade_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const PlannerPoint_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PlannerPoint_

// alias to use template instance with default allocator
using PlannerPoint =
  inspection_interfaces::msg::PlannerPoint_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace inspection_interfaces

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_POINT__STRUCT_HPP_
