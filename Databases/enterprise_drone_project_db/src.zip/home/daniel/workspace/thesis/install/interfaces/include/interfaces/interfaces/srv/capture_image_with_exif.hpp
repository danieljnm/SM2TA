// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__SRV__CAPTURE_IMAGE_WITH_EXIF_HPP_
#define INTERFACES__SRV__CAPTURE_IMAGE_WITH_EXIF_HPP_

#include "interfaces/srv/detail/capture_image_with_exif__struct.hpp"
#include "interfaces/srv/detail/capture_image_with_exif__builder.hpp"
#include "interfaces/srv/detail/capture_image_with_exif__traits.hpp"
#include "interfaces/srv/detail/capture_image_with_exif__type_support.hpp"

#endif  // INTERFACES__SRV__CAPTURE_IMAGE_WITH_EXIF_HPP_
