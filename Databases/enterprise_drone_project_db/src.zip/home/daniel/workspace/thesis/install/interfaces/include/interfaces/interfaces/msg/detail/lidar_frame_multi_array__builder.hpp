// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/LidarFrameMultiArray.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__DETAIL__LIDAR_FRAME_MULTI_ARRAY__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__LIDAR_FRAME_MULTI_ARRAY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/lidar_frame_multi_array__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_LidarFrameMultiArray_lidar_frames
{
public:
  Init_LidarFrameMultiArray_lidar_frames()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::interfaces::msg::LidarFrameMultiArray lidar_frames(::interfaces::msg::LidarFrameMultiArray::_lidar_frames_type arg)
  {
    msg_.lidar_frames = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::LidarFrameMultiArray msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::LidarFrameMultiArray>()
{
  return interfaces::msg::builder::Init_LidarFrameMultiArray_lidar_frames();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__LIDAR_FRAME_MULTI_ARRAY__BUILDER_HPP_
