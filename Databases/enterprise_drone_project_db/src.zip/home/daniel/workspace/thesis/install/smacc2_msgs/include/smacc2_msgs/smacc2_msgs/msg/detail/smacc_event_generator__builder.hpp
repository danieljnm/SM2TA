// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from smacc2_msgs:msg/SmaccEventGenerator.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_EVENT_GENERATOR__BUILDER_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_EVENT_GENERATOR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "smacc2_msgs/msg/detail/smacc_event_generator__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace smacc2_msgs
{

namespace msg
{

namespace builder
{

class Init_SmaccEventGenerator_object_tag
{
public:
  explicit Init_SmaccEventGenerator_object_tag(::smacc2_msgs::msg::SmaccEventGenerator & msg)
  : msg_(msg)
  {}
  ::smacc2_msgs::msg::SmaccEventGenerator object_tag(::smacc2_msgs::msg::SmaccEventGenerator::_object_tag_type arg)
  {
    msg_.object_tag = std::move(arg);
    return std::move(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccEventGenerator msg_;
};

class Init_SmaccEventGenerator_type_name
{
public:
  explicit Init_SmaccEventGenerator_type_name(::smacc2_msgs::msg::SmaccEventGenerator & msg)
  : msg_(msg)
  {}
  Init_SmaccEventGenerator_object_tag type_name(::smacc2_msgs::msg::SmaccEventGenerator::_type_name_type arg)
  {
    msg_.type_name = std::move(arg);
    return Init_SmaccEventGenerator_object_tag(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccEventGenerator msg_;
};

class Init_SmaccEventGenerator_index
{
public:
  Init_SmaccEventGenerator_index()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SmaccEventGenerator_type_name index(::smacc2_msgs::msg::SmaccEventGenerator::_index_type arg)
  {
    msg_.index = std::move(arg);
    return Init_SmaccEventGenerator_type_name(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccEventGenerator msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::smacc2_msgs::msg::SmaccEventGenerator>()
{
  return smacc2_msgs::msg::builder::Init_SmaccEventGenerator_index();
}

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_EVENT_GENERATOR__BUILDER_HPP_
