// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from inspection_interfaces:msg/PlannerResult.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_RESULT__BUILDER_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_RESULT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "inspection_interfaces/msg/detail/planner_result__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace inspection_interfaces
{

namespace msg
{

namespace builder
{

class Init_PlannerResult_global_init_alt
{
public:
  explicit Init_PlannerResult_global_init_alt(::inspection_interfaces::msg::PlannerResult & msg)
  : msg_(msg)
  {}
  ::inspection_interfaces::msg::PlannerResult global_init_alt(::inspection_interfaces::msg::PlannerResult::_global_init_alt_type arg)
  {
    msg_.global_init_alt = std::move(arg);
    return std::move(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerResult msg_;
};

class Init_PlannerResult_global_init_lon
{
public:
  explicit Init_PlannerResult_global_init_lon(::inspection_interfaces::msg::PlannerResult & msg)
  : msg_(msg)
  {}
  Init_PlannerResult_global_init_alt global_init_lon(::inspection_interfaces::msg::PlannerResult::_global_init_lon_type arg)
  {
    msg_.global_init_lon = std::move(arg);
    return Init_PlannerResult_global_init_alt(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerResult msg_;
};

class Init_PlannerResult_global_init_lat
{
public:
  explicit Init_PlannerResult_global_init_lat(::inspection_interfaces::msg::PlannerResult & msg)
  : msg_(msg)
  {}
  Init_PlannerResult_global_init_lon global_init_lat(::inspection_interfaces::msg::PlannerResult::_global_init_lat_type arg)
  {
    msg_.global_init_lat = std::move(arg);
    return Init_PlannerResult_global_init_lon(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerResult msg_;
};

class Init_PlannerResult_local_hub_init_pose
{
public:
  explicit Init_PlannerResult_local_hub_init_pose(::inspection_interfaces::msg::PlannerResult & msg)
  : msg_(msg)
  {}
  Init_PlannerResult_global_init_lat local_hub_init_pose(::inspection_interfaces::msg::PlannerResult::_local_hub_init_pose_type arg)
  {
    msg_.local_hub_init_pose = std::move(arg);
    return Init_PlannerResult_global_init_lat(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerResult msg_;
};

class Init_PlannerResult_plan
{
public:
  Init_PlannerResult_plan()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PlannerResult_local_hub_init_pose plan(::inspection_interfaces::msg::PlannerResult::_plan_type arg)
  {
    msg_.plan = std::move(arg);
    return Init_PlannerResult_local_hub_init_pose(msg_);
  }

private:
  ::inspection_interfaces::msg::PlannerResult msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::inspection_interfaces::msg::PlannerResult>()
{
  return inspection_interfaces::msg::builder::Init_PlannerResult_plan();
}

}  // namespace inspection_interfaces

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__PLANNER_RESULT__BUILDER_HPP_
