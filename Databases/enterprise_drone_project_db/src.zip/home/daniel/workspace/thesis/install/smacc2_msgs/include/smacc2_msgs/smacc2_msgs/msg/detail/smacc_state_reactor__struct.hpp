// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from smacc2_msgs:msg/SmaccStateReactor.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_STATE_REACTOR__STRUCT_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_STATE_REACTOR__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'event_sources'
#include "smacc2_msgs/msg/detail/smacc_event__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__smacc2_msgs__msg__SmaccStateReactor __attribute__((deprecated))
#else
# define DEPRECATED__smacc2_msgs__msg__SmaccStateReactor __declspec(deprecated)
#endif

namespace smacc2_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SmaccStateReactor_
{
  using Type = SmaccStateReactor_<ContainerAllocator>;

  explicit SmaccStateReactor_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->index = 0l;
      this->type_name = "";
      this->object_tag = "";
    }
  }

  explicit SmaccStateReactor_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : type_name(_alloc),
    object_tag(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->index = 0l;
      this->type_name = "";
      this->object_tag = "";
    }
  }

  // field types and members
  using _index_type =
    int32_t;
  _index_type index;
  using _type_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _type_name_type type_name;
  using _object_tag_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _object_tag_type object_tag;
  using _event_sources_type =
    std::vector<smacc2_msgs::msg::SmaccEvent_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<smacc2_msgs::msg::SmaccEvent_<ContainerAllocator>>>;
  _event_sources_type event_sources;

  // setters for named parameter idiom
  Type & set__index(
    const int32_t & _arg)
  {
    this->index = _arg;
    return *this;
  }
  Type & set__type_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->type_name = _arg;
    return *this;
  }
  Type & set__object_tag(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->object_tag = _arg;
    return *this;
  }
  Type & set__event_sources(
    const std::vector<smacc2_msgs::msg::SmaccEvent_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<smacc2_msgs::msg::SmaccEvent_<ContainerAllocator>>> & _arg)
  {
    this->event_sources = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator> *;
  using ConstRawPtr =
    const smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__smacc2_msgs__msg__SmaccStateReactor
    std::shared_ptr<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__smacc2_msgs__msg__SmaccStateReactor
    std::shared_ptr<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SmaccStateReactor_ & other) const
  {
    if (this->index != other.index) {
      return false;
    }
    if (this->type_name != other.type_name) {
      return false;
    }
    if (this->object_tag != other.object_tag) {
      return false;
    }
    if (this->event_sources != other.event_sources) {
      return false;
    }
    return true;
  }
  bool operator!=(const SmaccStateReactor_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SmaccStateReactor_

// alias to use template instance with default allocator
using SmaccStateReactor =
  smacc2_msgs::msg::SmaccStateReactor_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_STATE_REACTOR__STRUCT_HPP_
