// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from inspection_interfaces:msg/Trajectory.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__TRAJECTORY__TYPE_SUPPORT_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__TRAJECTORY__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "inspection_interfaces/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_inspection_interfaces
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  inspection_interfaces,
  msg,
  Trajectory
)();
#ifdef __cplusplus
}
#endif

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__TRAJECTORY__TYPE_SUPPORT_HPP_
