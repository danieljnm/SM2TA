// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from interfaces:msg/ImageExif.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__DETAIL__IMAGE_EXIF__STRUCT_HPP_
#define INTERFACES__MSG__DETAIL__IMAGE_EXIF__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'drone_pose'
#include "geometry_msgs/msg/detail/pose__struct.hpp"
// Member 'gimbal_orientation'
#include "geometry_msgs/msg/detail/quaternion__struct.hpp"
// Member 'hub_location'
#include "geometry_msgs/msg/detail/point__struct.hpp"
// Member 'lidar_frames'
#include "interfaces/msg/detail/lidar_frame_multi_array__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__interfaces__msg__ImageExif __attribute__((deprecated))
#else
# define DEPRECATED__interfaces__msg__ImageExif __declspec(deprecated)
#endif

namespace interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ImageExif_
{
  using Type = ImageExif_<ContainerAllocator>;

  explicit ImageExif_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    drone_pose(_init),
    gimbal_orientation(_init),
    hub_location(_init),
    lidar_frames(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->file_name = "";
      this->latitude = 0.0;
      this->longitude = 0.0;
      this->altitude_msl = 0.0;
      this->sequence_direction = "";
      this->blade_side = "";
      this->blade_abc = "";
      this->turbine_name = "";
      this->inspection_id = "";
    }
  }

  explicit ImageExif_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    file_name(_alloc),
    drone_pose(_alloc, _init),
    gimbal_orientation(_alloc, _init),
    hub_location(_alloc, _init),
    sequence_direction(_alloc),
    blade_side(_alloc),
    blade_abc(_alloc),
    turbine_name(_alloc),
    inspection_id(_alloc),
    lidar_frames(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->file_name = "";
      this->latitude = 0.0;
      this->longitude = 0.0;
      this->altitude_msl = 0.0;
      this->sequence_direction = "";
      this->blade_side = "";
      this->blade_abc = "";
      this->turbine_name = "";
      this->inspection_id = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _file_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _file_name_type file_name;
  using _latitude_type =
    double;
  _latitude_type latitude;
  using _longitude_type =
    double;
  _longitude_type longitude;
  using _altitude_msl_type =
    double;
  _altitude_msl_type altitude_msl;
  using _drone_pose_type =
    geometry_msgs::msg::Pose_<ContainerAllocator>;
  _drone_pose_type drone_pose;
  using _gimbal_orientation_type =
    geometry_msgs::msg::Quaternion_<ContainerAllocator>;
  _gimbal_orientation_type gimbal_orientation;
  using _hub_location_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _hub_location_type hub_location;
  using _sequence_direction_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _sequence_direction_type sequence_direction;
  using _blade_side_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _blade_side_type blade_side;
  using _blade_abc_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _blade_abc_type blade_abc;
  using _turbine_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _turbine_name_type turbine_name;
  using _inspection_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _inspection_id_type inspection_id;
  using _lidar_frames_type =
    interfaces::msg::LidarFrameMultiArray_<ContainerAllocator>;
  _lidar_frames_type lidar_frames;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__file_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->file_name = _arg;
    return *this;
  }
  Type & set__latitude(
    const double & _arg)
  {
    this->latitude = _arg;
    return *this;
  }
  Type & set__longitude(
    const double & _arg)
  {
    this->longitude = _arg;
    return *this;
  }
  Type & set__altitude_msl(
    const double & _arg)
  {
    this->altitude_msl = _arg;
    return *this;
  }
  Type & set__drone_pose(
    const geometry_msgs::msg::Pose_<ContainerAllocator> & _arg)
  {
    this->drone_pose = _arg;
    return *this;
  }
  Type & set__gimbal_orientation(
    const geometry_msgs::msg::Quaternion_<ContainerAllocator> & _arg)
  {
    this->gimbal_orientation = _arg;
    return *this;
  }
  Type & set__hub_location(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->hub_location = _arg;
    return *this;
  }
  Type & set__sequence_direction(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->sequence_direction = _arg;
    return *this;
  }
  Type & set__blade_side(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->blade_side = _arg;
    return *this;
  }
  Type & set__blade_abc(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->blade_abc = _arg;
    return *this;
  }
  Type & set__turbine_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->turbine_name = _arg;
    return *this;
  }
  Type & set__inspection_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->inspection_id = _arg;
    return *this;
  }
  Type & set__lidar_frames(
    const interfaces::msg::LidarFrameMultiArray_<ContainerAllocator> & _arg)
  {
    this->lidar_frames = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    interfaces::msg::ImageExif_<ContainerAllocator> *;
  using ConstRawPtr =
    const interfaces::msg::ImageExif_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<interfaces::msg::ImageExif_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<interfaces::msg::ImageExif_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::ImageExif_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::ImageExif_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::ImageExif_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::ImageExif_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<interfaces::msg::ImageExif_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<interfaces::msg::ImageExif_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__interfaces__msg__ImageExif
    std::shared_ptr<interfaces::msg::ImageExif_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__interfaces__msg__ImageExif
    std::shared_ptr<interfaces::msg::ImageExif_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ImageExif_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->file_name != other.file_name) {
      return false;
    }
    if (this->latitude != other.latitude) {
      return false;
    }
    if (this->longitude != other.longitude) {
      return false;
    }
    if (this->altitude_msl != other.altitude_msl) {
      return false;
    }
    if (this->drone_pose != other.drone_pose) {
      return false;
    }
    if (this->gimbal_orientation != other.gimbal_orientation) {
      return false;
    }
    if (this->hub_location != other.hub_location) {
      return false;
    }
    if (this->sequence_direction != other.sequence_direction) {
      return false;
    }
    if (this->blade_side != other.blade_side) {
      return false;
    }
    if (this->blade_abc != other.blade_abc) {
      return false;
    }
    if (this->turbine_name != other.turbine_name) {
      return false;
    }
    if (this->inspection_id != other.inspection_id) {
      return false;
    }
    if (this->lidar_frames != other.lidar_frames) {
      return false;
    }
    return true;
  }
  bool operator!=(const ImageExif_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ImageExif_

// alias to use template instance with default allocator
using ImageExif =
  interfaces::msg::ImageExif_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__IMAGE_EXIF__STRUCT_HPP_
