// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from smacc2_msgs:msg/SmaccOrthogonal.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_ORTHOGONAL__BUILDER_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_ORTHOGONAL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "smacc2_msgs/msg/detail/smacc_orthogonal__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace smacc2_msgs
{

namespace msg
{

namespace builder
{

class Init_SmaccOrthogonal_client_names
{
public:
  explicit Init_SmaccOrthogonal_client_names(::smacc2_msgs::msg::SmaccOrthogonal & msg)
  : msg_(msg)
  {}
  ::smacc2_msgs::msg::SmaccOrthogonal client_names(::smacc2_msgs::msg::SmaccOrthogonal::_client_names_type arg)
  {
    msg_.client_names = std::move(arg);
    return std::move(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccOrthogonal msg_;
};

class Init_SmaccOrthogonal_client_behavior_names
{
public:
  explicit Init_SmaccOrthogonal_client_behavior_names(::smacc2_msgs::msg::SmaccOrthogonal & msg)
  : msg_(msg)
  {}
  Init_SmaccOrthogonal_client_names client_behavior_names(::smacc2_msgs::msg::SmaccOrthogonal::_client_behavior_names_type arg)
  {
    msg_.client_behavior_names = std::move(arg);
    return Init_SmaccOrthogonal_client_names(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccOrthogonal msg_;
};

class Init_SmaccOrthogonal_name
{
public:
  Init_SmaccOrthogonal_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SmaccOrthogonal_client_behavior_names name(::smacc2_msgs::msg::SmaccOrthogonal::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_SmaccOrthogonal_client_behavior_names(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccOrthogonal msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::smacc2_msgs::msg::SmaccOrthogonal>()
{
  return smacc2_msgs::msg::builder::Init_SmaccOrthogonal_name();
}

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_ORTHOGONAL__BUILDER_HPP_
