// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from inspection_interfaces:msg/TurbinePose.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__TURBINE_POSE__STRUCT_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__TURBINE_POSE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__inspection_interfaces__msg__TurbinePose __attribute__((deprecated))
#else
# define DEPRECATED__inspection_interfaces__msg__TurbinePose __declspec(deprecated)
#endif

namespace inspection_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct TurbinePose_
{
  using Type = TurbinePose_<ContainerAllocator>;

  explicit TurbinePose_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->first_blade_rotation = 0.0;
      this->pixel_center_x = 0.0;
      this->pixel_center_y = 0.0;
      this->current_distance_lidar = 0.0;
    }
  }

  explicit TurbinePose_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->first_blade_rotation = 0.0;
      this->pixel_center_x = 0.0;
      this->pixel_center_y = 0.0;
      this->current_distance_lidar = 0.0;
    }
  }

  // field types and members
  using _first_blade_rotation_type =
    double;
  _first_blade_rotation_type first_blade_rotation;
  using _pixel_center_x_type =
    double;
  _pixel_center_x_type pixel_center_x;
  using _pixel_center_y_type =
    double;
  _pixel_center_y_type pixel_center_y;
  using _current_distance_lidar_type =
    double;
  _current_distance_lidar_type current_distance_lidar;

  // setters for named parameter idiom
  Type & set__first_blade_rotation(
    const double & _arg)
  {
    this->first_blade_rotation = _arg;
    return *this;
  }
  Type & set__pixel_center_x(
    const double & _arg)
  {
    this->pixel_center_x = _arg;
    return *this;
  }
  Type & set__pixel_center_y(
    const double & _arg)
  {
    this->pixel_center_y = _arg;
    return *this;
  }
  Type & set__current_distance_lidar(
    const double & _arg)
  {
    this->current_distance_lidar = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    inspection_interfaces::msg::TurbinePose_<ContainerAllocator> *;
  using ConstRawPtr =
    const inspection_interfaces::msg::TurbinePose_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<inspection_interfaces::msg::TurbinePose_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<inspection_interfaces::msg::TurbinePose_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      inspection_interfaces::msg::TurbinePose_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<inspection_interfaces::msg::TurbinePose_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      inspection_interfaces::msg::TurbinePose_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<inspection_interfaces::msg::TurbinePose_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<inspection_interfaces::msg::TurbinePose_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<inspection_interfaces::msg::TurbinePose_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__inspection_interfaces__msg__TurbinePose
    std::shared_ptr<inspection_interfaces::msg::TurbinePose_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__inspection_interfaces__msg__TurbinePose
    std::shared_ptr<inspection_interfaces::msg::TurbinePose_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const TurbinePose_ & other) const
  {
    if (this->first_blade_rotation != other.first_blade_rotation) {
      return false;
    }
    if (this->pixel_center_x != other.pixel_center_x) {
      return false;
    }
    if (this->pixel_center_y != other.pixel_center_y) {
      return false;
    }
    if (this->current_distance_lidar != other.current_distance_lidar) {
      return false;
    }
    return true;
  }
  bool operator!=(const TurbinePose_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct TurbinePose_

// alias to use template instance with default allocator
using TurbinePose =
  inspection_interfaces::msg::TurbinePose_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace inspection_interfaces

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__TURBINE_POSE__STRUCT_HPP_
