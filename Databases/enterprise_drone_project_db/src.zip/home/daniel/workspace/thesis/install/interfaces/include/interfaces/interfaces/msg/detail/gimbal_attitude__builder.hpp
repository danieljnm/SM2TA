// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:msg/GimbalAttitude.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__DETAIL__GIMBAL_ATTITUDE__BUILDER_HPP_
#define INTERFACES__MSG__DETAIL__GIMBAL_ATTITUDE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/msg/detail/gimbal_attitude__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace msg
{

namespace builder
{

class Init_GimbalAttitude_gimbal_device_id
{
public:
  explicit Init_GimbalAttitude_gimbal_device_id(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  ::interfaces::msg::GimbalAttitude gimbal_device_id(::interfaces::msg::GimbalAttitude::_gimbal_device_id_type arg)
  {
    msg_.gimbal_device_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_failure_flags
{
public:
  explicit Init_GimbalAttitude_failure_flags(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_gimbal_device_id failure_flags(::interfaces::msg::GimbalAttitude::_failure_flags_type arg)
  {
    msg_.failure_flags = std::move(arg);
    return Init_GimbalAttitude_gimbal_device_id(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_angular_velocity_z
{
public:
  explicit Init_GimbalAttitude_angular_velocity_z(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_failure_flags angular_velocity_z(::interfaces::msg::GimbalAttitude::_angular_velocity_z_type arg)
  {
    msg_.angular_velocity_z = std::move(arg);
    return Init_GimbalAttitude_failure_flags(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_angular_velocity_y
{
public:
  explicit Init_GimbalAttitude_angular_velocity_y(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_angular_velocity_z angular_velocity_y(::interfaces::msg::GimbalAttitude::_angular_velocity_y_type arg)
  {
    msg_.angular_velocity_y = std::move(arg);
    return Init_GimbalAttitude_angular_velocity_z(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_angular_velocity_x
{
public:
  explicit Init_GimbalAttitude_angular_velocity_x(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_angular_velocity_y angular_velocity_x(::interfaces::msg::GimbalAttitude::_angular_velocity_x_type arg)
  {
    msg_.angular_velocity_x = std::move(arg);
    return Init_GimbalAttitude_angular_velocity_y(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_yaw
{
public:
  explicit Init_GimbalAttitude_yaw(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_angular_velocity_x yaw(::interfaces::msg::GimbalAttitude::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_GimbalAttitude_angular_velocity_x(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_pitch
{
public:
  explicit Init_GimbalAttitude_pitch(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_yaw pitch(::interfaces::msg::GimbalAttitude::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_GimbalAttitude_yaw(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_roll
{
public:
  explicit Init_GimbalAttitude_roll(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_pitch roll(::interfaces::msg::GimbalAttitude::_roll_type arg)
  {
    msg_.roll = std::move(arg);
    return Init_GimbalAttitude_pitch(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_orientation
{
public:
  explicit Init_GimbalAttitude_orientation(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_roll orientation(::interfaces::msg::GimbalAttitude::_orientation_type arg)
  {
    msg_.orientation = std::move(arg);
    return Init_GimbalAttitude_roll(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_flags
{
public:
  explicit Init_GimbalAttitude_flags(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_orientation flags(::interfaces::msg::GimbalAttitude::_flags_type arg)
  {
    msg_.flags = std::move(arg);
    return Init_GimbalAttitude_orientation(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_time_boot_ms
{
public:
  explicit Init_GimbalAttitude_time_boot_ms(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_flags time_boot_ms(::interfaces::msg::GimbalAttitude::_time_boot_ms_type arg)
  {
    msg_.time_boot_ms = std::move(arg);
    return Init_GimbalAttitude_flags(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_target_component
{
public:
  explicit Init_GimbalAttitude_target_component(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_time_boot_ms target_component(::interfaces::msg::GimbalAttitude::_target_component_type arg)
  {
    msg_.target_component = std::move(arg);
    return Init_GimbalAttitude_time_boot_ms(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_target_system
{
public:
  explicit Init_GimbalAttitude_target_system(::interfaces::msg::GimbalAttitude & msg)
  : msg_(msg)
  {}
  Init_GimbalAttitude_target_component target_system(::interfaces::msg::GimbalAttitude::_target_system_type arg)
  {
    msg_.target_system = std::move(arg);
    return Init_GimbalAttitude_target_component(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

class Init_GimbalAttitude_header
{
public:
  Init_GimbalAttitude_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GimbalAttitude_target_system header(::interfaces::msg::GimbalAttitude::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_GimbalAttitude_target_system(msg_);
  }

private:
  ::interfaces::msg::GimbalAttitude msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::msg::GimbalAttitude>()
{
  return interfaces::msg::builder::Init_GimbalAttitude_header();
}

}  // namespace interfaces

#endif  // INTERFACES__MSG__DETAIL__GIMBAL_ATTITUDE__BUILDER_HPP_
