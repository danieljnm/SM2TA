// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__TURBINE_POSE_HPP_
#define INSPECTION_INTERFACES__MSG__TURBINE_POSE_HPP_

#include "inspection_interfaces/msg/detail/turbine_pose__struct.hpp"
#include "inspection_interfaces/msg/detail/turbine_pose__builder.hpp"
#include "inspection_interfaces/msg/detail/turbine_pose__traits.hpp"
#include "inspection_interfaces/msg/detail/turbine_pose__type_support.hpp"

#endif  // INSPECTION_INTERFACES__MSG__TURBINE_POSE_HPP_
