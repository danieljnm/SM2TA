// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from inspection_interfaces:msg/Trajectory.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__TRAJECTORY__BUILDER_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__TRAJECTORY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "inspection_interfaces/msg/detail/trajectory__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace inspection_interfaces
{

namespace msg
{

namespace builder
{

class Init_Trajectory_mission_index
{
public:
  explicit Init_Trajectory_mission_index(::inspection_interfaces::msg::Trajectory & msg)
  : msg_(msg)
  {}
  ::inspection_interfaces::msg::Trajectory mission_index(::inspection_interfaces::msg::Trajectory::_mission_index_type arg)
  {
    msg_.mission_index = std::move(arg);
    return std::move(msg_);
  }

private:
  ::inspection_interfaces::msg::Trajectory msg_;
};

class Init_Trajectory_points
{
public:
  Init_Trajectory_points()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Trajectory_mission_index points(::inspection_interfaces::msg::Trajectory::_points_type arg)
  {
    msg_.points = std::move(arg);
    return Init_Trajectory_mission_index(msg_);
  }

private:
  ::inspection_interfaces::msg::Trajectory msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::inspection_interfaces::msg::Trajectory>()
{
  return inspection_interfaces::msg::builder::Init_Trajectory_points();
}

}  // namespace inspection_interfaces

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__TRAJECTORY__BUILDER_HPP_
