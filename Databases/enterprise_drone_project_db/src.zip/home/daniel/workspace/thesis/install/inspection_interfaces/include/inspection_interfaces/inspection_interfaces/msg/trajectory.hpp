// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__TRAJECTORY_HPP_
#define INSPECTION_INTERFACES__MSG__TRAJECTORY_HPP_

#include "inspection_interfaces/msg/detail/trajectory__struct.hpp"
#include "inspection_interfaces/msg/detail/trajectory__builder.hpp"
#include "inspection_interfaces/msg/detail/trajectory__traits.hpp"
#include "inspection_interfaces/msg/detail/trajectory__type_support.hpp"

#endif  // INSPECTION_INTERFACES__MSG__TRAJECTORY_HPP_
