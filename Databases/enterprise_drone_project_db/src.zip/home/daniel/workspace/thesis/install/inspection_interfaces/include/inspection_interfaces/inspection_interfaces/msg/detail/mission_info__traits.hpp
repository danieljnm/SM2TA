// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from inspection_interfaces:msg/MissionInfo.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__MISSION_INFO__TRAITS_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__MISSION_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "inspection_interfaces/msg/detail/mission_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace inspection_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const MissionInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: dist_blade_target
  {
    out << "dist_blade_target: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_blade_target, out);
    out << ", ";
  }

  // member: blade_length
  {
    out << "blade_length: ";
    rosidl_generator_traits::value_to_yaml(msg.blade_length, out);
    out << ", ";
  }

  // member: first_blade
  {
    out << "first_blade: ";
    rosidl_generator_traits::value_to_yaml(msg.first_blade, out);
    out << ", ";
  }

  // member: inspect_targets
  {
    if (msg.inspect_targets.size() == 0) {
      out << "inspect_targets: []";
    } else {
      out << "inspect_targets: [";
      size_t pending_items = msg.inspect_targets.size();
      for (auto item : msg.inspect_targets) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: overlap_procentage
  {
    out << "overlap_procentage: ";
    rosidl_generator_traits::value_to_yaml(msg.overlap_procentage, out);
    out << ", ";
  }

  // member: hub_offset
  {
    out << "hub_offset: ";
    rosidl_generator_traits::value_to_yaml(msg.hub_offset, out);
    out << ", ";
  }

  // member: vertical_safety
  {
    out << "vertical_safety: ";
    rosidl_generator_traits::value_to_yaml(msg.vertical_safety, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MissionInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: dist_blade_target
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dist_blade_target: ";
    rosidl_generator_traits::value_to_yaml(msg.dist_blade_target, out);
    out << "\n";
  }

  // member: blade_length
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "blade_length: ";
    rosidl_generator_traits::value_to_yaml(msg.blade_length, out);
    out << "\n";
  }

  // member: first_blade
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "first_blade: ";
    rosidl_generator_traits::value_to_yaml(msg.first_blade, out);
    out << "\n";
  }

  // member: inspect_targets
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.inspect_targets.size() == 0) {
      out << "inspect_targets: []\n";
    } else {
      out << "inspect_targets:\n";
      for (auto item : msg.inspect_targets) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: overlap_procentage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "overlap_procentage: ";
    rosidl_generator_traits::value_to_yaml(msg.overlap_procentage, out);
    out << "\n";
  }

  // member: hub_offset
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "hub_offset: ";
    rosidl_generator_traits::value_to_yaml(msg.hub_offset, out);
    out << "\n";
  }

  // member: vertical_safety
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vertical_safety: ";
    rosidl_generator_traits::value_to_yaml(msg.vertical_safety, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MissionInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace inspection_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use inspection_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const inspection_interfaces::msg::MissionInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  inspection_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use inspection_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const inspection_interfaces::msg::MissionInfo & msg)
{
  return inspection_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<inspection_interfaces::msg::MissionInfo>()
{
  return "inspection_interfaces::msg::MissionInfo";
}

template<>
inline const char * name<inspection_interfaces::msg::MissionInfo>()
{
  return "inspection_interfaces/msg/MissionInfo";
}

template<>
struct has_fixed_size<inspection_interfaces::msg::MissionInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<inspection_interfaces::msg::MissionInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<inspection_interfaces::msg::MissionInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__MISSION_INFO__TRAITS_HPP_
