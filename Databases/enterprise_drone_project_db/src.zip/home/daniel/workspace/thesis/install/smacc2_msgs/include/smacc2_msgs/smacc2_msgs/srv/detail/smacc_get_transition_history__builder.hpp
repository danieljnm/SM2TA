// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from smacc2_msgs:srv/SmaccGetTransitionHistory.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__SRV__DETAIL__SMACC_GET_TRANSITION_HISTORY__BUILDER_HPP_
#define SMACC2_MSGS__SRV__DETAIL__SMACC_GET_TRANSITION_HISTORY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "smacc2_msgs/srv/detail/smacc_get_transition_history__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace smacc2_msgs
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::smacc2_msgs::srv::SmaccGetTransitionHistory_Request>()
{
  return ::smacc2_msgs::srv::SmaccGetTransitionHistory_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace smacc2_msgs


namespace smacc2_msgs
{

namespace srv
{

namespace builder
{

class Init_SmaccGetTransitionHistory_Response_history
{
public:
  Init_SmaccGetTransitionHistory_Response_history()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::smacc2_msgs::srv::SmaccGetTransitionHistory_Response history(::smacc2_msgs::srv::SmaccGetTransitionHistory_Response::_history_type arg)
  {
    msg_.history = std::move(arg);
    return std::move(msg_);
  }

private:
  ::smacc2_msgs::srv::SmaccGetTransitionHistory_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::smacc2_msgs::srv::SmaccGetTransitionHistory_Response>()
{
  return smacc2_msgs::srv::builder::Init_SmaccGetTransitionHistory_Response_history();
}

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__SRV__DETAIL__SMACC_GET_TRANSITION_HISTORY__BUILDER_HPP_
