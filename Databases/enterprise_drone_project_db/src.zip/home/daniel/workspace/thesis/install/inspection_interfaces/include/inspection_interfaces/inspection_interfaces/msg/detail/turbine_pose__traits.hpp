// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from inspection_interfaces:msg/TurbinePose.idl
// generated code does not contain a copyright notice

#ifndef INSPECTION_INTERFACES__MSG__DETAIL__TURBINE_POSE__TRAITS_HPP_
#define INSPECTION_INTERFACES__MSG__DETAIL__TURBINE_POSE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "inspection_interfaces/msg/detail/turbine_pose__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace inspection_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const TurbinePose & msg,
  std::ostream & out)
{
  out << "{";
  // member: first_blade_rotation
  {
    out << "first_blade_rotation: ";
    rosidl_generator_traits::value_to_yaml(msg.first_blade_rotation, out);
    out << ", ";
  }

  // member: pixel_center_x
  {
    out << "pixel_center_x: ";
    rosidl_generator_traits::value_to_yaml(msg.pixel_center_x, out);
    out << ", ";
  }

  // member: pixel_center_y
  {
    out << "pixel_center_y: ";
    rosidl_generator_traits::value_to_yaml(msg.pixel_center_y, out);
    out << ", ";
  }

  // member: current_distance_lidar
  {
    out << "current_distance_lidar: ";
    rosidl_generator_traits::value_to_yaml(msg.current_distance_lidar, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const TurbinePose & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: first_blade_rotation
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "first_blade_rotation: ";
    rosidl_generator_traits::value_to_yaml(msg.first_blade_rotation, out);
    out << "\n";
  }

  // member: pixel_center_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pixel_center_x: ";
    rosidl_generator_traits::value_to_yaml(msg.pixel_center_x, out);
    out << "\n";
  }

  // member: pixel_center_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pixel_center_y: ";
    rosidl_generator_traits::value_to_yaml(msg.pixel_center_y, out);
    out << "\n";
  }

  // member: current_distance_lidar
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "current_distance_lidar: ";
    rosidl_generator_traits::value_to_yaml(msg.current_distance_lidar, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const TurbinePose & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace inspection_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use inspection_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const inspection_interfaces::msg::TurbinePose & msg,
  std::ostream & out, size_t indentation = 0)
{
  inspection_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use inspection_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const inspection_interfaces::msg::TurbinePose & msg)
{
  return inspection_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<inspection_interfaces::msg::TurbinePose>()
{
  return "inspection_interfaces::msg::TurbinePose";
}

template<>
inline const char * name<inspection_interfaces::msg::TurbinePose>()
{
  return "inspection_interfaces/msg/TurbinePose";
}

template<>
struct has_fixed_size<inspection_interfaces::msg::TurbinePose>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<inspection_interfaces::msg::TurbinePose>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<inspection_interfaces::msg::TurbinePose>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // INSPECTION_INTERFACES__MSG__DETAIL__TURBINE_POSE__TRAITS_HPP_
