// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from cv_interfaces:srv/EstimateStartPosition.idl
// generated code does not contain a copyright notice

#ifndef CV_INTERFACES__SRV__DETAIL__ESTIMATE_START_POSITION__TRAITS_HPP_
#define CV_INTERFACES__SRV__DETAIL__ESTIMATE_START_POSITION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "cv_interfaces/srv/detail/estimate_start_position__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace cv_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const EstimateStartPosition_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: frame_jpeg
  {
    if (msg.frame_jpeg.size() == 0) {
      out << "frame_jpeg: []";
    } else {
      out << "frame_jpeg: [";
      size_t pending_items = msg.frame_jpeg.size();
      for (auto item : msg.frame_jpeg) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: target_height
  {
    out << "target_height: ";
    rosidl_generator_traits::value_to_yaml(msg.target_height, out);
    out << ", ";
  }

  // member: target_width
  {
    out << "target_width: ";
    rosidl_generator_traits::value_to_yaml(msg.target_width, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EstimateStartPosition_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: frame_jpeg
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.frame_jpeg.size() == 0) {
      out << "frame_jpeg: []\n";
    } else {
      out << "frame_jpeg:\n";
      for (auto item : msg.frame_jpeg) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: target_height
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_height: ";
    rosidl_generator_traits::value_to_yaml(msg.target_height, out);
    out << "\n";
  }

  // member: target_width
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_width: ";
    rosidl_generator_traits::value_to_yaml(msg.target_width, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EstimateStartPosition_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace cv_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use cv_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const cv_interfaces::srv::EstimateStartPosition_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  cv_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use cv_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const cv_interfaces::srv::EstimateStartPosition_Request & msg)
{
  return cv_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<cv_interfaces::srv::EstimateStartPosition_Request>()
{
  return "cv_interfaces::srv::EstimateStartPosition_Request";
}

template<>
inline const char * name<cv_interfaces::srv::EstimateStartPosition_Request>()
{
  return "cv_interfaces/srv/EstimateStartPosition_Request";
}

template<>
struct has_fixed_size<cv_interfaces::srv::EstimateStartPosition_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<cv_interfaces::srv::EstimateStartPosition_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<cv_interfaces::srv::EstimateStartPosition_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace cv_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const EstimateStartPosition_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: is_valid
  {
    out << "is_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.is_valid, out);
    out << ", ";
  }

  // member: center_px_x
  {
    out << "center_px_x: ";
    rosidl_generator_traits::value_to_yaml(msg.center_px_x, out);
    out << ", ";
  }

  // member: center_px_y
  {
    out << "center_px_y: ";
    rosidl_generator_traits::value_to_yaml(msg.center_px_y, out);
    out << ", ";
  }

  // member: rotation_deg
  {
    out << "rotation_deg: ";
    rosidl_generator_traits::value_to_yaml(msg.rotation_deg, out);
    out << ", ";
  }

  // member: error_msg
  {
    out << "error_msg: ";
    rosidl_generator_traits::value_to_yaml(msg.error_msg, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EstimateStartPosition_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: is_valid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.is_valid, out);
    out << "\n";
  }

  // member: center_px_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "center_px_x: ";
    rosidl_generator_traits::value_to_yaml(msg.center_px_x, out);
    out << "\n";
  }

  // member: center_px_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "center_px_y: ";
    rosidl_generator_traits::value_to_yaml(msg.center_px_y, out);
    out << "\n";
  }

  // member: rotation_deg
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rotation_deg: ";
    rosidl_generator_traits::value_to_yaml(msg.rotation_deg, out);
    out << "\n";
  }

  // member: error_msg
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "error_msg: ";
    rosidl_generator_traits::value_to_yaml(msg.error_msg, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EstimateStartPosition_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace cv_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use cv_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const cv_interfaces::srv::EstimateStartPosition_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  cv_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use cv_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const cv_interfaces::srv::EstimateStartPosition_Response & msg)
{
  return cv_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<cv_interfaces::srv::EstimateStartPosition_Response>()
{
  return "cv_interfaces::srv::EstimateStartPosition_Response";
}

template<>
inline const char * name<cv_interfaces::srv::EstimateStartPosition_Response>()
{
  return "cv_interfaces/srv/EstimateStartPosition_Response";
}

template<>
struct has_fixed_size<cv_interfaces::srv::EstimateStartPosition_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<cv_interfaces::srv::EstimateStartPosition_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<cv_interfaces::srv::EstimateStartPosition_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<cv_interfaces::srv::EstimateStartPosition>()
{
  return "cv_interfaces::srv::EstimateStartPosition";
}

template<>
inline const char * name<cv_interfaces::srv::EstimateStartPosition>()
{
  return "cv_interfaces/srv/EstimateStartPosition";
}

template<>
struct has_fixed_size<cv_interfaces::srv::EstimateStartPosition>
  : std::integral_constant<
    bool,
    has_fixed_size<cv_interfaces::srv::EstimateStartPosition_Request>::value &&
    has_fixed_size<cv_interfaces::srv::EstimateStartPosition_Response>::value
  >
{
};

template<>
struct has_bounded_size<cv_interfaces::srv::EstimateStartPosition>
  : std::integral_constant<
    bool,
    has_bounded_size<cv_interfaces::srv::EstimateStartPosition_Request>::value &&
    has_bounded_size<cv_interfaces::srv::EstimateStartPosition_Response>::value
  >
{
};

template<>
struct is_service<cv_interfaces::srv::EstimateStartPosition>
  : std::true_type
{
};

template<>
struct is_service_request<cv_interfaces::srv::EstimateStartPosition_Request>
  : std::true_type
{
};

template<>
struct is_service_response<cv_interfaces::srv::EstimateStartPosition_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // CV_INTERFACES__SRV__DETAIL__ESTIMATE_START_POSITION__TRAITS_HPP_
