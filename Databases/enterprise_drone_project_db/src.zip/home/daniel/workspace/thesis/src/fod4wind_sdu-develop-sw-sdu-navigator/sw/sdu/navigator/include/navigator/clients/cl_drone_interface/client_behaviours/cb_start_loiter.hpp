
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_drone_interface/cl_drone_interface.hpp>
#include <condition_variable>
#include <std_msgs/msg/float32.hpp>
#include <std_msgs/msg/bool.hpp>
#include "inspection_interfaces/msg/mission_info.hpp"
#include <mavros_msgs/msg/state.hpp>
#include <mavros_msgs/srv/set_mode.hpp>
#include <navigator/navigator.hpp>
#include <chrono>
#include <navigator/LogHelper.hpp>

namespace navigator {
namespace cl_drone_interface {

class CbStartLoiter : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
  CbStartLoiter() = default;

  ~CbStartLoiter() override = default;

  // Log Function configs
  rclcpp::Logger getNodeLogger() { return this->getLogger(); }

  std::string getLogName() { return "CbStartLoiter"; }

  void onExit() override {
    // remove sub/pubs
    _sub.reset();
  }

  void onEntry() override {

    log_info("OnEntry: Sending request to drone to go into loiter mode");

    // Subs to check if loiter is activated
    _sub = getNode()->create_subscription<mavros_msgs::msg::State>("/mavros/state", rclcpp::ServicesQoS(),
                                                                   std::bind(&CbStartLoiter::onMessageState, this,
                                                                             std::placeholders::_1));

    // enable offboard mode
    rclcpp::Client<mavros_msgs::srv::SetMode>::SharedPtr client =
            getNode()->create_client<mavros_msgs::srv::SetMode>("/mavros/set_mode");

    auto request = std::make_shared<mavros_msgs::srv::SetMode::Request>();
    request->custom_mode = "AUTO.LOITER";

    auto result = client->async_send_request(request);
    // Wait for the result.
    result.wait();
    if (result.get()->mode_sent) {
      log_info("Returned: True, Drone flightmode now in LOITER");
//      force_shutdown = true;
      postSuccessEvent();
    } else {
      log_info("Failed to call service mavros/set_mode");
    }

    // start loop to keep going until we are in offboard!
//    rclcpp::Rate rate(0.5); // 0.5Hz
//    while (!isShutdownRequested() && !force_shutdown) {
//      _pub_position_target->publish(_msg);
//      rate.sleep();
//    }
  }

private:
  void onMessageState(const mavros_msgs::msg::State::SharedPtr msg) {
    // validate if the current published setpoint is == to our requested setpoint.
    //  A hacky way to ensure this node gets closed, but not before the setpoint has been accepted
    log_info("received state message, mode: %s" + msg->mode);
    if (msg->mode.find("LOITER") != std::string::npos) {
//      force_shutdown = true;
//      postSuccessEvent();
    }
  }

  rclcpp::Subscription<mavros_msgs::msg::State>::SharedPtr _sub;
  bool force_shutdown = false;
};
}
}
