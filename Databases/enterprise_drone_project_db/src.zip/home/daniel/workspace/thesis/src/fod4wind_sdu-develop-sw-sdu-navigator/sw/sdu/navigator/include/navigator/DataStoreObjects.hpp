#ifndef BUILD_DATASTOREOBJECTS_HPP
#define BUILD_DATASTOREOBJECTS_HPP

#include "custom_defines.hpp"
#include <vector>
#include <chrono>
#include "sensor_msgs/msg/point_cloud2.hpp"
#include "interfaces/msg/lidar_frame_multi_array.hpp"

namespace navigator
{

// custom structs for data storage
struct DronePos {
    double lat = -1;
    double lon = -1;
    double alt = -1;
};

struct DronePoseLocal {
    double x = -1;
    double y = -1;
    double z = -1;
    double q_x = -1;
    double q_y = -1;
    double q_z = -1;
    double q_w = -1;
};

struct GimbalPose {
    long timestamp_ns = -1;
    double q_x = -1;
    double q_y = -1;
    double q_z = -1;
    double q_w = -1;
};

struct TurbineInfo {
    float blade_length = 0;
    float blade_distance_target = 0;
    int hub_center_px_x = 0;
    int hub_center_px_y = 0;
    int first_blade = BLADE_A;
    float first_blade_rotation = 0;
    float overlap_procentage = 20;
    std::vector<unsigned char> inspect_targets;
    float hub_offset = 1;
    float vertical_safety = 10; // 10m by default
    // hardcoded distance for now until lidar is validated properly
    float current_distance_lidar = 10;
};

struct LidarInfo {
    // metadata
    long timestamp_ns = 0;
    std::string frame_id = "lidar";
    interfaces::msg::LidarFrameMultiArray dists;

    float curr_distance = 0;
};

struct CameraInfo {
    double sensor_width = 0;
    double sensor_height = 0;
    double focal_length = 0;
    int image_width = 0;
    int image_height = 0;
};

}
#endif //BUILD_DATASTOREOBJECTS_HPP
