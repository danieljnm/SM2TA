
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_drone_interface/cl_drone_interface.hpp>
#include <condition_variable>
#include <std_msgs/msg/float32.hpp>
#include <std_msgs/msg/bool.hpp>
#include "inspection_interfaces/msg/mission_info.hpp"
#include <mavros_msgs/msg/state.hpp>
#include <navigator/navigator.hpp>
#include <navigator/LogHelper.hpp>

namespace navigator {
namespace cl_drone_interface {

class CbStartOffboard : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
  CbStartOffboard() = default;

  ~CbStartOffboard() override = default;

  // Log Function configs
  rclcpp::Logger getNodeLogger() { return this->getLogger(); }

  std::string getLogName() { return "CbStartOffboard"; }

  void onExit() override {
    _sub.reset();
  }

  void onEntry() override {

    log_info("OnEntry: Sending request to drone to go into offboard mode ");

    // Subs to check if offboard is activated
    _sub = getNode()->create_subscription<mavros_msgs::msg::State>("/mavros/state", rclcpp::SensorDataQoS(),
                                                                   std::bind(&CbStartOffboard::onMessageState, this,
                                                                             std::placeholders::_1));

    // enable offboard mode
    auto _pub = getNode()->create_publisher<std_msgs::msg::Bool>("/drone_commander/cmd/activate_offboard",
                                                                 rclcpp::ServicesQoS());
    std_msgs::msg::Bool _msg;
    _msg.data = true;
    _pub->publish(_msg);

    // start loop to keep going until we are in offboard!
    rclcpp::Rate rate(0.5); // 0.5Hz
    while (!isShutdownRequested() && !force_shutdown) {
      _pub->publish(_msg);
      rate.sleep();
    }
  }

private:
  void onMessageState(const mavros_msgs::msg::State::SharedPtr msg) {
    // validate if the current published setpoint is == to our requested setpoint.
    //  A hacky way to ensure this node gets closed, but not before the setpoint has been accepted
    log_info("received state message, mode: " + msg->mode);
    if (msg->mode.find("OFFBOARD") != std::string::npos || msg->mode.find("GUIDED") != std::string::npos) {
      force_shutdown = true;
      postSuccessEvent();
    }
  }

  rclcpp::Subscription<mavros_msgs::msg::State>::SharedPtr _sub;
  bool force_shutdown = false;
};
}
}
