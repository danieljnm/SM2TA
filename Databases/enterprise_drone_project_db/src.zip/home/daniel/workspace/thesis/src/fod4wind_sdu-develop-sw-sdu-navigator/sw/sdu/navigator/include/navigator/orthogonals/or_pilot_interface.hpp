#pragma once

#include <navigator/clients/cl_pilot_interface/cl_pilot_interface.hpp>
#include <smacc2/smacc_orthogonal.hpp>

namespace navigator
{
    using namespace navigator::cl_pilot_interface;

    class OrPilotInterface : public smacc2::Orthogonal<OrPilotInterface>
    {
    public:
        void onInitialize() override
        {
            // This needs client for talking with imaging node, and client to talk with operator
            auto pilot_interface_client = this->createClient<ClPilotInterface>();
        }
    };
}  // namespace