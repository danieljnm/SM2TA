
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_pilot_interface/cl_pilot_interface.hpp>
#include <condition_variable>
#include <std_msgs/msg/float32.hpp>
#include "inspection_interfaces/msg/mission_info.hpp"
#include <navigator/navigator.hpp>
#include "navigator/LogHelper.hpp"

namespace navigator {
namespace cl_pilot_interface {

class CbPostMissionNotice : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
  CbPostMissionNotice() = default;
  ~CbPostMissionNotice() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }
    std::string getLogName() { return "CbPostMissionNotice"; }

  void onEntry() override {

    // TODO publish mission stuff for pilot that we are done etc. Not important at current state
//
//
//    std::string topicname = "/inspection_targets";
//
//    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable().durability_volatile();
//    rclcpp::SubscriptionOptions sub_option;
//    _sub_plan = getNode()->create_subscription<inspection_interfaces::msg::MissionInfo>(topicname, qos, std::bind(&CbRequestInspectionTargets::onMessageReceived, this, std::placeholders::_1), sub_option);

    log_info("Mission completed. Notifying pilot, and moving to IDLE");
    postSuccessEvent();
  }

private:
//  void onMessageReceived(const inspection_interfaces::msg::MissionInfo::SharedPtr msg) {
//
//    DataStore* _ds;
//    this->getStateMachine()->getGlobalSMData("datastore", _ds);
//
//    auto _turInfo = _ds->getTurbineInfo();
//    _turInfo.overlap_procentage = msg->overlap_procentage;
//    _turInfo.first_blade = msg->first_blade;
//    _turInfo.blade_distance_target = msg->dist_blade_target;
//    _turInfo.blade_length = msg->blade_length;
//    _turInfo.inspect_targets = std::vector<unsigned char> (std::begin(msg->inspect_targets), std::end(msg->inspect_targets));
//    _ds->setTurbineInfo(_turInfo);
//
//    RCLCPP_INFO(getLogger(), "[CbPostMissionNotice] Inspection Targets Received: ", _turInfo.inspect_targets.data(),
//                ", with overlap: ", _turInfo.overlap_procentage,
//                ", and distance: ", _turInfo.blade_distance_target,
//                ", First blade identified as: ", _turInfo.first_blade);
//
//    postSuccessEvent();
//  }

//  bool triggered = false;
//  std::mutex mutex;
  rclcpp::Subscription<inspection_interfaces::msg::MissionInfo>::SharedPtr sub_;
};
}
}
