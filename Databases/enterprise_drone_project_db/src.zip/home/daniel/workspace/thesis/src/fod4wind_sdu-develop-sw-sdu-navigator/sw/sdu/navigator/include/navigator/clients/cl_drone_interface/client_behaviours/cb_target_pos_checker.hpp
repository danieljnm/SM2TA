
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_drone_interface/cl_drone_interface.hpp>
#include <condition_variable>
#include <std_msgs/msg/float32.hpp>
#include "inspection_interfaces/msg/mission_info.hpp"
#include <navigator/navigator.hpp>
#include <rclcpp/rclcpp.hpp>
#include <navigator/LogHelper.hpp>
#include <navigator/Helpers.hpp>

// 5 hz
#define UPDATE_RATE (1000000000/5)

namespace navigator {
namespace cl_drone_interface {

class CbTargetPosChecker : public smacc2::SmaccClientBehavior, public smacc2::ISmaccUpdatable, LogHelper {
public:
    CbTargetPosChecker() : ISmaccUpdatable(rclcpp::Duration(0,UPDATE_RATE)) {}

    ~CbTargetPosChecker() override = default;

  // Log Function configs
  rclcpp::Logger getNodeLogger() { return this->getLogger(); }

  std::string getLogName() { return "CbTargetPosChecker"; }


  void onEntry() override {
    log_info("OnEntry, Checking pos every 5hz");
  }

  void onExit() override {
      log_info("Exiting Target Pos Checker...");
  }

  void update() override
  {
      this->checkDistanceToTarget();
  }

private:

  void checkDistanceToTarget() {
    try {
      DataStore *_ds;
      this->getStateMachine()->getGlobalSMData("datastore", _ds);

      // get target pos, and drone current pos
      auto _missionIndex = _ds->getCurrentMissionIndex();
      auto _missionPlan = _ds->getCurrentMissionPlan();
      auto _gimbal_threshold = _ds->getGimbalThresholdDeg();
      auto _pos_threshold = _ds->getPosThresholdM();

      // to avoid race-condition when changing state we check if current mission index is bigger than the size of missions, in which case we exit behaviour
      // It seems like this behaviour might be started before the state realise its reached end of mission and continues
      if (_missionIndex >= _missionPlan.plan.size()) {
        log_info("Stopping TargetPosChecker as current mission index is: " + std::to_string(_missionIndex) +
                 ", and plan size is: " + std::to_string(_missionPlan.plan.size() - 1));
        return;
      }

      auto _targetPos = _missionPlan.plan[_missionIndex].pose.pose.position;
      auto _targetGimbal = _missionPlan.plan[_missionIndex].gimbal_pose;
      auto _gimbalPose = _ds->getGimbalPose();

      // calculate distance between current pos and target
      auto _dist = _ds->calcDistanceCurrentLocalPosToPoint(_targetPos.x, _targetPos.y, _targetPos.z);

//    auto _debugPos = _ds->getDronePoseLocal();
//    log_info("target_pos: " + std::to_string(_targetPos.x) + "," + std::to_string(_targetPos.y) + "," + std::to_string(_targetPos.z));
//    log_info("local_pos: " + std::to_string(_debugPos.x) + "," + std::to_string(_debugPos.y) + "," + std::to_string(_debugPos.z));
//    log_info("Dist to target pos: " + std::to_string(_dist) + ", Threshold: 0.1m");

      // if we are within 1m continue and capture image
      if (_dist < _pos_threshold) {
        log_info("Dist to target pos: " + std::to_string(_dist) + ", Threshold: 1m");

        // check if gimbal reached gimbal pose. Threshold is 1deg
        auto at_orientation = PositionHelper::GimbalWithinThreshold(this->getLogger(),
                                                                    _gimbalPose, _targetGimbal.quaternion, _gimbal_threshold);
        if (at_orientation) {
          auto ev = new smacc2::EvCbSuccess<CbTargetPosChecker, OrDroneInterface>();
          this->postEvent(ev);
          log_info("Within position threshold. Moving to Capture Image State");
        }
      }
    }
    catch (const std::exception &e) {
      log_info("TargetPosChecker experienced an exception and exited:");
      log_info(e.what());
      return;
    }
  }
};
}
}
