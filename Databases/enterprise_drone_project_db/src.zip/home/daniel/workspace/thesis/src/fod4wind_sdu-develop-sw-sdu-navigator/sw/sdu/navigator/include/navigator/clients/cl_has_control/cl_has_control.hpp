#pragma once
#include <std_msgs/msg/float32.hpp>

namespace navigator
{
    namespace cl_has_control
    {
        class ClHasControl : public smacc2::ISmaccClient
        {
        public:
          ClHasControl() = default;
        };
    }  // namespace cl_has_control
}  // namespace navigator