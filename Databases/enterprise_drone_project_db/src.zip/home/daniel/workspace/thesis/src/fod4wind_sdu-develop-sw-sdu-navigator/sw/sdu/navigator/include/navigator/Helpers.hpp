#ifndef BUILD_HELPERS_H
#define BUILD_HELPERS_H

#include <geometry_msgs/msg/pose.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <geometry_msgs/msg/quaternion_stamped.hpp>
#include <geometry_msgs/msg/quaternion.hpp>
#include <rclcpp/logger.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <tf2/transform_datatypes.h>
#include <date.h>
#include <navigator/LogHelper.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include <visualization_msgs/msg/marker.hpp>

// Class to help with logging output text. Makes it easier to have each behaviour class inherit from this
//  and then overwrite the member functions with specific logger and name object
class PositionHelper {
public:

    // Static message build functions
    static geometry_msgs::msg::Pose buildPose(navigator::DronePoseLocal pose) {
        return buildPose(pose.x, pose.y, pose.z, pose.q_x, pose.q_y, pose.q_z, pose.q_w);
    }

    static geometry_msgs::msg::Pose buildPose(double x, double y, double z, double q_x, double q_y, double q_z, double q_w) {
        // build and return pose message

        auto _pose = geometry_msgs::msg::Pose();
        _pose.position = geometry_msgs::build<geometry_msgs::msg::Point>().x(x).y(y).z(z);
        _pose.orientation = geometry_msgs::build<geometry_msgs::msg::Quaternion>().x(q_x).y(q_y).z(q_z).w(q_w);

        return _pose;
    }

    static geometry_msgs::msg::Point buildPoint(double x, double y, double z) {
        auto const _point = geometry_msgs::build<geometry_msgs::msg::Point>().x(x).y(y).z(z);
        return _point;
    }

    static geometry_msgs::msg::PointStamped buildPoint(double x, double y, double z, std::string frame) {
        geometry_msgs::msg::PointStamped _point;
        _point.point = buildPoint(x,y,z);
        _point.header.frame_id = frame;
        return _point;
    }

    static geometry_msgs::msg::Quaternion buildQuat(double x, double y, double z, double w) {
        auto _quat = geometry_msgs::build<geometry_msgs::msg::Quaternion>().x(x).y(y).z(z).w(w);
        return _quat;
    }

    static float yawFromQuat(const geometry_msgs::msg::Quaternion &quat)
    {
        tf2::Quaternion quat_tf;
        tf2::convert(quat, quat_tf);
        tf2::Matrix3x3 m(quat_tf);
        double roll, pitch, yaw;
        m.getRPY(roll, pitch, yaw);
        return yaw;
    }

    static float pitchFromQuat(const geometry_msgs::msg::Quaternion &quat)
    {
        tf2::Quaternion quat_tf;
        tf2::convert(quat, quat_tf);
        tf2::Matrix3x3 m(quat_tf);
        double roll, pitch, yaw;
        m.getRPY(roll, pitch, yaw);
        return pitch;
    }

    static bool floatEqualsX(float x, float target, float tolerance = 0.001f) {
        return (x + tolerance >= target) && (x - tolerance <= target);
    }

    static bool isPosePositionEqual(geometry_msgs::msg::PoseStamped &pose1, geometry_msgs::msg::PoseStamped &pose2, float tolerance = 0.001f) {
        float x1 = pose1.pose.position.x;
        float y1 = pose1.pose.position.y;
        float z1 = pose1.pose.position.z;

        float x2 = pose2.pose.position.x;
        float y2 = pose2.pose.position.y;
        float z2 = pose2.pose.position.z;

        return floatEqualsX(x1, x2, tolerance) && floatEqualsX(y1, y2, tolerance) && floatEqualsX(z1, z2, tolerance);
    }

    static double RadianToDegrees(double radian) {
        return (radian * (180.0 / M_PI));
    }

    // Ecludian distance in 3 dimensions
    static double getDistanceBetweenPoints(geometry_msgs::msg::PoseStamped &pose1, geometry_msgs::msg::PoseStamped &pose2) {
        double x1 = pose1.pose.position.x;
        double y1 = pose1.pose.position.y;
        double z1 = pose1.pose.position.z;

        double x2 = pose2.pose.position.x;
        double y2 = pose2.pose.position.y;
        double z2 = pose2.pose.position.z;

        double distance = sqrt( pow(x2 - x1, 2) + pow(y2 - y1, 2) + pow(z2 - z1, 2));
        return distance;
    }

    static bool
    GimbalWithinThreshold(rclcpp::Logger _logger, navigator::GimbalPose curr_pose, geometry_msgs::msg::Quaternion target_pose, float threshold = 1) {
        // convert both quats to TF2 quats
        auto _pose = tf2::Quaternion(curr_pose.q_x, curr_pose.q_y, curr_pose.q_z, curr_pose.q_w);
        tf2::Quaternion _target;
        tf2::fromMsg(target_pose, _target);

        // calculate difference
        auto q_r = _pose.inverse() * _target;
        // convert to rpy
        tf2::Matrix3x3 m(q_r);
        double roll, pitch, yaw;
        m.getRPY(roll, pitch, yaw);

        // convert rpy to degrees instead of radians for comparison with threshold
        double roll_deg = abs(RadianToDegrees(roll));
        double pitch_deg = abs(RadianToDegrees(pitch));
        double yaw_deg = abs(RadianToDegrees(yaw));

        if (roll_deg < threshold && pitch_deg < threshold && yaw_deg < threshold) {
            LogHelper::log_info(_logger, "GimbalWithinThreshold","Gimbal within threshold at target orientation. Threshold: " + std::to_string(threshold) + ", Difference: roll: " + std::to_string(roll_deg) + ", pitch: " + std::to_string(pitch_deg) + ", yaw: " + std::to_string(yaw_deg));
            return true;
        }
        else {
            LogHelper::log_info(_logger, "GimbalWithinThreshold","Gimbal NOT within threshold at target orientation. Threshold: " + std::to_string(threshold) + ", Difference: roll: " + std::to_string(roll_deg) + ", pitch: " + std::to_string(pitch_deg) + ", yaw: " + std::to_string(yaw_deg));
            return false;
        }
    }
};

class MetadataHelper {
public:

    //static to generate filename
    static std::string buildImagePathAndFileName(int index, const std::string& blade, const std::string& blade_side, const std::string& motion_dir) {

        // current date
        auto date_string = date::format("%y%m%d_%H_%M_%S", std::chrono::system_clock::now());

        // Site/Turbine_model/data(YYMMDD)-run/A/Side#[rt/tr].JPG
        // Naming convention based on above.
        std::string path = "Site/Turbine_model/" + date_string + "-0/" + blade + "/" + blade_side + std::to_string(index) + motion_dir + ".jpg";

        return path;
    }
    // function for non-inspection images like start-position. Just needs to provide filepath
    //  Result will be "filepath/given/datestring.jpg"
    static std::string buildImagePathAndFileNameNoMetaData(const std::string& filepath) {

        // current date
        auto date_string = date::format("%y%m%d_%H_%M_%S", std::chrono::system_clock::now());

        // Site/Turbine_model/data(YYMMDD)-run/A/Side#[rt/tr].JPG
        // Naming convention based on above.
        std::string path = filepath + "/" + date_string + ".jpg";

        return path;
    }
};

class VisualizeHelper
{
public:

    // static to generate marker array from mission plan
    static visualization_msgs::msg::MarkerArray markerArrayFromPlannerResult(std::vector<inspection_interfaces::msg::PlannerPoint>& plan)
    {
        visualization_msgs::msg::MarkerArray vizArray;

        int i = 0;
        for (auto & item : plan)
        {
            // VISULIZATION
            visualization_msgs::msg::Marker marker1;
            marker1.header.frame_id = "map";
            marker1.id = i;
            marker1.type = visualization_msgs::msg::Marker::ARROW;
            marker1.action = visualization_msgs::msg::Marker::ADD; // add or modify object
            marker1.pose = item.pose.pose;
            marker1.color.a = 1;
            marker1.color.r = 1;
            marker1.color.g = 0;
            marker1.color.b = 0;
            // scale for spheres => 0.05
            marker1.scale.x = 0.8;
            marker1.scale.y = 0.3;
            marker1.scale.z = 0.3;

            vizArray.markers.push_back(marker1);

            // GIMBAL POS VIZ - Shows gimbal pose, while the above show drone pos. Using custom square arrows to see if roll is applied
            visualization_msgs::msg::Marker marker2;
            marker2.header.frame_id = "map";
            marker2.id = i+1000;
            marker2.type = visualization_msgs::msg::Marker::MESH_RESOURCE;
            marker2.mesh_resource = "package://global_planner/meshes/square_arrow.dae";
            marker2.action = visualization_msgs::msg::Marker::ADD; // add or modify object
            marker2.pose = item.gimbal_map_pose.pose;
            marker2.color.a = 1;
            marker2.color.r = 0;
            marker2.color.g = 0;
            marker2.color.b = 1;
            marker2.scale.x = 0.3;
            marker2.scale.y = 0.3;
            marker2.scale.z = 0.3;

            vizArray.markers.push_back(marker2);

            i++;
        }

        return vizArray;
    }
};


#endif // BUILD_HELPERS_H


