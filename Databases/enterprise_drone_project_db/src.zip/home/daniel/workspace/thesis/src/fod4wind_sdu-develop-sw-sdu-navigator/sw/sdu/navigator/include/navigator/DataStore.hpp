#ifndef BUILD_DATASTORE_HPP
#define BUILD_DATASTORE_HPP

#include <navigator/DataStoreObjects.hpp>
#include <inspection_interfaces/msg/planner_result.hpp>
#include <shared_mutex> // Shared mutex, as it allows for multiple threads to read at same time, but locks to one thread for writing
#include <mutex>
// std::unique_lock lock(mutex_); //Only one thread/writer can access
// std::shared_lock lock(mutex_); //Multiple threads/readers can read value at the same time.

namespace navigator {

class DataStore {


public:
    const DronePos &getDronePos() const;

    void setDronePos(const DronePos &dronePos);

    const DronePoseLocal &getDronePoseLocal() const;

    void setDronePoseLocal(const DronePoseLocal &dronePosLocal);

    const TurbineInfo &getTurbineInfo() const;

    void setTurbineInfo(const TurbineInfo &turbineInfo);

    const LidarInfo &getLidarInfo() const;

    void setLidarInfo(const LidarInfo &lidarInfo);

    const inspection_interfaces::msg::PlannerResult &getCurrentMissionPlan() const;

    void setCurrentMissionPlan(const inspection_interfaces::msg::PlannerResult &currentMissionPlan);

    int getCurrentMissionIndex() const;

    void setCurrentMissionIndex(int currentMissionIndex);

    void updateMissionItem(inspection_interfaces::msg::PlannerPoint item, int index);

    void updateMissionItemPlan(std::vector<inspection_interfaces::msg::PlannerPoint> items);

    double calcDistanceCurrentLocalPosToPoint(float x, float y, float z) const;

    const GimbalPose &getGimbalPose() const;

    void setGimbalPose(const GimbalPose &gimbalPose);

    double getPosThresholdM() const;

    void setPosThresholdM(double posThresholdM);

    double getGimbalThresholdDeg() const;

    void setGimbalThresholdDeg(double gimbalThresholdDeg);

    const CameraInfo &getCamInfo() const;

    void setCamInfo(const CameraInfo &camInfo);

private:
    DronePos _dronePos;
    DronePoseLocal _dronePosLocal;
    TurbineInfo _turbineInfo;
    LidarInfo _lidarInfo;
    GimbalPose _gimbalPose;
    CameraInfo _camInfo;

    // ros variables
    double _pos_threshold_m = 1;
    double _gimbal_threshold_deg = 1;

    // planner result, we just use the ros-message, no need to customize that data structure
    inspection_interfaces::msg::PlannerResult current_mission_plan;
    int current_mission_index = 0;

    // MUTEXS
    mutable std::shared_mutex _drone_pos_mutex;
    mutable std::shared_mutex _drone_pos_local_mutex;
    mutable std::shared_mutex _drone_pose_mutex;
    mutable std::shared_mutex _lidar_info_mutex;
    mutable std::shared_mutex _gimbal_pose_mutex;

    mutable std::shared_mutex _ros_param_mutex;
    mutable std::shared_mutex _shared_mutex;
};

}
#endif //BUILD_DATASTORE_HPP
