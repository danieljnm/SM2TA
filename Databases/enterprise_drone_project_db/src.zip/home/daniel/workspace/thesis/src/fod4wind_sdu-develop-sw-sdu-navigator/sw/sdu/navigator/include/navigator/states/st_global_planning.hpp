#pragma once

#include "rclcpp/rclcpp.hpp"
#include "smacc2/smacc.hpp"
#include "navigator/LogHelper.hpp"

// ORTHOGONALS
//using navigator::OrTimer;  // This is an example variable - feel free to delete it.

namespace navigator
{
// SMACC2 clases
using smacc2::Transition;
using smacc2::EvStateRequestFinish;
using smacc2::default_transition_tags::SUCCESS;
using smacc2::default_transition_tags::ABORT;

// STATE DECLARATION
struct GlobalPlanningState : smacc2::SmaccState<GlobalPlanningState, Navigator>
{
  using SmaccState::SmaccState;

  // DECLARE CUSTOM OBJECT TAGS
  struct LOST_CONTROL : ABORT{};
  struct NEXT : SUCCESS{};
  struct PREVIOUS : ABORT{};
  struct SrGlobalPlanReady;

  std::string _prefix = "[GLOBAL_PLANNING] ";

  // TRANSITION TABLE - adjust as needed
  typedef boost::mpl::list<
//    Transition<EvCbSuccess<CbGetGlobalPlan, OrGlobalPlanner>, mission_executor_super_state::mission_executor_state, NEXT>,
    Transition<EvAllGo<SrAllEventsGo, SrGlobalPlanReady>, StiNextPosState, NEXT>,
    Transition<EvCbFailure<CbCheckControl, OrHasControl>, IdleState, LOST_CONTROL>,
    Transition<EvGlobalError, IdleState, ABORT>

    >reactions;

  // STATE FUNCTIONS
  static void staticConfigure()
  {
    // START: Example code - change needed
    configure_orthogonal<OrGlobalPlanner, CbGetGlobalPlan>();
    configure_orthogonal<OrHasControl, CbCheckControl>();
    configure_orthogonal<OrDroneInterface, CbUpdateDroneData>();
    configure_orthogonal<OrDroneInterface, CbStartOffboard>();
    configure_orthogonal<OrLocalPlanner, CbToggleLocalPlanCorrections>(true);

    // Create State Reactor
    static_createStateReactor<
        SrAllEventsGo, smacc2::state_reactors::EvAllGo<SrAllEventsGo, SrGlobalPlanReady>,
        mpl::list<
            EvCbSuccess<CbGetGlobalPlan, OrGlobalPlanner>,
            EvCbSuccess<CbStartOffboard, OrDroneInterface>
        >>();
  }

  void runtimeConfigure() {}

  void onEntry()
  {
    LogHelper::log_info(getLogger(), _prefix, "Entered planner...");
  }

  void onExit(){}
};
}
