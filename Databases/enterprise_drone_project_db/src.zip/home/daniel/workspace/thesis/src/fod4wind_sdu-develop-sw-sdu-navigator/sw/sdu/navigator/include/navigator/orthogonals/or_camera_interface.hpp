#pragma once

#include <navigator/clients/cl_camera_interface/cl_camera_interface.hpp>
#include <smacc2/smacc_orthogonal.hpp>

namespace navigator
{
    using namespace navigator::cl_camera_interface;

    class OrCameraInterface : public smacc2::Orthogonal<OrCameraInterface>
    {
    public:
        void onInitialize() override
        {
            auto camera_interface_client = this->createClient<ClCameraInterface>();
        }
    };
}  // namespace