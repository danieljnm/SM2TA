#pragma once

#include <navigator/clients/cl_drone_interface/cl_drone_interface.hpp>
#include <smacc2/smacc_orthogonal.hpp>

namespace navigator
{
    using namespace navigator::cl_drone_interface;

    class OrDroneInterface : public smacc2::Orthogonal<OrDroneInterface>
    {
    public:
        void onInitialize() override
        {
            // This needs client for talking with imaging node, and client to talk with operator
            auto drone_interface_client = this->createClient<ClDroneInterface>();
        }
    };
}  // namespace