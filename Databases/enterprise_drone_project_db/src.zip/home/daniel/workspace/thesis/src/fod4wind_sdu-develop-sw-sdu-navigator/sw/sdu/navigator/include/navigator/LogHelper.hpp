#ifndef BUILD_LOGHELPER_H
#define BUILD_LOGHELPER_H

#include <std_msgs/msg/string.hpp>

// Class to help with logging output text. Makes it easier to have each behaviour class inherit from this
//  and then overwrite the member functions with specific logger and name object
class LogHelper
{
public:
    // log function for behaviours
    void log_info(const std::string log) {
        RCLCPP_INFO(getNodeLogger(), "%s", ("\x1B[34m [" + getLogName() + "] " + log + "\033[0m").c_str());
    }

    // Static log function
    static void log_info(rclcpp::Logger logger, std::string name, std::string log) {
        RCLCPP_INFO(logger, "%s", ("\x1B[34m" + name + log + "\033[0m").c_str());
    }

protected:
    virtual rclcpp::Logger getNodeLogger() = 0;
    virtual std::string getLogName() = 0;
    virtual ~LogHelper() = default;
private:

  // PUBLISHERS
//  rclcpp::Publisher<inspection_interfaces::msg::PlannerResult>::SharedPtr pub_plan_result;
};

#endif //BUILD_LOGHELPER_H
