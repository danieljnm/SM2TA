
#include <navigator/DataStore.hpp>
#include <utility>
#include <math.h>

namespace navigator {

const DronePos &DataStore::getDronePos() const {
  std::shared_lock lock(_drone_pos_mutex);
  return _dronePos;
}

void DataStore::setDronePos(const DronePos &dronePos) {
  std::unique_lock lock(_drone_pos_mutex);
  _dronePos = dronePos;
}

const DronePoseLocal &DataStore::getDronePoseLocal() const {
  std::shared_lock lock(_drone_pos_local_mutex);
  return _dronePosLocal;
}

void DataStore::setDronePoseLocal(const DronePoseLocal &dronePosLocal) {
  std::unique_lock lock(_drone_pos_local_mutex);
  _dronePosLocal = dronePosLocal;
}

const TurbineInfo &DataStore::getTurbineInfo() const {
  std::shared_lock lock(_shared_mutex);
  return _turbineInfo;
}

void DataStore::setTurbineInfo(const TurbineInfo &turbineInfo) {
  std::unique_lock lock(_shared_mutex);
  _turbineInfo = turbineInfo;
}

const LidarInfo &DataStore::getLidarInfo() const {
  std::shared_lock lock(_lidar_info_mutex);
  return _lidarInfo;
}

void DataStore::setLidarInfo(const LidarInfo &lidarInfo) {
  std::unique_lock lock(_lidar_info_mutex);
  _lidarInfo = lidarInfo;
}

const inspection_interfaces::msg::PlannerResult &DataStore::getCurrentMissionPlan() const {
  std::shared_lock lock(_shared_mutex);
  return current_mission_plan;
}

void DataStore::setCurrentMissionPlan(const inspection_interfaces::msg::PlannerResult &currentMissionPlan) {
  std::unique_lock lock(_shared_mutex);
  current_mission_plan = currentMissionPlan;
}

int DataStore::getCurrentMissionIndex() const {
  std::shared_lock lock(_shared_mutex);
  return current_mission_index;
}

void DataStore::setCurrentMissionIndex(int currentMissionIndex) {
  std::unique_lock lock(_shared_mutex);
  current_mission_index = currentMissionIndex;
}

void DataStore::updateMissionItem(inspection_interfaces::msg::PlannerPoint item, const int index)
{
  std::unique_lock lock(_shared_mutex);
  current_mission_plan.plan[index] = std::move(item);
}

void DataStore::updateMissionItemPlan(std::vector<inspection_interfaces::msg::PlannerPoint> items)
{
  std::unique_lock lock(_shared_mutex);
  current_mission_plan.plan = std::move(items);
}


double DataStore::calcDistanceCurrentLocalPosToPoint(float x, float y, float z) const {
  // get current local pos first
  auto _currPos = this->getDronePoseLocal();

  // calculate distance
  auto _dist = sqrt(pow(x - _currPos.x, 2) + pow(y - _currPos.y, 2) + pow(z - _currPos.z, 2));
  return _dist;
}

const GimbalPose &DataStore::getGimbalPose() const {
  std::shared_lock lock(_gimbal_pose_mutex);
  return _gimbalPose;
}

void DataStore::setGimbalPose(const GimbalPose &gimbalPose) {
  std::unique_lock lock(_gimbal_pose_mutex);
  _gimbalPose = gimbalPose;
}

double DataStore::getPosThresholdM() const {
  std::shared_lock lock(_ros_param_mutex);
  return _pos_threshold_m;
}

void DataStore::setPosThresholdM(double posThresholdM) {
  std::unique_lock lock(_ros_param_mutex);
  _pos_threshold_m = posThresholdM;
}

double DataStore::getGimbalThresholdDeg() const {
  std::shared_lock lock(_ros_param_mutex);
  return _gimbal_threshold_deg;
}

void DataStore::setGimbalThresholdDeg(double gimbalThresholdDeg) {
  std::unique_lock lock(_ros_param_mutex);
  _gimbal_threshold_deg = gimbalThresholdDeg;
}

const CameraInfo &DataStore::getCamInfo() const {
    std::shared_lock lock(_ros_param_mutex);
    return _camInfo;
}

void DataStore::setCamInfo(const CameraInfo &camInfo) {
    std::unique_lock lock(_ros_param_mutex);
    _camInfo = camInfo;
}
}