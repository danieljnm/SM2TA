
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_image_analyzer/cl_image_analyzer.hpp>
#include <condition_variable>
#include <std_msgs/msg/float32.hpp>
#include "navigator/LogHelper.hpp"

namespace navigator {
namespace cl_image_analyzer {

class CbValidateImage : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
  CbValidateImage() = default;

  ~CbValidateImage() override = default;

  // Log Function configs
  rclcpp::Logger getNodeLogger() { return this->getLogger(); }

  std::string getLogName() { return "CbValidateImage"; }

  void onEntry() override {

//    std::string topicname = "/turbine_blade_initial_pose";
//
//    auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable().durability_volatile();
//    rclcpp::SubscriptionOptions sub_option;
//    _sub_plan = getNode()->create_subscription<std_msgs::msg::Float32>(topicname, qos, std::bind(&CbGetTurbinePose::onMessageReceived, this, std::placeholders::_1), sub_option);

    log_info("Validating latest captured inspection image...");
    // do actual validation. Out of scope of current project

    try {
      // if good image, we move to next position.
      DataStore *_ds;
      this->getStateMachine()->getGlobalSMData("datastore", _ds);
      auto _current_index = _ds->getCurrentMissionIndex();
      _current_index++;
      _ds->setCurrentMissionIndex(_current_index);

      postSuccessEvent();
    }
    catch (const std::exception &e) {
      log_info("ValidateImage behaviour experienced an exception and exited:");
      log_info(e.what());
      return;
    }
  }

private:
//  void onMessageReceived(const std_msgs::msg::Float32::SharedPtr msg) {
//
//
//    postSuccessEvent();
//  }

//  bool triggered = false;
//  std::mutex mutex;
  rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr sub_;
};
}
}
