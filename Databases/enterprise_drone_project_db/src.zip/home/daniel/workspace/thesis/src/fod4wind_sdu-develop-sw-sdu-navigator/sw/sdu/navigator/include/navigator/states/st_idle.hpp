#pragma once

#include "rclcpp/rclcpp.hpp"
#include "smacc2/smacc.hpp"
#include "navigator/LogHelper.hpp"

namespace navigator
{
// SMACC2 clases
using smacc2::Transition;
using smacc2::EvStateRequestFinish;
using smacc2::default_transition_tags::SUCCESS;
using smacc2::default_transition_tags::ABORT;

//using cl_ros_timer::EvTimer;
//using cl_ros_timer::CbTimerCountdownLoop;
//using cl_ros_timer::CbTimerCountdownOnce;
//
//using navigator::OrTimer;

// STATE DECLARATION
struct IdleState : smacc2::SmaccState<IdleState, Navigator>
{
  using SmaccState::SmaccState;

    // DECLARE CUSTOM OBJECT TAGS
    struct TIMEOUT : ABORT{};
    struct NEXT : SUCCESS{};
    struct PREVIOUS : ABORT{};

    std::string _prefix = "[IDLE] ";

  // TRANSITION TABLE - adjust as needed
  typedef boost::mpl::list<

    Transition<EvCbSuccess<CbCheckControl, OrHasControl>, PosAquisitionState, NEXT>

    >reactions;

  // STATE FUNCTIONS
  static void staticConfigure()
  {
      configure_orthogonal<OrHasControl, CbCheckControl>();
      configure_orthogonal<OrDroneInterface, CbSendNeutralPos>();
      configure_orthogonal<OrDroneInterface, CbUpdateDroneData>();
  }

  void runtimeConfigure() {}

  void onEntry()
  {
    LogHelper::log_info(getLogger(), _prefix, "Entered IDLE...");
  }

  void onExit()
  {
  }
};
}
