
#pragma once

#include "navigator/LogHelper.hpp"
#include <chrono>
#include <condition_variable>
#include <interfaces/srv/capture_image_with_exif.hpp>
#include <navigator/clients/cl_camera_interface/cl_camera_interface.hpp>
#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <std_msgs/msg/float32.hpp>
#include <inspection_interfaces/msg/start_pos_estimation_request.hpp>
#include "navigator/Helpers.hpp"

using namespace std::chrono_literals;

namespace navigator {
namespace cl_camera_interface {

class CbTakeStartPositionPicture : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
    CbTakeStartPositionPicture() = default;

    ~CbTakeStartPositionPicture() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }

    std::string getLogName() { return "CbTakeStartPositionPicture"; }

    void onEntry() override {
        // check if current waypoint is transition, if it is, skip to validation
        DataStore *_ds;
        this->getStateMachine()->getGlobalSMData("datastore", _ds);
        captureImage(); // todo, right now this can block entry until image is taken, consider spawning it in thread
    }

    void onExit() override {
        // stop services
        capture_srv.reset();
        _pub_request_start_pos_estimation.reset();

    }

private:
    void captureImage() {
        capture_srv = getNode()->create_client<interfaces::srv::CaptureImageWithExif>(
                "/camera_sony_sdk/capture_image_with_exif_srv");

        _pub_request_start_pos_estimation = getNode()->create_publisher<inspection_interfaces::msg::StartPosEstimationRequest>("/navigator/start_estimation/request", rclcpp::ServicesQoS());

        // take picture and save where we can use it...
        log_info("Asking to save image...");

        try {
            // get meta-data required
            DataStore *_ds;
            this->getStateMachine()->getGlobalSMData("datastore", _ds);

            // target point
            auto _plan = _ds->getCurrentMissionPlan();
            auto _turInfo = _ds->getTurbineInfo();
            auto _lidarInfo = _ds->getLidarInfo();
            auto _dronePos = _ds->getDronePos();

            // local
            auto _dronePoseLocal = _ds->getDronePoseLocal();
            auto _gimbalPose = _ds->getGimbalPose();

            // filename with full path
            auto _filename = MetadataHelper::buildImagePathAndFileNameNoMetaData("start_position_images");

            // Create request object and send to service
            auto request =
                    std::make_shared<interfaces::srv::CaptureImageWithExif::Request>();

            request->header.stamp = this->getNode()->now();
            request->cmd = request->CAPTURE_IMAGE;
            request->name = _filename;
            request->focal_distance = _lidarInfo.curr_distance;

            request->exif_data.file_name = _filename;
            request->exif_data.header.stamp = this->getNode()->now();
            request->exif_data.altitude_msl = _dronePos.alt;
            request->exif_data.latitude = _dronePos.lat;
            request->exif_data.longitude = _dronePos.lon;
            request->exif_data.drone_pose = PositionHelper::buildPose(_dronePoseLocal); // LOCAL POSE
            request->exif_data.gimbal_orientation = PositionHelper::buildQuat(_gimbalPose.q_x, _gimbalPose.q_y,
                                                                              _gimbalPose.q_z,
                                                                              _gimbalPose.q_w);
            request->exif_data.inspection_id = "1"; // TODO is hardcoded for now, in future should depend on input from user? Or otherwise be told based on files on SD card, which is the next number?
            request->exif_data.lidar_frames = _lidarInfo.dists;


            auto result = capture_srv->async_send_request(request);
            result.wait_for(10s); //blocking for 10sec or until answer is ready

            // result of request to camera handler
            auto response = result.get();
            if (response != nullptr) {
                // we succeed
                log_info("Returned: True, Image captured");

                // send request for location estimation
                inspection_interfaces::msg::StartPosEstimationRequest msg;
                msg.filepath = response->path;
                msg.current_lidar_distance = _lidarInfo.curr_distance;
                _pub_request_start_pos_estimation->publish(msg);
                return;
            } else {
                log_info("Failed to get answer from takepicture service, aborting to idle");
                postFailureEvent();
                return;
            }

        } catch (const std::exception &e) {
            log_info("Failed to call service camera/captureimage with exception" +
                     to_string(e) + ", trying again...");
            log_info(e.what());
            captureImage();
        }
    }
    rclcpp::Client<interfaces::srv::CaptureImageWithExif>::SharedPtr capture_srv;
    rclcpp::Publisher<inspection_interfaces::msg::StartPosEstimationRequest>::SharedPtr _pub_request_start_pos_estimation;
};
} // namespace cl_camera_interface
} // namespace navigator
