#pragma once

#include <navigator/clients/cl_has_control/cl_has_control.hpp>
#include <smacc2/smacc_orthogonal.hpp>

namespace navigator
{
    using namespace navigator::cl_has_control;

    class OrHasControl : public smacc2::Orthogonal<OrHasControl>
    {
    public:
        void onInitialize() override
        {
          auto has_control_client = this->createClient<ClHasControl>();
        }
    };
}  // namespace