
#pragma once

#include <navigator/clients/cl_has_control/client_behaviours/cb_in_control_subscriber_behaviour.hpp>
#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <condition_variable>
#include <navigator/LogHelper.hpp>

namespace navigator {
namespace cl_has_control {

class CbCheckControl : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
  CbCheckControl() = default;
  ~CbCheckControl() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }
    std::string getLogName() { return "CbHasControl"; }

  void onExit() override {
      _sub_control.reset();
    }

  void onEntry() override {

    std::string topicname = "/system/control";

    rclcpp::SubscriptionOptions sub_option;
    _sub_control = getNode()->create_subscription<std_msgs::msg::Float32>(topicname, rclcpp::ServicesQoS(), std::bind(&CbCheckControl::onMessageReceived, this, std::placeholders::_1), sub_option);

  }

private:
  void onMessageReceived(const std_msgs::msg::Float32::SharedPtr msg) {

    // 1 == control, 0 == no control
    if (msg->data == 1)
    {
      log_info("We got mission control!");

      postSuccessEvent();
    }
    else if (msg->data == 0)
    {
      log_info("We no longer have mission control!");
      postFailureEvent();
    }

  }

  rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr _sub_control;
};
}
}
