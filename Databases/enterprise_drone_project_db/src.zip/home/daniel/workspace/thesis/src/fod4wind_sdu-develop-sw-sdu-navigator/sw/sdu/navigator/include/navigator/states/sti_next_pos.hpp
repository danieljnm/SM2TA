#pragma once

#include "rclcpp/rclcpp.hpp"
#include "smacc2/smacc.hpp"
#include <navigator/DataStore.hpp>
#include <cstdio>
#include "navigator/LogHelper.hpp"

namespace navigator {
using smacc2::default_transition_tags::SUCCESS;
using smacc2::default_transition_tags::CONTINUELOOP;

// STATE DECLARATION
struct StiNextPosState : smacc2::SmaccState<StiNextPosState, Navigator> {
public:
  using SmaccState::SmaccState;

  // DECLARE CUSTOM OBJECT TAGS
  struct LOST_CONTROL : ABORT {};
  struct NEXT : SUCCESS{};

  std::string _prefix = "[NEXT_POS] ";

  // TRANSITION TABLE
  typedef mpl::list<
          Transition<EvCbFailure<CbCheckControl, OrHasControl>, IdleState, LOST_CONTROL>,
          Transition<EvCbSuccess<CbTargetPosChecker, OrDroneInterface>, StiCaptureState, CONTINUELOOP>,
          Transition<EvLoopEnd<StiNextPosState>, MissionCompletedState, NEXT>
  > reactions;

  // STATE FUNCTIONS
  static void staticConfigure() {
    configure_orthogonal<OrHasControl, CbCheckControl>();
    configure_orthogonal<OrDroneInterface, CbUpdateDroneData>();
    configure_orthogonal<OrDroneInterface, CbTargetPosChecker>();
    configure_orthogonal<OrDroneInterface, CbSendTargetPos>();
    configure_orthogonal<OrLocalPlanner, CbGetLocalPlanCorrections>();
  }

  void runtimeConfigure() {}

  void onEntry() {
    try {

      // get data store
      DataStore *_ds;
      this->getStateMachine().getGlobalSMData("datastore", _ds);
      auto _currentIndex = _ds->getCurrentMissionIndex();
      auto _missionPlan = _ds->getCurrentMissionPlan();
      auto _totalWaypoints = _missionPlan.plan.size();

      // check if current waypoint index is bigger than mission-list array. Subtracting one as current is index, and total is size
      LogHelper::log_info(getLogger(), _prefix,
                          "Current waypoint: " + std::to_string(_currentIndex) + ", total waypoints: " +
                          std::to_string(_totalWaypoints - 1));

      // if index is larger or equal to size, we have exhausted the list and should finish the mission
      if (_currentIndex >= _totalWaypoints) {
        this->postEvent<EvLoopEnd<StiNextPosState>>();
      }
    }
    catch (const std::exception &e) {
      LogHelper::log_info(getLogger(), _prefix,
                          "NextPos State experienced an exception in OnEntry and returned early:" + to_string(e));
      LogHelper::log_info(getLogger(), _prefix, e.what());
      return;
    }
  }

  void onExit() {}
};
}  // namespace navigator