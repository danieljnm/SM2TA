
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_drone_interface/cl_drone_interface.hpp>
#include <condition_variable>
#include <navigator/navigator.hpp>
#include <mavros_msgs/msg/position_target.hpp>
#include "interfaces/msg/gimbal_attitude.hpp"
#include "interfaces/msg/larke_position_target.hpp"
#include <tf2/convert.h>
#include <tf2/transform_datatypes.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <inspection_interfaces/msg/trajectory.hpp>
#include "navigator/LogHelper.hpp"

// 5 hz
#define UPDATE_RATE (1000000000/5)

namespace navigator {
namespace cl_drone_interface {

class CbSendNeutralPos : public smacc2::SmaccClientBehavior, public smacc2::ISmaccUpdatable, LogHelper {
public:
    CbSendNeutralPos() : ISmaccUpdatable(rclcpp::Duration(0, UPDATE_RATE)) {}
    ~CbSendNeutralPos() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }
    std::string getLogName() { return "CbSendNeutralPos"; }

    void onExit() override {
        // unsub subs/pubs
        _pub_gimbal.reset();
        _pub_position_target.reset();
    }


    // could make this more generic by adding pose as input argument to the behaviour so we could use it in multiple states to set the pos and gimbal we want. But no point as we don't use that.
    //  LocalCorrectionsEnabled shows how arguments can be passed


    void onEntry() override {

        // set target pos
        _pub_gimbal = getNode()->create_publisher<interfaces::msg::GimbalAttitude>("/drone_commander/cmd/set_gimbal_attitude", rclcpp::ServicesQoS());
        _pub_position_target = getNode()->create_publisher<interfaces::msg::LarkePositionTarget>("/drone_commander/cmd/setpoint_raw", rclcpp::ServicesQoS());

        // TRY
        try {

            // Position, send the current position as target position. Goal is to avoid the drone moving if it goes into offboard mode, before we send the new targeted position
            DataStore *_ds;
            this->getStateMachine()->getGlobalSMData("datastore", _ds);

            auto _targetPos = _ds->getDronePoseLocal();
            _msg.position = PositionHelper::buildPoint(_targetPos.x, _targetPos.y, _targetPos.z);

            // Required by Upteko
            _msg.coordinate_frame = 1;
            _msg.header.stamp = getNode()->now();
            _msg.header.frame_id = "navigator";

            // type flag, set to only use position and yaw: http://docs.ros.org/en/api/mavros_msgs/html/msg/PositionTarget.html
            _msg.type_mask = 0b100111111000;

            // Make quat and extract yaw
            float yaw = PositionHelper::yawFromQuat(PositionHelper::buildQuat(_targetPos.q_x, _targetPos.q_y, _targetPos.q_z, _targetPos.q_w));
            _msg.yaw = yaw;

            _pub_position_target->publish(_msg);

            // gimbal message
            _gimbal_msg.orientation = PositionHelper::buildQuat(0, 0, 0, 1);
            _gimbal_msg.gimbal_device_id = 154;
            _gimbal_msg.flags = 44; // yaw in vehicle frame, lock roll and pitch to angle from horizon. (standard on stabilized gimbals)
            // set NaN on velocity, if it doesn't react, might need to set a wanted rate
            _gimbal_msg.angular_velocity_x = NAN;
            _gimbal_msg.angular_velocity_y = NAN;
            _gimbal_msg.angular_velocity_z = NAN;

            _pub_gimbal->publish(_gimbal_msg);
            log_info("Sent request to gimbal to set in neutral default pose");
        }
        catch (const std::exception& e) {
            log_info("SendNeutralPos experienced an exception and exited:");
            log_info(e.what());
            return;
        }
    }
    void update() override
    {  }

private:
    interfaces::msg::GimbalAttitude _gimbal_msg;
    interfaces::msg::LarkePositionTarget _msg;
    rclcpp::Publisher<interfaces::msg::GimbalAttitude>::SharedPtr _pub_gimbal;
    rclcpp::Publisher<interfaces::msg::LarkePositionTarget>::SharedPtr _pub_position_target;
};
}
}