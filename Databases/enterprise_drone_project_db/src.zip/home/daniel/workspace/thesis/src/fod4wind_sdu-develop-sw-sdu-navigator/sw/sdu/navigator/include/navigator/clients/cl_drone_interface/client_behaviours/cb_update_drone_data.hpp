
#pragma once

#include "inspection_interfaces/msg/mission_info.hpp"
#include "navigator/LogHelper.hpp"
#include <condition_variable>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <interfaces/msg/lidar_frame_multi_array.hpp>
#include <interfaces/msg/global_pos.hpp>
#include <navigator/clients/cl_drone_interface/cl_drone_interface.hpp>
#include <navigator/navigator.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <std_msgs/msg/float32.hpp>
#include <interfaces/msg/gimbal_attitude.hpp>

namespace navigator {
namespace cl_drone_interface {

class CbUpdateDroneData : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
    CbUpdateDroneData() = default;
    ~CbUpdateDroneData() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }
    std::string getLogName() { return "CbUpdateDroneData"; }

    void onExit() override {
        // remove subs
        _sub_global_pos.reset();
        _sub_local_pos.reset();
        _sub_gimbal_pose.reset();
        _sub_lidar.reset();
        _sub_lidar_shortest.reset();
    }

    void onEntry() override {

        //TODO we get them as reliable from drone_info node, but pos and local pos should probably be best_effort due to update frequency. (Require Upteko changes)
        _sub_global_pos = getNode()->create_subscription<interfaces::msg::GlobalPos>("/drone_info/global_pos/position", rclcpp::ServicesQoS(), std::bind(&CbUpdateDroneData::onMessageGlobalPosition, this, std::placeholders::_1));
        _sub_local_pos = getNode()->create_subscription<geometry_msgs::msg::PoseStamped>("/drone_info/local_pose", rclcpp::ServicesQoS(), std::bind(&CbUpdateDroneData::onMessageLocalPosition, this, std::placeholders::_1));
        _sub_lidar = getNode()->create_subscription<interfaces::msg::LidarFrameMultiArray>("/lidar/dists", rclcpp::SensorDataQoS(), std::bind(&CbUpdateDroneData::onMessageLidar, this, std::placeholders::_1));
        _sub_lidar_shortest = getNode()->create_subscription<std_msgs::msg::Float32>("/lidar/shortest_dist", rclcpp::SensorDataQoS(), std::bind(&CbUpdateDroneData::onMessageShortestLidar, this, std::placeholders::_1));
        _sub_gimbal_pose = getNode()->create_subscription<interfaces::msg::GimbalAttitude>("/drone_info/gimbal_attitude", rclcpp::SensorDataQoS(), std::bind(&CbUpdateDroneData::onMessageGimbalPose, this, std::placeholders::_1));

        log_info("Updater subscribed to: \n" + std::string(_sub_global_pos->get_topic_name()) + "\n" + std::string(_sub_local_pos->get_topic_name()) +"\n");
    }

private:
    void onMessageGlobalPosition(const interfaces::msg::GlobalPos::SharedPtr msg) {

        DataStore* _ds;
        this->getStateMachine()->getGlobalSMData("datastore", _ds);
        DronePos _newPos;
        _newPos.lat = msg->lat;
        _newPos.lon = msg->lon;
        _newPos.alt = msg->gps_alt;

        _ds->setDronePos(_newPos);
    }

    void onMessageLocalPosition(const geometry_msgs::msg::PoseStamped::SharedPtr msg) {

        DataStore* _ds;
        this->getStateMachine()->getGlobalSMData("datastore", _ds);
        DronePoseLocal _newPose;
        _newPose.x = msg->pose.position.x;
        _newPose.y = msg->pose.position.y;
        _newPose.z = msg->pose.position.z;

        _newPose.q_x = msg->pose.orientation.x;
        _newPose.q_y = msg->pose.orientation.y;
        _newPose.q_w = msg->pose.orientation.w;
        _newPose.q_z = msg->pose.orientation.z;

        _ds->setDronePoseLocal(_newPose);
    }

    void onMessageLidar(const interfaces::msg::LidarFrameMultiArray::SharedPtr msg) {
        DataStore* _ds;
        this->getStateMachine()->getGlobalSMData("datastore", _ds);
        auto _lidar = _ds->getLidarInfo();
        // we keep in PointCloud2 message format to ensure we are compatible later, but extract a few metadata for ease of use
        _lidar.timestamp_ns = rclcpp::Time(msg->lidar_frames[0].header.stamp).nanoseconds();
        _lidar.dists = *msg;
        _ds->setLidarInfo(_lidar);
    }

    void onMessageShortestLidar(const std_msgs::msg::Float32::SharedPtr msg) {
        DataStore* _ds;
        this->getStateMachine()->getGlobalSMData("datastore", _ds);
        auto _lidar = _ds->getLidarInfo();
        _lidar.curr_distance = msg->data;
        _ds->setLidarInfo(_lidar);
    }

    void onMessageGimbalPose(const interfaces::msg::GimbalAttitude::SharedPtr msg) {
        DataStore* _ds;
        this->getStateMachine()->getGlobalSMData("datastore", _ds);
        GimbalPose _newGimbal;
        _newGimbal.timestamp_ns = rclcpp::Time(msg->header.stamp).nanoseconds();
        _newGimbal.q_x = msg->orientation.x;
        _newGimbal.q_y = msg->orientation.y;
        _newGimbal.q_z = msg->orientation.z;
        _newGimbal.q_w = msg->orientation.w;

        _ds->setGimbalPose(_newGimbal);
    }


    rclcpp::Subscription<interfaces::msg::GlobalPos>::SharedPtr _sub_global_pos;
    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr _sub_local_pos;
    rclcpp::Subscription<interfaces::msg::LidarFrameMultiArray>::SharedPtr _sub_lidar;
    rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr _sub_lidar_shortest;
    rclcpp::Subscription<interfaces::msg::GimbalAttitude>::SharedPtr _sub_gimbal_pose;
};
}
}
