#ifndef BUILD_CUSTOM_DEFINES_HPP
#define BUILD_CUSTOM_DEFINES_HPP

#define BLADE_A 1
#define BLADE_B 2
#define BLADE_C 3
#define TOWER   4
#define NACELL  5



#endif //BUILD_CUSTOM_DEFINES_HPP
