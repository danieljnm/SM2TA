#pragma once

#include "rclcpp/rclcpp.hpp"
#include "smacc2/smacc.hpp"
#include "navigator/LogHelper.hpp"

// ORTHOGONALS
//using navigator::OrTimer;  // This is an example variable - feel free to delete it.

namespace navigator
{
// SMACC2 clases
using smacc2::Transition;
using smacc2::EvStateRequestFinish;
using smacc2::default_transition_tags::SUCCESS;
using smacc2::default_transition_tags::ABORT;

//using cl_ros_timer::EvTimer;
//using cl_ros_timer::CbTimerCountdownLoop;
//using cl_ros_timer::CbTimerCountdownOnce;
//
//using navigator::OrTimer;

// STATE DECLARATION
struct MissionCompletedState : smacc2::SmaccState<MissionCompletedState, Navigator>
{
  using SmaccState::SmaccState;

  // DECLARE CUSTOM OBJECT TAGS
  struct LOST_CONTROL : ABORT{};
  struct NEXT : SUCCESS{};
  struct PREVIOUS : ABORT{};

  std::string _prefix = "[MISSION_COMPLETE] ";

  // TRANSITION TABLE - adjust as needed
  typedef boost::mpl::list<

    // change to post-mission OR/handler for rpi endurance testing: mission_executor_super_state::mission_executor_state
    Transition<EvCbSuccess<CbPostMissionNotice, OrPilotInterface>, IdleState, NEXT>,
    Transition<EvCbFailure<CbCheckControl, OrHasControl>, IdleState, LOST_CONTROL>,
    Transition<EvGlobalError, IdleState, ABORT>

    >reactions;

  // STATE FUNCTIONS
  static void staticConfigure()
  {
      // START: Example code - change needed
    configure_orthogonal<OrHasControl, CbCheckControl>();
    configure_orthogonal<OrDroneInterface, CbUpdateDroneData>();
    configure_orthogonal<OrDroneInterface, CbStartLoiter>();
    configure_orthogonal<OrPilotInterface, CbPostMissionNotice>();
    configure_orthogonal<OrLocalPlanner, CbToggleLocalPlanCorrections>(false);
    // END: Example code - change or delete as needed
  }

  void runtimeConfigure() {}

  void onEntry()
  {
    LogHelper::log_info(getLogger(), _prefix, "Entered Mission_Complete...Mission is done");

//    // endurance test
//    LogHelper::log_info(getLogger(), _prefix, "Setting mission index to zero if we wish to continue to repeat flight");
//    DataStore* _ds;
//    this->getStateMachine().getGlobalSMData("datastore", _ds);
//    _ds->setCurrentMissionIndex(0);
  }

  void onExit()
  {  }
};
}
