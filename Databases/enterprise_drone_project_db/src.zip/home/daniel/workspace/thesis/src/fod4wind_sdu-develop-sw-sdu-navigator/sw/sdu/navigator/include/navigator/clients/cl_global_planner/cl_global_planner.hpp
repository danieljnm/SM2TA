#pragma once
#include <smacc2/smacc.hpp>
#include <std_msgs/msg/float32.hpp>

namespace navigator
{
namespace cl_global_planner
{
class ClGlobalPlanner : public smacc2::ISmaccClient
{
public:
  ClGlobalPlanner()= default;

};
}  // namespace cl_global_planner
}  // namespace navigator