
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_pilot_interface/cl_pilot_interface.hpp>
#include <condition_variable>
#include <std_msgs/msg/float32.hpp>
#include "inspection_interfaces/msg/mission_info.hpp"
#include <navigator/navigator.hpp>
#include <navigator/LogHelper.hpp>

namespace navigator {
namespace cl_pilot_interface {

class CbRequestInspectionTargets : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
  CbRequestInspectionTargets() = default;
  ~CbRequestInspectionTargets() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }
    std::string getLogName() { return "CbRequestInspectionTargets"; }

  void onExit() override {
      _sub.reset();
    }

  void onEntry() override {

    std::string topicname = "/inspection_targets";

    _sub = getNode()->create_subscription<inspection_interfaces::msg::MissionInfo>(topicname, rclcpp::ServicesQoS(), std::bind(&CbRequestInspectionTargets::onMessageReceived, this, std::placeholders::_1));

    log_info("Requesting Inspection targets from Pilot...");

  }

private:
  void onMessageReceived(const inspection_interfaces::msg::MissionInfo::SharedPtr msg) {

    DataStore* _ds;
    this->getStateMachine()->getGlobalSMData("datastore", _ds);

    auto _turInfo = _ds->getTurbineInfo();
    _turInfo.overlap_procentage = msg->overlap_procentage;
    _turInfo.first_blade = msg->first_blade;
    _turInfo.blade_distance_target = msg->dist_blade_target;
    _turInfo.blade_length = msg->blade_length;
    _turInfo.inspect_targets = std::vector<unsigned char> (std::begin(msg->inspect_targets), std::end(msg->inspect_targets));
    _turInfo.hub_offset = msg->hub_offset;
    _turInfo.vertical_safety = msg->vertical_safety;
    _ds->setTurbineInfo(_turInfo);

    // not using our log function, as it can't easily convert a vector into array data, seemingly.
//    RCLCPP_INFO(getLogger(), "[CbRequestInspectionTargets] Inspection Targets Received: %d, with overlap: %d, First blade identified as: %d",
//                _turInfo.inspect_targets.data(), _turInfo.overlap_procentage, _turInfo.blade_distance_target, _turInfo.first_blade);

    log_info("Inspection Targets Received: " + to_string(_turInfo.inspect_targets.data()) + ", with overlap: " +
                 to_string(_turInfo.overlap_procentage) + ", First blade identified as: " + to_string(_turInfo.first_blade) + ", Vertical_safety_dist: " + to_string(_turInfo.vertical_safety));

    postSuccessEvent();
  }

//  bool triggered = false;
//  std::mutex mutex;
  rclcpp::Subscription<inspection_interfaces::msg::MissionInfo>::SharedPtr _sub;
};
}
}
