
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_global_planner/client_behaviours/cb_get_global_plan.hpp>
#include <condition_variable>
#include <std_msgs/msg/float32.hpp>
#include "inspection_interfaces/msg/planner_request.hpp"
#include "inspection_interfaces/msg/planner_result.hpp"
#include <navigator/DataStoreObjects.hpp>
#include <navigator/DataStore.hpp>
#include "navigator/LogHelper.hpp"

namespace navigator {
namespace cl_global_planner {

class CbGetGlobalPlan : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
  CbGetGlobalPlan() = default;

  ~CbGetGlobalPlan() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }
    std::string getLogName() { return "CbGetGlobalPlan"; }

  void onExit() override {
      _sub_plan.reset();
    }

  void onEntry() override {

    std::string topicname = "/global_planner/result";

    rclcpp::SubscriptionOptions sub_option;
    _sub_plan = getNode()->create_subscription<inspection_interfaces::msg::PlannerResult>(topicname, rclcpp::ServicesQoS(),
                                                                                          std::bind(&CbGetGlobalPlan::onMessageReceived, this,
                                                                            std::placeholders::_1), sub_option);

    // make publisher and send request for global-plan
    auto _pub = getNode()->create_publisher<inspection_interfaces::msg::PlannerRequest>("/global_planner/request", rclcpp::ServicesQoS());
    inspection_interfaces::msg::PlannerRequest _msg;

    // get objects from store to transmit planner request
    DataStore *_ds;
    this->getStateMachine()->getGlobalSMData("datastore", _ds);

    auto _dronePos = _ds->getDronePos();
    auto _dronePoseLocal = _ds->getDronePoseLocal();
    auto _turInfo = _ds->getTurbineInfo();
    auto _lidarInfo = _ds->getLidarInfo();

    _msg.blade_length = _turInfo.blade_length;
    _msg.dist_blade_target = _turInfo.blade_distance_target;
    _msg.first_blade = _turInfo.first_blade;
    _msg.first_blade_rotation = _turInfo.first_blade_rotation;
    _msg.overlap_procentage = _turInfo.overlap_procentage;
    _msg.dist_blade_current = _turInfo.current_distance_lidar;
    _msg.current_pos_global.latitude = _dronePos.lat;
    _msg.current_pos_global.longitude = _dronePos.lon;
    _msg.current_pos_global.altitude = _dronePos.alt;
    _msg.current_pose.orientation.w = _dronePoseLocal.q_w;
    _msg.current_pose.orientation.x = _dronePoseLocal.q_x;
    _msg.current_pose.orientation.y = _dronePoseLocal.q_y;
    _msg.current_pose.orientation.z = _dronePoseLocal.q_z;
    _msg.current_pose.position.x = _dronePoseLocal.x;
    _msg.current_pose.position.y = _dronePoseLocal.y;
    _msg.current_pose.position.z = _dronePoseLocal.z;
    _msg.inspect_targets = _turInfo.inspect_targets;
    _msg.hub_offset = _turInfo.hub_offset;
    _msg.vertical_safety = _turInfo.vertical_safety;
    _msg.hub_center_px_x = _turInfo.hub_center_px_x;
    _msg.hub_center_px_y = _turInfo.hub_center_px_y;

    _pub->publish(_msg);

    std::stringstream log_msg;
    log_msg << "Asking Global Planner for route... Start Pos: x: " << _dronePoseLocal.x << ", y: " << _dronePoseLocal.y << ", z: " << _dronePoseLocal.z
    << ", lat: " << _dronePos.lat << ", lon: " << _dronePos.lon << ", alt: " << _dronePos.alt << ", vertical safety: " << _turInfo.vertical_safety;
    log_info(log_msg.str());
  }

private:
  void onMessageReceived(const inspection_interfaces::msg::PlannerResult::SharedPtr msg) {
    // get objects from store
    DataStore *_ds;
    this->getStateMachine()->getGlobalSMData("datastore", _ds);
    _ds->setCurrentMissionPlan(*msg);
    _ds->setCurrentMissionIndex(0);

    postSuccessEvent();

    log_info("Received plan from Global Planner of " + to_string(msg->plan.size()) + " points, moving to flight execution state");
  }

  rclcpp::Subscription<inspection_interfaces::msg::PlannerResult>::SharedPtr _sub_plan;
};
}
}
