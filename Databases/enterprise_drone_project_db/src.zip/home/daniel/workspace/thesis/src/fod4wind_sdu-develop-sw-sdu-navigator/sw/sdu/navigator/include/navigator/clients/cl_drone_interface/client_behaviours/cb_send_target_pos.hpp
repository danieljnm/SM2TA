
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_drone_interface/cl_drone_interface.hpp>
#include <condition_variable>
#include <navigator/navigator.hpp>
#include <mavros_msgs/msg/position_target.hpp>
#include "interfaces/msg/gimbal_attitude.hpp"
#include "interfaces/msg/larke_position_target.hpp"
#include <tf2/convert.h>
#include <tf2/transform_datatypes.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <inspection_interfaces/msg/trajectory.hpp>
#include "navigator/LogHelper.hpp"

// 5 hz
#define UPDATE_RATE (1000000000/5)

namespace navigator {
namespace cl_drone_interface {

class CbSendTargetPos : public smacc2::SmaccClientBehavior, public smacc2::ISmaccUpdatable, LogHelper {
public:
    CbSendTargetPos() : ISmaccUpdatable(rclcpp::Duration(0,UPDATE_RATE)) {}
    ~CbSendTargetPos() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }
    std::string getLogName() { return "CbSendTargetPos"; }

    void onExit() override {
        // unsub subs/pubs
        _sub_mavros_setpoint.reset();
        _pub_position_target.reset();
        _pub_gimbal.reset();
    }

    void onEntry() override {

        // set target pos
        _pub_position_target = getNode()->create_publisher<interfaces::msg::LarkePositionTarget>("/drone_commander/cmd/setpoint_raw", rclcpp::ServicesQoS());
        _pub_gimbal = getNode()->create_publisher<interfaces::msg::GimbalAttitude>("/drone_commander/cmd/set_gimbal_attitude", rclcpp::ServicesQoS());
        _pub_localplanner_curr_target = getNode()->create_publisher<inspection_interfaces::msg::Trajectory>("/local_planner/set_current_targets", rclcpp::ServicesQoS());

        // _sub_mavros_setpoint = getNode()->create_subscription<mavros_msgs::msg::PositionTarget>("/mavros/setpoint_raw/local", rclcpp::SensorDataQoS(), std::bind(&CbSendTargetPos::onMessageSetpointRaw, this, std::placeholders::_1));

        // get current data from datastore
        DataStore *_ds;
        this->getStateMachine()->getGlobalSMData("datastore", _ds);

        auto _plan = _ds->getCurrentMissionPlan();
        auto _index = _ds->getCurrentMissionIndex();

        // Required even when we are checking on state-entry. Not guranteed that state transition will trigger before this onEntry
        if (_index >= _plan.plan.size()) {
            log_info("Stopping SendTargetPos as current mission index is: " + std::to_string(_index) + ", and plan size is: " + std::to_string(_plan.plan.size()-1));
            return;
        }

        // TRY
        try {
            // get target pos
            auto _targetPos = _plan.plan[_index];
            _msg.position = _targetPos.pose.pose.position;

            // type flag, set to only use position and yaw: http://docs.ros.org/en/api/mavros_msgs/html/msg/PositionTarget.html
            _msg.type_mask = 0b100111111000;

            // convert pose to rpy, and set yaw
            float yaw = PositionHelper::yawFromQuat(_targetPos.pose.pose.orientation);
            _msg.yaw = yaw;

            // Required by Upteko
            _msg.coordinate_frame = 1; // MAV_FRAME_BODY_NED
            _msg.header.stamp = getNode()->now();
            _msg.header.frame_id = "navigator";

            _pub_position_target->publish(_msg);
            log_info("Sent request to waypoint: x: " + std::to_string(_msg.position.x) + ", y: " + std::to_string(_msg.position.y) + ", z: " + std::to_string(_msg.position.z) + ", yaw: " + std::to_string(_msg.yaw));

            // gimbal message
            _gimbal_msg.orientation = _targetPos.gimbal_pose.quaternion;
            _gimbal_msg.gimbal_device_id = 154;
            _gimbal_msg.flags = 44; // yaw in vehicle frame, lock roll and pitch to angle from horizon. (standard on stabilized gimbals)
            // set NaN on velocity, if it doesn't react, might need to set a wanted rate
            _gimbal_msg.angular_velocity_x = NAN;
            _gimbal_msg.angular_velocity_y = NAN;
            _gimbal_msg.angular_velocity_z = NAN;

            _pub_gimbal->publish(_gimbal_msg);
            log_info("Sent request to gimbal in pose: x: " + std::to_string(_gimbal_msg.orientation.x) + ", y: " + std::to_string(_gimbal_msg.orientation.y) + ", z: " + std::to_string(_gimbal_msg.orientation.z) + ", w: " + std::to_string(_gimbal_msg.orientation.w));

            // publish target pos for local-planner send list from current to next transition
            inspection_interfaces::msg::Trajectory _targetPoints;
            _targetPoints.mission_index = _index;

            // loop through current point up to transition point in the next side. So we correct the next side too
            bool reached_transition = false;
            bool side_change = false;
            std::string current_side = _plan.plan[_index].blade_side;
            std::string current_blade = _plan.plan[_index].blade_id;

            for (auto i = _index; i < _plan.plan.size(); i++)
            {
                auto item = &_plan.plan[i];

                //if we have reached a third side, we are outside where we want to correct and break before adding the point
                // break here if current item is from a 3rd side. Transitions points don't have side labels, so we don't use those to check
                // break straight away if we are on new blade. We don't mix blades
                if (item->blade_id != current_blade || (side_change && current_side != item->blade_side && item->action == 1)) {
                    break;
                }

                // make point-stamped
                auto ps = PositionHelper::buildPoint(item->pose.pose.position.x, item->pose.pose.position.y, item->pose.pose.position.z, item->pose.header.frame_id);

                // add to msg
                _targetPoints.points.push_back(*item);

                if (!side_change && item->blade_side != current_side && item->action == 1) {
                    side_change = true;
                    current_side = item->blade_side;
                }
            }

            _pub_localplanner_curr_target->publish(_targetPoints);

            // don't exit and potentially clean up the publishers before our target and gimbal pose has been acked!
            _pub_position_target->wait_for_all_acked();
            _pub_gimbal->wait_for_all_acked();
        }
        catch (const std::exception& e) {
            log_info("SendTargetPos experienced an exception and exited:");
            log_info(e.what());
            return;
        }
    }
    void update() override
    {
        //if (_ready)
        //{
        //  _pub_position_target->publish(_msg);
        //  _pub_gimbal->publish(_gimbal_msg);
        //}
    }

private:
    // void onMessageSetpointRaw(const mavros_msgs::msg::PositionTarget::SharedPtr msg) {
    //   // validate if the current published setpoint is == to our requested setpoint.
    //   //  A hacky way to ensure this node gets closed, but not before the setpoint has been accepted
    //   if (msg->position == _msg.position) {
    //     this->dispose();
    //   }
    // }
    bool _ready = false;
    interfaces::msg::LarkePositionTarget _msg;
    interfaces::msg::GimbalAttitude _gimbal_msg;
    rclcpp::Subscription<mavros_msgs::msg::PositionTarget>::SharedPtr _sub_mavros_setpoint;
    rclcpp::Publisher<interfaces::msg::LarkePositionTarget>::SharedPtr _pub_position_target;
    rclcpp::Publisher<interfaces::msg::GimbalAttitude>::SharedPtr _pub_gimbal;
    rclcpp::Publisher<inspection_interfaces::msg::Trajectory>::SharedPtr _pub_localplanner_curr_target;
};
}
}

//Ignore everything but yaw and position: 0b100111111000
//uint16 IGNORE_PX = 1 # Position ignore flags
//uint16 IGNORE_PY = 2
//uint16 IGNORE_PZ = 4
//uint16 IGNORE_VX = 8 # Velocity vector ignore flags
//uint16 IGNORE_VY = 16
//uint16 IGNORE_VZ = 32
//uint16 IGNORE_AFX = 64 # Acceleration/Force vector ignore flags
//uint16 IGNORE_AFY = 128
//uint16 IGNORE_AFZ = 256
//uint16 FORCE = 512 # Force in af vector flag
//uint16 IGNORE_YAW = 1024
//uint16 IGNORE_YAW_RATE = 2048
