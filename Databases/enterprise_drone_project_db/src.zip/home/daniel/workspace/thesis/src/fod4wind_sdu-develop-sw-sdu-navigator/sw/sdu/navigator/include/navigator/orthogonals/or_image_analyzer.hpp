#pragma once

#include <navigator/clients/cl_image_analyzer/cl_image_analyzer.hpp>
#include <smacc2/smacc_orthogonal.hpp>

namespace navigator
{
    using namespace navigator::cl_image_analyzer;

    class OrImageAnalyzer : public smacc2::Orthogonal<OrImageAnalyzer>
    {
    public:
        void onInitialize() override
        {
            auto subscriber_image_analyzer_client = this->createClient<ClImageAnalyzer>();
        }
    };
}  // namespace