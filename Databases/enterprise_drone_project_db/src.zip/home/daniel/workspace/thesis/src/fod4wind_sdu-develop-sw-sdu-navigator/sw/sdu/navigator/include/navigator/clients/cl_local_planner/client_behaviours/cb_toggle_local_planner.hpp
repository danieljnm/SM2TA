
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <std_msgs/msg/bool.hpp>
#include "navigator/LogHelper.hpp"

namespace navigator {
namespace cl_local_planner {

class CbToggleLocalPlanCorrections : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
  explicit CbToggleLocalPlanCorrections(bool enable): _enable(enable) {}

  ~CbToggleLocalPlanCorrections() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }
    std::string getLogName() { return "CbToggleLocalPlanCorrections"; }

  void onExit() override {
      _pub_local_planner_enable.reset();
    }

  void onEntry() override {
      _pub_local_planner_enable = getNode()->create_publisher<std_msgs::msg::Bool>("/local_planner/activate", rclcpp::ServicesQoS());

      // publish message based on argument
      std_msgs::msg::Bool msg;
      msg.data = _enable;
      _pub_local_planner_enable->publish(msg);
      log_info("Published request for local planner corrections turn on: " + std::to_string(_enable));
  }

private:
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr _pub_local_planner_enable;
  bool _enable = false;
};
}
}
