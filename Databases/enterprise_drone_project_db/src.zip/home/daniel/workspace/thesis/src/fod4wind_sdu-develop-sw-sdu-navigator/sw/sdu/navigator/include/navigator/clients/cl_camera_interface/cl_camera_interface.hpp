#pragma once
#include <smacc2/smacc.hpp>
#include <std_msgs/msg/float32.hpp>


namespace navigator
{
namespace cl_camera_interface
{
class ClCameraInterface : public smacc2::ISmaccClient
{
public:
  ClCameraInterface()= default;

//  ~ClImageAnalyzer() override= default;;
//
//  void onInitialize() override;
};
}  // namespace cl_image_analyzer
}  // namespace navigator