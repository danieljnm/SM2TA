
#pragma once

#include "navigator/LogHelper.hpp"
#include <chrono>
#include <condition_variable>
#include <interfaces/srv/capture_image_with_exif.hpp>
#include <navigator/clients/cl_camera_interface/cl_camera_interface.hpp>
#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <std_msgs/msg/float32.hpp>
#include "navigator/Helpers.hpp"

using namespace std::chrono_literals;

namespace navigator {
namespace cl_camera_interface {

class CbTakePicture : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
  CbTakePicture() = default;

  ~CbTakePicture() override = default;

  // Log Function configs
  rclcpp::Logger getNodeLogger() { return this->getLogger(); }

  std::string getLogName() { return "CbTakePicture"; }

  void onEntry() override {
    // TODO when validation does actual validation this needs to either tell validator no image is needed so don't validate
    //  or implement in nextPos state to be able to go straight for next pos, without going through capture and validate states
    //  Can be done direct, or a new "transition" state could be made that just updates the mission index and returns back to nextPos
    // check if current waypoint is transition, if it is, skip to validation
    DataStore *_ds;
    this->getStateMachine()->getGlobalSMData("datastore", _ds);
    auto _plan = _ds->getCurrentMissionPlan();
    auto _index = _ds->getCurrentMissionIndex();

    // Capture = 1, Transition = 2
    if (_plan.plan[_index].action == 2) {
        log_info("Action is transition, no image needs to be taken, just move on straight away");
        postSuccessEvent();
    } else {
        // call function to capture image
        captureImage();
    }
  }

  void onExit() override {
      // stop services
      capture_srv.reset();
  }

private:
  void captureImage() {
    capture_srv = getNode()->create_client<interfaces::srv::CaptureImageWithExif>(
                    "/camera_sony_sdk/capture_image_with_exif_srv");

    // take picture and save where we can use it...
    log_info("Asking to save image...");

    try {
      // get meta-data required
      DataStore *_ds;
      this->getStateMachine()->getGlobalSMData("datastore", _ds);

      // target point
      auto _plan = _ds->getCurrentMissionPlan();
      auto _index = _ds->getCurrentMissionIndex();
      auto _targetPos = _plan.plan[_index];

      auto _turInfo = _ds->getTurbineInfo();
      auto _lidarInfo = _ds->getLidarInfo();
      auto _dronePos = _ds->getDronePos();
      auto _missionPlan = _ds->getCurrentMissionPlan();

      // local
      auto _dronePoseLocal = _ds->getDronePoseLocal();
      auto _gimbalPose = _ds->getGimbalPose();

      // filename with full path
      auto _filename = MetadataHelper::buildImagePathAndFileName(_index, _targetPos.blade_id, _targetPos.blade_side,
                                                                 _targetPos.motion_dir);

      // Create request object and send to service
      auto request =
              std::make_shared<interfaces::srv::CaptureImageWithExif::Request>();

      request->header.stamp = this->getNode()->now();
      request->cmd = request->CAPTURE_IMAGE;
      request->name = _filename;
      request->focal_distance = _lidarInfo.curr_distance;

      request->exif_data.file_name = _filename;
      request->exif_data.header.stamp = this->getNode()->now();
      request->exif_data.blade_side = _targetPos.blade_side;
      request->exif_data.blade_abc = _targetPos.blade_id;
      request->exif_data.altitude_msl = _dronePos.alt;
      request->exif_data.latitude = _dronePos.lat;
      request->exif_data.longitude = _dronePos.lon;
      request->exif_data.drone_pose = PositionHelper::buildPose(_dronePoseLocal); // LOCAL POSE
      request->exif_data.gimbal_orientation = PositionHelper::buildQuat(_gimbalPose.q_x, _gimbalPose.q_y,
                                                                        _gimbalPose.q_z,
                                                                        _gimbalPose.q_w);
      request->exif_data.hub_location = _missionPlan.local_hub_init_pose.position;
      request->exif_data.inspection_id = "1"; // TODO is hardcoded for now, in future should depend on input from user? Or otherwise be told based on files on SD card, which is the next number?
      request->exif_data.sequence_direction = _targetPos.motion_dir;
      request->exif_data.lidar_frames = _lidarInfo.dists;


      auto result = capture_srv->async_send_request(request);
      result.wait_for(10s); //blocking for 10sec or until answer is ready

      // result of request to camera handler
      if (result.get()) {
        // we succeed
          log_info("Returned: True, Image captured");
          postSuccessEvent();
      } else {
          log_info("Failed to get answer from takepicture service, retrying...");
          captureImage();
      }

    } catch (const std::exception &e) {
      log_info("Failed to call service camera/captureimage with exception" +
               to_string(e) + ", trying again...");
      log_info(e.what());
      captureImage();
    }
  }
    rclcpp::Client<interfaces::srv::CaptureImageWithExif>::SharedPtr capture_srv;
};
} // namespace cl_camera_interface
} // namespace navigator
