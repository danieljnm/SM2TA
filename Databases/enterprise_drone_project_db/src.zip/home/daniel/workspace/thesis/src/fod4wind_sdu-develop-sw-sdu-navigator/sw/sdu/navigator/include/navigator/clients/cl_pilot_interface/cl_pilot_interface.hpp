#pragma once
#include <smacc2/smacc.hpp>
#include <std_msgs/msg/float32.hpp>

namespace navigator
{
namespace cl_pilot_interface
{
class ClPilotInterface : public smacc2::ISmaccClient
{
public:
  ClPilotInterface()= default;

//  ~ClImageAnalyzer() override= default;;
//
//  void onInitialize() override;
};
}  // namespace cl_image_analyzer
}  // namespace navigator