
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_image_analyzer/cl_image_analyzer.hpp>
#include <condition_variable>
#include <cv_interfaces/srv/estimate_start_position.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <inspection_interfaces/msg/start_pos_estimation_request.hpp>
#include <inspection_interfaces/msg/turbine_pose.hpp>
#include "navigator/LogHelper.hpp"
#include <vector>
#include <fstream>
#include <chrono>
#include <filesystem>

using namespace std::chrono_literals;

namespace navigator {
namespace cl_image_analyzer {

class CbEstimateStartPosition : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
    CbEstimateStartPosition() = default;
    ~CbEstimateStartPosition() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }
    std::string getLogName() { return "CbEstimateStartPosition"; }

    void onExit() override {
        _sub_request_start_pos_estimation.reset();
        _srv_start_position_esitmator.reset();
        _pub_turbine_pose.reset();
        stop_thread = true;
        t_file.join();
    }

    void onEntry() override {

        _sub_request_start_pos_estimation = getNode()->create_subscription<inspection_interfaces::msg::StartPosEstimationRequest>("/navigator/start_estimation/request",
                                                                                                                                  rclcpp::ServicesQoS(),
                                                                                                                                  [this](inspection_interfaces::msg::StartPosEstimationRequest::SharedPtr msg) {
                                                                                                                                      onMessageReceived(std::move(msg));
                                                                                                                                  });

        _srv_start_position_esitmator = getNode()->create_client<cv_interfaces::srv::EstimateStartPosition>("estimate_start_position", rmw_qos_profile_services_default);
        _pub_turbine_pose = getNode()->create_publisher<inspection_interfaces::msg::TurbinePose>("/turbine_blade_initial_pose", rclcpp::ServicesQoS());

        log_info("Waiting on msg with filepath to image to estimate");
    }

private:
    void responseReceivedFromVision(rclcpp::Client<cv_interfaces::srv::EstimateStartPosition>::SharedFuture inner_future) {
        // result of request to camera handler
        const auto& response = inner_future.get();
        if (response) {
            // we succeed
            log_info("Got start estimation, sending turbine pose...");
            inspection_interfaces::msg::TurbinePose tur_pose;
            tur_pose.pixel_center_x = response->center_px_x;
            tur_pose.pixel_center_y = response->center_px_y;
            tur_pose.first_blade_rotation = response->rotation_deg;
            tur_pose.current_distance_lidar = lidar_distance;

            // use the result of the service to pub the data needed for initial blade pos estimation
            _pub_turbine_pose->publish(tur_pose);

        } else {
            log_info("ERROR: Failed to get answer from Start Position Estimator service");
            postFailureEvent();
        }
    }
    // checks if file exists with 200ms sleep between checks
    void fileExists(std::string path) {
        while (!std::filesystem::exists(path) && !stop_thread.load())
        {
            auto debug = std::filesystem::exists(path);
            log_info("Testing if file exists: path: " + path + ", result: " + std::to_string(debug));
            // sleep for 200ms, so we only check for file existing 5 times a second. Should save resources
            std::this_thread::sleep_for(std::chrono::milliseconds(200));
        }
    }
    void waitingForFile(std::string path) {
        // new we are in new thread spawn a future that actually checks when file is ready or timeout in 10s
        auto fut = std::async(std::launch::async, [this, path] { fileExists(path); });

        // wait for file to be available
        if (fut.wait_for(10s) == std::future_status::timeout) {
            log_info("ERROR: Timed out waiting on file, returning to IDLE");
            stop_thread = true;
            postFailureEvent();
            return;
        }

        log_info("INFO: file is available on disk, attempting to read to send to vision node");

        std::ifstream file(path, std::ios::binary);
        while (!file)
        {
            log_info("ERROR: Could not open image file");
            stop_thread = true;
            postFailureEvent();
            return;
        }
        // read the file into the buffer
        std::vector<unsigned char> buffer(std::istreambuf_iterator<char>(file), {});

        // make request
        auto request = std::make_shared<cv_interfaces::srv::EstimateStartPosition::Request>();

        // get image size data from datastore
        DataStore *_ds;
        this->getStateMachine()->getGlobalSMData("datastore", _ds);
        auto camInfo = _ds->getCamInfo();

        // put uint8 into ros message for vision
        request->frame_jpeg = buffer;
        request->target_width = camInfo.image_width; //don't need lock as this is set in start-up params
        request->target_height = camInfo.image_height; //and never changed

        log_info("Asking vision nodes to estimate start location from given image");
        
        // send image to service
        _srv_start_position_esitmator->async_send_request(request,
                                                          [&,this](rclcpp::Client<cv_interfaces::srv::EstimateStartPosition>::SharedFuture inner_future)
                                                          {responseReceivedFromVision(std::move(inner_future));}
        );
    }

    void onMessageReceived(const inspection_interfaces::msg::StartPosEstimationRequest::SharedPtr msg) {
        // use filepath to load image into byte array, then use the service to request vision processing
        auto path = msg->filepath;

        // save lidar distance
        lidar_distance = msg->current_lidar_distance;

        log_info("Attempting to read image from disk to pass on to vision estimator");

        // spawning function to not block callback
        t_file = std::thread( [this, path] { waitingForFile(path); } );
    }

//  std::mutex mutex;
    rclcpp::Subscription<inspection_interfaces::msg::StartPosEstimationRequest>::SharedPtr _sub_request_start_pos_estimation;
    rclcpp::Client<cv_interfaces::srv::EstimateStartPosition>::SharedPtr _srv_start_position_esitmator;
    rclcpp::Publisher<inspection_interfaces::msg::TurbinePose>::SharedPtr _pub_turbine_pose;

    // vars
    double lidar_distance = 0;
    std::thread t_file;
    std::atomic<bool> stop_thread = false;
};
}
}
