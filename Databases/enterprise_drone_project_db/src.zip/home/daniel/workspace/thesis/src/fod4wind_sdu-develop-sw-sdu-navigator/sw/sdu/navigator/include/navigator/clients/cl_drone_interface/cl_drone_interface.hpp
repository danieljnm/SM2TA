#pragma once
#include <smacc2/smacc.hpp>
#include <std_msgs/msg/float32.hpp>

namespace navigator
{
namespace cl_drone_interface
{

class ClDroneInterface : public smacc2::ISmaccClient
{
public:
  ClDroneInterface()= default;

  ~ClDroneInterface() override= default;
};
}  // namespace cl_image_analyzer
}  // namespace navigator