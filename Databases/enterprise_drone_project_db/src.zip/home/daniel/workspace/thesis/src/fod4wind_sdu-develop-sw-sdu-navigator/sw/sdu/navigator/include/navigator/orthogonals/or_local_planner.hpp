#pragma once

#include <navigator/clients/cl_local_planner/cl_local_planner.hpp>
#include <smacc2/smacc_orthogonal.hpp>

namespace navigator
{
    using namespace navigator::cl_local_planner;

    class OrLocalPlanner : public smacc2::Orthogonal<OrLocalPlanner>
    {
    public:
        void onInitialize() override
        {
            //
            auto subscriber_local_planner_client = this->createClient<ClLocalPlanner>();
        }
    };
}  // namespace