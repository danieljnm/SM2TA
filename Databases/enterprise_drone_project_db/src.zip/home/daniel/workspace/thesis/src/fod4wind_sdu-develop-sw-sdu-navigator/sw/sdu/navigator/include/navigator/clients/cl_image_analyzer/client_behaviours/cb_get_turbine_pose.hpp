
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_image_analyzer/cl_image_analyzer.hpp>
#include <condition_variable>
#include <inspection_interfaces/msg/turbine_pose.hpp>
#include "navigator/LogHelper.hpp"

namespace navigator {
namespace cl_image_analyzer {

class CbGetTurbinePose : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
  CbGetTurbinePose() = default;
  ~CbGetTurbinePose() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }
    std::string getLogName() { return "CbGetTurbinePose"; }

  void onExit() override {
      _sub_pose.reset();
    }

  void onEntry() override {

    std::string topicname = "/turbine_blade_initial_pose";

    _sub_pose = getNode()->create_subscription<inspection_interfaces::msg::TurbinePose>(topicname, rclcpp::ServicesQoS(),
                                                                                        [this](inspection_interfaces::msg::TurbinePose::SharedPtr msg) {
                                                                                            onMessageReceived(std::move(msg));
                                                                                        });

    log_info("Asking vision nodes for detected pose");

  }

private:
  void onMessageReceived(const inspection_interfaces::msg::TurbinePose::SharedPtr msg) {
    // save pose in datastore
    DataStore* _ds;
    this->getStateMachine()->getGlobalSMData("datastore", _ds);

    auto _turInfo = _ds->getTurbineInfo();
    _turInfo.first_blade_rotation = msg->first_blade_rotation;
    _turInfo.current_distance_lidar = msg->current_distance_lidar;
    _turInfo.hub_center_px_x = msg->pixel_center_x;
    _turInfo.hub_center_px_y = msg->pixel_center_y;
    _ds->setTurbineInfo(_turInfo);

    postSuccessEvent();
  }

//  bool triggered = false;
//  std::mutex mutex;
  rclcpp::Subscription<inspection_interfaces::msg::TurbinePose>::SharedPtr _sub_pose;
};
}
}
