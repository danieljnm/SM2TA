#pragma once

#include <navigator/clients/cl_global_planner/cl_global_planner.hpp>
#include <smacc2/smacc_orthogonal.hpp>

namespace navigator
{
    using namespace navigator::cl_global_planner;

    class OrGlobalPlanner : public smacc2::Orthogonal<OrGlobalPlanner>
    {
    public:
        void onInitialize() override
        {
            //
            auto subscriber_global_planner_client = this->createClient<ClGlobalPlanner>();
        }
    };
}  // namespace