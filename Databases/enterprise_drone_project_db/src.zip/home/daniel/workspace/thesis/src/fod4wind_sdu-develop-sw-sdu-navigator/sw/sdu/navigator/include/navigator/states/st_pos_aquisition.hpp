#pragma once

#include "smacc2/smacc.hpp"
#include "navigator/LogHelper.hpp"

// ORTHOGONALS
#include <navigator/orthogonals/or_pilot_interface.hpp>
#include <navigator/orthogonals/or_image_analyzer.hpp>

namespace navigator {
// SMACC2 clases
using smacc2::Transition;
using smacc2::EvStateRequestFinish;
using smacc2::default_transition_tags::SUCCESS;

// STATE DECLARATION
struct PosAquisitionState : smacc2::SmaccState<PosAquisitionState, Navigator> {
  using SmaccState::SmaccState;

  // DECLARE CUSTOM OBJECT TAGS
  struct ON_SYSTEMS_READY : SUCCESS {};
  struct LOST_CONTROL : ABORT{};
  struct FAILED_ESTIMATION : ABORT{};

  std::string _prefix = "[POS_AQUISITION] ";

  struct SrInspectionReady;

  // TRANSITION TABLE - adjust as needed
  typedef boost::mpl::list<

      Transition<EvAllGo<SrAllEventsGo, SrInspectionReady>, GlobalPlanningState, ON_SYSTEMS_READY>,
      Transition<EvCbFailure<CbCheckControl, OrHasControl>, IdleState, LOST_CONTROL>,
      Transition<EvCbFailure<CbEstimateStartPosition, OrImageAnalyzer>, IdleState, FAILED_ESTIMATION>,
      Transition<EvCbFailure<CbTakeStartPositionPicture, OrCameraInterface>, IdleState, FAILED_ESTIMATION>,
      Transition<EvGlobalError, IdleState, ABORT>

  > reactions;

  // STATE FUNCTIONS
  static void staticConfigure() {
    // configure orthogonal
    configure_orthogonal<OrPilotInterface, CbRequestInspectionTargets>();
    configure_orthogonal<OrDroneInterface, CbSendNeutralPos>();
    configure_orthogonal<OrCameraInterface, CbTakeStartPositionPicture>();
    configure_orthogonal<OrImageAnalyzer, CbEstimateStartPosition>();
    configure_orthogonal<OrImageAnalyzer, CbGetTurbinePose>();
    configure_orthogonal<OrHasControl, CbCheckControl>();
    configure_orthogonal<OrDroneInterface, CbUpdateDroneData>();

    // Create State Reactor
    static_createStateReactor<
        SrAllEventsGo, smacc2::state_reactors::EvAllGo<SrAllEventsGo, SrInspectionReady>,
        mpl::list<
            EvCbSuccess<CbRequestInspectionTargets, OrPilotInterface>,
            EvCbSuccess<CbGetTurbinePose, OrImageAnalyzer>
        >>();
  }

  void runtimeConfigure() {}

  void onEntry() {
    LogHelper::log_info(getLogger(), _prefix, "Entered Aquisition...");
  }

  void onExit() {}
};
}
