#pragma once

#include "rclcpp/rclcpp.hpp"
#include "smacc2/smacc.hpp"
#include "navigator/LogHelper.hpp"

namespace navigator
{
// STATE DECLARATION
struct StiValidateState : smacc2::SmaccState<StiValidateState, Navigator>
{
public:
  using SmaccState::SmaccState;

  // DECLARE CUSTOM OBJECT TAGS
  struct LOST_CONTROL : ABORT{};
  struct NEXT : SUCCESS{};
  struct PREVIOUS : ABORT{};

  std::string _prefix = "[VALIDATION] ";

  // TRANSITION TABLE
  typedef mpl::list<

    Transition<EvCbFailure<CbCheckControl, OrHasControl>, IdleState, LOST_CONTROL>,
    Transition<EvCbSuccess<CbValidateImage, OrImageAnalyzer>, StiNextPosState, NEXT>

  >reactions;

  // STATE FUNCTIONS
  static void staticConfigure() {
    configure_orthogonal<OrHasControl, CbCheckControl>();
    configure_orthogonal<OrDroneInterface, CbUpdateDroneData>();
    configure_orthogonal<OrImageAnalyzer, CbValidateImage>();
  }

  void runtimeConfigure() {}

  void onEntry() {
    // get data store
    DataStore* _ds;
    this->getStateMachine().getGlobalSMData("datastore", _ds);
    auto _currentIndex = _ds->getCurrentMissionIndex();
    LogHelper::log_info(getLogger(), _prefix, "Validating image captured at waypoint: " + std::to_string(_currentIndex));
  }

  void onExit() { }
};
}  // namespace navigator