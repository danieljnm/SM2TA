
#pragma once

#include <memory>
#include <string>
#include <std_msgs/msg/string.hpp>
#include "DataStoreObjects.hpp"
#include "DataStore.hpp"

#include "smacc2/smacc.hpp"

//STATE REACTORS
#include <sr_all_events_go/sr_all_events_go.hpp>
using namespace smacc2::state_reactors;
using namespace smacc2::default_events;

// ORTHOGONALS
//#include "navigator/orthogonals/or_timer.hpp"
#include "orthogonals/or_has_control.hpp"
#include "orthogonals/or_pilot_interface.hpp"
#include "orthogonals/or_drone_interface.hpp"
#include "orthogonals/or_image_analyzer.hpp"
#include "orthogonals/or_global_planner.hpp"
#include "orthogonals/or_camera_interface.hpp"
#include "orthogonals/or_local_planner.hpp"

// DATA STORE OBJECTS
#include "DataStoreObjects.hpp"
#include "custom_defines.hpp"
#include "DataStore.hpp"

// SMACC2 clases
//using navigator::OrTimer;  // This is example variable - feel free to delete it.
using namespace navigator::cl_has_control;
#include "clients/cl_has_control/client_behaviours/cb_in_control_subscriber_behaviour.hpp"

using namespace navigator::cl_pilot_interface;
#include "clients/cl_pilot_interface/client_behaviours/cb_request_inspection_targets.hpp"
#include "clients/cl_pilot_interface/client_behaviours/cb_post_mission_notice.hpp"

using namespace navigator::cl_drone_interface;
#include "clients/cl_drone_interface/client_behaviours/cb_target_pos_checker.hpp"
#include "clients/cl_drone_interface/client_behaviours/cb_start_offboard.hpp"
#include "clients/cl_drone_interface/client_behaviours/cb_start_loiter.hpp"
#include "clients/cl_drone_interface/client_behaviours/cb_send_target_pos.hpp"
#include "clients/cl_drone_interface/client_behaviours/cb_send_neutral_pos.hpp"
#include "clients/cl_drone_interface/client_behaviours/cb_update_drone_data.hpp"

using namespace navigator::cl_image_analyzer;
#include "clients/cl_image_analyzer/client_behaviours/cb_get_turbine_pose.hpp"
#include "clients/cl_image_analyzer/client_behaviours/cb_estimate_start_position.hpp"
#include "clients/cl_image_analyzer/client_behaviours/cb_validate_image.hpp"

using namespace navigator::cl_global_planner;
#include "clients/cl_global_planner/client_behaviours/cb_get_global_plan.hpp"

using namespace navigator::cl_camera_interface;
#include "clients/cl_camera_interface/client_behaviours/cb_take_picture.hpp"
#include "clients/cl_camera_interface/client_behaviours/cb_take_start_position_picture.hpp"

using namespace navigator::cl_local_planner;
#include "clients/cl_local_planner/client_behaviours/cb_get_local_plan_corrections.hpp"
#include "clients/cl_local_planner/client_behaviours/cb_toggle_local_planner.hpp"


using namespace smacc2;

namespace navigator
{

// custom navigator event
struct EvGlobalError : sc::event<EvGlobalError>{};

// SUPERSTATES
namespace mission_executor_super_state
{
class mission_executor_state;
}  // namespace mission_executor_super_state

//STATES
struct IdleState;
struct PosAquisitionState;
struct GlobalPlanningState;
struct MissionCompletedState;
struct StiNextPosState;
struct StiCaptureState;
struct StiValidateState;

//--------------------------------------------------------------------
//STATE_MACHINE
struct Navigator
        : public smacc2::SmaccStateMachineBase<Navigator, IdleState>
{
    using SmaccStateMachineBase::SmaccStateMachineBase;

    // Datastore, make our own datastore with needed data, instead of using the StringStream system...
    DataStore _ds;

    void onInitialize() override
    {
        // START: Example code - change or delete as needed
        //this->createOrthogonal<OrTimer>();
        this->createOrthogonal<OrHasControl>();
        this->createOrthogonal<OrPilotInterface>();
        this->createOrthogonal<OrImageAnalyzer>();
        this->createOrthogonal<OrGlobalPlanner>();
        this->createOrthogonal<OrDroneInterface>();
        this->createOrthogonal<OrCameraInterface>();
        this->createOrthogonal<OrLocalPlanner>();

        // Use Blackboard to store pointer to our global data-store
        setGlobalSMData("datastore", &_ds);

        // ros params
        this->getNode()->declare_parameter("pos_threshold_m", 1.0);
        this->getNode()->declare_parameter("gimbal_threshold_deg", 1.0);

        this->getNode()->declare_parameter("cam_sensor_height", 35.7);
        this->getNode()->declare_parameter("cam_sensor_width", 23.8);
        this->getNode()->declare_parameter("cam_focal_length", 50.0);
        this->getNode()->declare_parameter("cam_image_width", 9504);
        this->getNode()->declare_parameter("cam_image_height", 6336);

        auto pos_threshold_m = this->getNode()->get_parameter("pos_threshold_m").as_double();
        auto gimbal_threshold_deg = this->getNode()->get_parameter("gimbal_threshold_deg").as_double();

        // camera info
        CameraInfo camInfo;
        camInfo.sensor_width = this->getNode()->get_parameter("cam_sensor_width").as_double();
        camInfo.sensor_height = this->getNode()->get_parameter("cam_sensor_height").as_double();
        camInfo.focal_length = this->getNode()->get_parameter("cam_focal_length").as_double();
        camInfo.image_width = this->getNode()->get_parameter("cam_image_width").as_int();
        camInfo.image_height = this->getNode()->get_parameter("cam_image_height").as_int();

        // save in datastore
        _ds.setPosThresholdM(pos_threshold_m);
        _ds.setGimbalThresholdDeg(gimbal_threshold_deg);
        _ds.setCamInfo(camInfo);
    }

};

}  // namespace navigator

//STATES
#include "states/st_idle.hpp"
#include "states/st_pos_aquisition.hpp"
#include "states/st_global_planning.hpp"
#include "states/st_mission_completed.hpp"
#include "states/sti_next_pos.hpp"
#include "states/sti_capture_state.hpp"
#include "states/sti_validation.hpp"

