
#pragma once

#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <navigator/clients/cl_local_planner/client_behaviours/cb_get_local_plan_corrections.hpp>
#include <condition_variable>
#include <std_msgs/msg/float32.hpp>
#include "inspection_interfaces/msg/planner_request.hpp"
#include "inspection_interfaces/msg/planner_result.hpp"
#include "inspection_interfaces/msg/trajectory.hpp"
#include <navigator/DataStoreObjects.hpp>
#include <navigator/DataStore.hpp>
#include "navigator/LogHelper.hpp"

namespace navigator {
namespace cl_local_planner {

class CbGetLocalPlanCorrections : public smacc2::SmaccAsyncClientBehavior, LogHelper {
public:
  CbGetLocalPlanCorrections() = default;

  ~CbGetLocalPlanCorrections() override = default;

    // Log Function configs
    rclcpp::Logger getNodeLogger() { return this->getLogger(); }
    std::string getLogName() { return "CbGetLocalPlanCorrections"; }

  void onExit() override {
      _sub_point.reset();
      _pub_position_target.reset();
      _pub_viz_mission.reset();
    }

  void onEntry() override {
      _pub_position_target = getNode()->create_publisher<interfaces::msg::LarkePositionTarget>("/drone_commander/cmd/setpoint_raw", rclcpp::ServicesQoS());

      _pub_viz_mission = getNode()->create_publisher<visualization_msgs::msg::MarkerArray>("navigator/missionplan/viz", rclcpp::SensorDataQoS());

      if (_pub_viz_mission == nullptr)
          log_info("Publisher is NULL even though it should just have been created. We are now making Sub and will likely get sigfault");

      // gotta have pubs first, as we trigger on sub messages, so if we got a message before the pub was created we would sigfault.
      _sub_point = getNode()->create_subscription<inspection_interfaces::msg::Trajectory>("local_planner/target_center_point", rclcpp::SensorDataQoS(),
                                                                                          std::bind(&CbGetLocalPlanCorrections::onMessageReceived, this,
                                                                                                    std::placeholders::_1));
  }

private:
  void onMessageReceived(const inspection_interfaces::msg::Trajectory::SharedPtr msg) {
    try {
        // get objects from store
        DataStore *_ds;
        this->getStateMachine()->getGlobalSMData("datastore", _ds);

        auto _missionPlan = _ds->getCurrentMissionPlan();
        auto _missionIndex = _ds->getCurrentMissionIndex();
        const auto _currentTarget = _missionPlan.plan[_missionIndex];

        // check if mission-index is same as mission-index we got in message. As if we transition index as the msg was sent
        //  then the index will not match, and we react on unaligned data
        if (_missionIndex != msg->mission_index) {
            log_info("Mission index does not match index in local corrections, rejecting corrections...");
            return;
        }

        // Check if current action is valid for corrections
        // If current point has local_corrections disabled we also return. It can happen that local-planner will manage
        // to send some measurements when we are in states where gimbal is pitched/yawed, that we dont want to react to
        // Capture = 1,
        // Transition = 2
        if (_currentTarget.action == 2 || !_currentTarget.local_corrections)
          return;

        // check if gimbal is at target rotational requirement, otherwise we skip adjustments. We don't want to adjust based on wrong gimbal measurements
        auto _gimbalPose = _ds->getGimbalPose();
        if (!PositionHelper::GimbalWithinThreshold(this->getLogger(), _gimbalPose, _currentTarget.gimbal_pose.quaternion))
            return;

        // update current and all future points until we hit a transition point
        int t_idx = 0;
        for (int i = _missionIndex; i < _missionPlan.plan.size(); i++)
        {
            auto item = &_missionPlan.plan[i];
            auto item_correction = &msg->points[t_idx];

            // if transition point we skip
            if (item->action == 2) {
                t_idx++; // we still increment index even if skip
                continue;
            }

            // if we run out of correction points we exit
            if (t_idx >= msg->points.size())
                break;

            // add sanity check, if distance from current plan to correction is larger than 5m, then we reject it?
            auto dist = PositionHelper::getDistanceBetweenPoints(item->pose, item_correction->pose);
            if (dist > 15) {
                log_info("Correction distance of " + to_string(dist) + ", is further away from original point than 10m. rejecting correction...");
                //log_info("x: " + to_string(item->pose.pose.position.x) + ", y: " + to_string(item->pose.pose.position.y) + ", z: " + to_string(item->pose.pose.position.z) + ", new pos: x:" + to_string(msg->points[t_idx].pose.pose.position.x) + ", y: " + to_string(msg->points[t_idx].pose.pose.position.y) + ", z: " + to_string(msg->points[t_idx].pose.pose.position.z));

                t_idx++; // need to remember to increment when we skip
                continue; //We skip if it is above the threshold
            }

            // if last point is a transition point with blade_side set as "in_place_transit"
            //  then we modify the last point with same values as this point
            if (t_idx != 0 && item->action == 1 && _missionPlan.plan[i - 1].action == 2 &&_missionPlan.plan[i - 1].blade_side == "in_place_transit") {
                // move last transition points x/y to match current one
                _missionPlan.plan[i - 1].pose.pose.position.set__x(item_correction->pose.pose.position.x);
                _missionPlan.plan[i - 1].pose.pose.position.set__y(item_correction->pose.pose.position.y);
                _missionPlan.plan[i - 1].pose.pose.position.set__z(item_correction->pose.pose.position.z);
                // gimbal pos, only used for visualization
                _missionPlan.plan[i - 1].gimbal_map_pose.pose.position.set__x(item_correction->pose.pose.position.x);
                _missionPlan.plan[i - 1].gimbal_map_pose.pose.position.set__y(item_correction->pose.pose.position.y);
                _missionPlan.plan[i - 1].gimbal_map_pose.pose.position.set__z(item_correction->pose.pose.position.z);
            }

            // else we modify next point
            item->pose.pose.position.set__x(item_correction->pose.pose.position.x);
            item->pose.pose.position.set__y(item_correction->pose.pose.position.y);
            item->pose.pose.position.set__z(item_correction->pose.pose.position.z);
            // gimbal pos, only used for visualization
            item->gimbal_map_pose.pose.position.set__x(item_correction->pose.pose.position.x);
            item->gimbal_map_pose.pose.position.set__y(item_correction->pose.pose.position.y);
            item->gimbal_map_pose.pose.position.set__z(item_correction->pose.pose.position.z);

            t_idx++;
        }

        // save new mission-plan
        _ds->updateMissionItemPlan(_missionPlan.plan);

        // republish entire mission plan markers for visulization. OBS. is a different topic than global-planner to have both visually available if wanted
        _missionPlan = _ds->getCurrentMissionPlan();
        auto vizArray = VisualizeHelper::markerArrayFromPlannerResult(_missionPlan.plan);
        _pub_viz_mission->publish(vizArray);

        // publish new setpoint
        interfaces::msg::LarkePositionTarget _setpointMsg;
        // get target pos
        auto _targetPos = _missionPlan.plan[_missionIndex];
        _setpointMsg.position = _targetPos.pose.pose.position;

        // type flag, set to only use position and yaw: http://docs.ros.org/en/api/mavros_msgs/html/msg/PositionTarget.html
        _setpointMsg.type_mask = 0b100111111000;
        _setpointMsg.coordinate_frame = 1; // BODY frame

        // convert pose to rpy, and set yaw
        float yaw = PositionHelper::yawFromQuat(_targetPos.pose.pose.orientation);
        _setpointMsg.yaw = yaw;

        _pub_position_target->publish(_setpointMsg);
        //log_info("New Target: x: " + std::to_string(_setpointMsg.position.x) + ", y: " + std::to_string(_setpointMsg.position.y) + ", z: " + std::to_string(_setpointMsg.position.z) + ", yaw: " + std::to_string(_setpointMsg.yaw));

        // we don't republish gimbal, as we don't adjust that with local-planner
    }
    catch (const std::exception& e) {
        log_info("GetLocalPlanCorrections experienced an exception and exited:");
        log_info(e.what());
    }
  }

    rclcpp::Publisher<interfaces::msg::LarkePositionTarget>::SharedPtr _pub_position_target;
    rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr _pub_viz_mission;
    rclcpp::Subscription<inspection_interfaces::msg::Trajectory>::SharedPtr _sub_point;
};
}
}
