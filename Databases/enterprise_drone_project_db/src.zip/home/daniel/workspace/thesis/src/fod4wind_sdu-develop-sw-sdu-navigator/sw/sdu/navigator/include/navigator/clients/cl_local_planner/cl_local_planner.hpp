#pragma once
#include <smacc2/smacc.hpp>
#include <std_msgs/msg/float32.hpp>

namespace navigator
{
namespace cl_local_planner
{
class ClLocalPlanner : public smacc2::ISmaccClient
{
public:
  ClLocalPlanner()= default;

};
}  // namespace cl_global_planner
}  // namespace navigator