// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__SMACC_EVENT_GENERATOR_HPP_
#define SMACC2_MSGS__MSG__SMACC_EVENT_GENERATOR_HPP_

#include "smacc2_msgs/msg/detail/smacc_event_generator__struct.hpp"
#include "smacc2_msgs/msg/detail/smacc_event_generator__builder.hpp"
#include "smacc2_msgs/msg/detail/smacc_event_generator__traits.hpp"
#include "smacc2_msgs/msg/detail/smacc_event_generator__type_support.hpp"

#endif  // SMACC2_MSGS__MSG__SMACC_EVENT_GENERATOR_HPP_
