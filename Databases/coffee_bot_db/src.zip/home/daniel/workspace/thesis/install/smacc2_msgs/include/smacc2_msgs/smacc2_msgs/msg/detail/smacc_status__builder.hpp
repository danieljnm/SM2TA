// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from smacc2_msgs:msg/SmaccStatus.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_STATUS__BUILDER_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "smacc2_msgs/msg/detail/smacc_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace smacc2_msgs
{

namespace msg
{

namespace builder
{

class Init_SmaccStatus_global_variable_values
{
public:
  explicit Init_SmaccStatus_global_variable_values(::smacc2_msgs::msg::SmaccStatus & msg)
  : msg_(msg)
  {}
  ::smacc2_msgs::msg::SmaccStatus global_variable_values(::smacc2_msgs::msg::SmaccStatus::_global_variable_values_type arg)
  {
    msg_.global_variable_values = std::move(arg);
    return std::move(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccStatus msg_;
};

class Init_SmaccStatus_global_variable_names
{
public:
  explicit Init_SmaccStatus_global_variable_names(::smacc2_msgs::msg::SmaccStatus & msg)
  : msg_(msg)
  {}
  Init_SmaccStatus_global_variable_values global_variable_names(::smacc2_msgs::msg::SmaccStatus::_global_variable_names_type arg)
  {
    msg_.global_variable_names = std::move(arg);
    return Init_SmaccStatus_global_variable_values(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccStatus msg_;
};

class Init_SmaccStatus_current_states
{
public:
  explicit Init_SmaccStatus_current_states(::smacc2_msgs::msg::SmaccStatus & msg)
  : msg_(msg)
  {}
  Init_SmaccStatus_global_variable_names current_states(::smacc2_msgs::msg::SmaccStatus::_current_states_type arg)
  {
    msg_.current_states = std::move(arg);
    return Init_SmaccStatus_global_variable_names(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccStatus msg_;
};

class Init_SmaccStatus_header
{
public:
  Init_SmaccStatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SmaccStatus_current_states header(::smacc2_msgs::msg::SmaccStatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SmaccStatus_current_states(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::smacc2_msgs::msg::SmaccStatus>()
{
  return smacc2_msgs::msg::builder::Init_SmaccStatus_header();
}

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_STATUS__BUILDER_HPP_
