// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from smacc2_msgs:msg/SmaccTransition.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION__BUILDER_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "smacc2_msgs/msg/detail/smacc_transition__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace smacc2_msgs
{

namespace msg
{

namespace builder
{

class Init_SmaccTransition_event
{
public:
  explicit Init_SmaccTransition_event(::smacc2_msgs::msg::SmaccTransition & msg)
  : msg_(msg)
  {}
  ::smacc2_msgs::msg::SmaccTransition event(::smacc2_msgs::msg::SmaccTransition::_event_type arg)
  {
    msg_.event = std::move(arg);
    return std::move(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccTransition msg_;
};

class Init_SmaccTransition_history_node
{
public:
  explicit Init_SmaccTransition_history_node(::smacc2_msgs::msg::SmaccTransition & msg)
  : msg_(msg)
  {}
  Init_SmaccTransition_event history_node(::smacc2_msgs::msg::SmaccTransition::_history_node_type arg)
  {
    msg_.history_node = std::move(arg);
    return Init_SmaccTransition_event(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccTransition msg_;
};

class Init_SmaccTransition_source_state_name
{
public:
  explicit Init_SmaccTransition_source_state_name(::smacc2_msgs::msg::SmaccTransition & msg)
  : msg_(msg)
  {}
  Init_SmaccTransition_history_node source_state_name(::smacc2_msgs::msg::SmaccTransition::_source_state_name_type arg)
  {
    msg_.source_state_name = std::move(arg);
    return Init_SmaccTransition_history_node(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccTransition msg_;
};

class Init_SmaccTransition_destiny_state_name
{
public:
  explicit Init_SmaccTransition_destiny_state_name(::smacc2_msgs::msg::SmaccTransition & msg)
  : msg_(msg)
  {}
  Init_SmaccTransition_source_state_name destiny_state_name(::smacc2_msgs::msg::SmaccTransition::_destiny_state_name_type arg)
  {
    msg_.destiny_state_name = std::move(arg);
    return Init_SmaccTransition_source_state_name(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccTransition msg_;
};

class Init_SmaccTransition_transition_type
{
public:
  explicit Init_SmaccTransition_transition_type(::smacc2_msgs::msg::SmaccTransition & msg)
  : msg_(msg)
  {}
  Init_SmaccTransition_destiny_state_name transition_type(::smacc2_msgs::msg::SmaccTransition::_transition_type_type arg)
  {
    msg_.transition_type = std::move(arg);
    return Init_SmaccTransition_destiny_state_name(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccTransition msg_;
};

class Init_SmaccTransition_transition_name
{
public:
  explicit Init_SmaccTransition_transition_name(::smacc2_msgs::msg::SmaccTransition & msg)
  : msg_(msg)
  {}
  Init_SmaccTransition_transition_type transition_name(::smacc2_msgs::msg::SmaccTransition::_transition_name_type arg)
  {
    msg_.transition_name = std::move(arg);
    return Init_SmaccTransition_transition_type(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccTransition msg_;
};

class Init_SmaccTransition_index
{
public:
  Init_SmaccTransition_index()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SmaccTransition_transition_name index(::smacc2_msgs::msg::SmaccTransition::_index_type arg)
  {
    msg_.index = std::move(arg);
    return Init_SmaccTransition_transition_name(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccTransition msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::smacc2_msgs::msg::SmaccTransition>()
{
  return smacc2_msgs::msg::builder::Init_SmaccTransition_index();
}

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION__BUILDER_HPP_
