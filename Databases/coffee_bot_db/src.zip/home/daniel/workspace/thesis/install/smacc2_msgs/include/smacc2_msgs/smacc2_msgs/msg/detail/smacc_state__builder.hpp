// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from smacc2_msgs:msg/SmaccState.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_STATE__BUILDER_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "smacc2_msgs/msg/detail/smacc_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace smacc2_msgs
{

namespace msg
{

namespace builder
{

class Init_SmaccState_event_generators
{
public:
  explicit Init_SmaccState_event_generators(::smacc2_msgs::msg::SmaccState & msg)
  : msg_(msg)
  {}
  ::smacc2_msgs::msg::SmaccState event_generators(::smacc2_msgs::msg::SmaccState::_event_generators_type arg)
  {
    msg_.event_generators = std::move(arg);
    return std::move(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccState msg_;
};

class Init_SmaccState_state_reactors
{
public:
  explicit Init_SmaccState_state_reactors(::smacc2_msgs::msg::SmaccState & msg)
  : msg_(msg)
  {}
  Init_SmaccState_event_generators state_reactors(::smacc2_msgs::msg::SmaccState::_state_reactors_type arg)
  {
    msg_.state_reactors = std::move(arg);
    return Init_SmaccState_event_generators(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccState msg_;
};

class Init_SmaccState_orthogonals
{
public:
  explicit Init_SmaccState_orthogonals(::smacc2_msgs::msg::SmaccState & msg)
  : msg_(msg)
  {}
  Init_SmaccState_state_reactors orthogonals(::smacc2_msgs::msg::SmaccState::_orthogonals_type arg)
  {
    msg_.orthogonals = std::move(arg);
    return Init_SmaccState_state_reactors(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccState msg_;
};

class Init_SmaccState_transitions
{
public:
  explicit Init_SmaccState_transitions(::smacc2_msgs::msg::SmaccState & msg)
  : msg_(msg)
  {}
  Init_SmaccState_orthogonals transitions(::smacc2_msgs::msg::SmaccState::_transitions_type arg)
  {
    msg_.transitions = std::move(arg);
    return Init_SmaccState_orthogonals(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccState msg_;
};

class Init_SmaccState_level
{
public:
  explicit Init_SmaccState_level(::smacc2_msgs::msg::SmaccState & msg)
  : msg_(msg)
  {}
  Init_SmaccState_transitions level(::smacc2_msgs::msg::SmaccState::_level_type arg)
  {
    msg_.level = std::move(arg);
    return Init_SmaccState_transitions(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccState msg_;
};

class Init_SmaccState_children_states
{
public:
  explicit Init_SmaccState_children_states(::smacc2_msgs::msg::SmaccState & msg)
  : msg_(msg)
  {}
  Init_SmaccState_level children_states(::smacc2_msgs::msg::SmaccState::_children_states_type arg)
  {
    msg_.children_states = std::move(arg);
    return Init_SmaccState_level(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccState msg_;
};

class Init_SmaccState_name
{
public:
  explicit Init_SmaccState_name(::smacc2_msgs::msg::SmaccState & msg)
  : msg_(msg)
  {}
  Init_SmaccState_children_states name(::smacc2_msgs::msg::SmaccState::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_SmaccState_children_states(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccState msg_;
};

class Init_SmaccState_index
{
public:
  Init_SmaccState_index()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SmaccState_name index(::smacc2_msgs::msg::SmaccState::_index_type arg)
  {
    msg_.index = std::move(arg);
    return Init_SmaccState_name(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::smacc2_msgs::msg::SmaccState>()
{
  return smacc2_msgs::msg::builder::Init_SmaccState_index();
}

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_STATE__BUILDER_HPP_
