// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from smacc2_msgs:msg/SmaccStatus.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_STATUS__STRUCT_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__smacc2_msgs__msg__SmaccStatus __attribute__((deprecated))
#else
# define DEPRECATED__smacc2_msgs__msg__SmaccStatus __declspec(deprecated)
#endif

namespace smacc2_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SmaccStatus_
{
  using Type = SmaccStatus_<ContainerAllocator>;

  explicit SmaccStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    (void)_init;
  }

  explicit SmaccStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _current_states_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _current_states_type current_states;
  using _global_variable_names_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _global_variable_names_type global_variable_names;
  using _global_variable_values_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _global_variable_values_type global_variable_values;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__current_states(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->current_states = _arg;
    return *this;
  }
  Type & set__global_variable_names(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->global_variable_names = _arg;
    return *this;
  }
  Type & set__global_variable_values(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->global_variable_values = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    smacc2_msgs::msg::SmaccStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const smacc2_msgs::msg::SmaccStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<smacc2_msgs::msg::SmaccStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<smacc2_msgs::msg::SmaccStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      smacc2_msgs::msg::SmaccStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<smacc2_msgs::msg::SmaccStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      smacc2_msgs::msg::SmaccStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<smacc2_msgs::msg::SmaccStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<smacc2_msgs::msg::SmaccStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<smacc2_msgs::msg::SmaccStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__smacc2_msgs__msg__SmaccStatus
    std::shared_ptr<smacc2_msgs::msg::SmaccStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__smacc2_msgs__msg__SmaccStatus
    std::shared_ptr<smacc2_msgs::msg::SmaccStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SmaccStatus_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->current_states != other.current_states) {
      return false;
    }
    if (this->global_variable_names != other.global_variable_names) {
      return false;
    }
    if (this->global_variable_values != other.global_variable_values) {
      return false;
    }
    return true;
  }
  bool operator!=(const SmaccStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SmaccStatus_

// alias to use template instance with default allocator
using SmaccStatus =
  smacc2_msgs::msg::SmaccStatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_STATUS__STRUCT_HPP_
