// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from smacc2_msgs:msg/SmaccStateMachine.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_STATE_MACHINE__BUILDER_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_STATE_MACHINE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "smacc2_msgs/msg/detail/smacc_state_machine__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace smacc2_msgs
{

namespace msg
{

namespace builder
{

class Init_SmaccStateMachine_states
{
public:
  Init_SmaccStateMachine_states()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::smacc2_msgs::msg::SmaccStateMachine states(::smacc2_msgs::msg::SmaccStateMachine::_states_type arg)
  {
    msg_.states = std::move(arg);
    return std::move(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccStateMachine msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::smacc2_msgs::msg::SmaccStateMachine>()
{
  return smacc2_msgs::msg::builder::Init_SmaccStateMachine_states();
}

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_STATE_MACHINE__BUILDER_HPP_
