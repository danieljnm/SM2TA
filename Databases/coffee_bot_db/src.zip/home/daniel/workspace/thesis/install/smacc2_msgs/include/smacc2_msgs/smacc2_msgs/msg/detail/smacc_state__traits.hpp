// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from smacc2_msgs:msg/SmaccState.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_STATE__TRAITS_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "smacc2_msgs/msg/detail/smacc_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'transitions'
#include "smacc2_msgs/msg/detail/smacc_transition__traits.hpp"
// Member 'orthogonals'
#include "smacc2_msgs/msg/detail/smacc_orthogonal__traits.hpp"
// Member 'state_reactors'
#include "smacc2_msgs/msg/detail/smacc_state_reactor__traits.hpp"
// Member 'event_generators'
#include "smacc2_msgs/msg/detail/smacc_event_generator__traits.hpp"

namespace smacc2_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SmaccState & msg,
  std::ostream & out)
{
  out << "{";
  // member: index
  {
    out << "index: ";
    rosidl_generator_traits::value_to_yaml(msg.index, out);
    out << ", ";
  }

  // member: name
  {
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << ", ";
  }

  // member: children_states
  {
    if (msg.children_states.size() == 0) {
      out << "children_states: []";
    } else {
      out << "children_states: [";
      size_t pending_items = msg.children_states.size();
      for (auto item : msg.children_states) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: level
  {
    out << "level: ";
    rosidl_generator_traits::value_to_yaml(msg.level, out);
    out << ", ";
  }

  // member: transitions
  {
    if (msg.transitions.size() == 0) {
      out << "transitions: []";
    } else {
      out << "transitions: [";
      size_t pending_items = msg.transitions.size();
      for (auto item : msg.transitions) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: orthogonals
  {
    if (msg.orthogonals.size() == 0) {
      out << "orthogonals: []";
    } else {
      out << "orthogonals: [";
      size_t pending_items = msg.orthogonals.size();
      for (auto item : msg.orthogonals) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: state_reactors
  {
    if (msg.state_reactors.size() == 0) {
      out << "state_reactors: []";
    } else {
      out << "state_reactors: [";
      size_t pending_items = msg.state_reactors.size();
      for (auto item : msg.state_reactors) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: event_generators
  {
    if (msg.event_generators.size() == 0) {
      out << "event_generators: []";
    } else {
      out << "event_generators: [";
      size_t pending_items = msg.event_generators.size();
      for (auto item : msg.event_generators) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SmaccState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: index
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "index: ";
    rosidl_generator_traits::value_to_yaml(msg.index, out);
    out << "\n";
  }

  // member: name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << "\n";
  }

  // member: children_states
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.children_states.size() == 0) {
      out << "children_states: []\n";
    } else {
      out << "children_states:\n";
      for (auto item : msg.children_states) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: level
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "level: ";
    rosidl_generator_traits::value_to_yaml(msg.level, out);
    out << "\n";
  }

  // member: transitions
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.transitions.size() == 0) {
      out << "transitions: []\n";
    } else {
      out << "transitions:\n";
      for (auto item : msg.transitions) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: orthogonals
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.orthogonals.size() == 0) {
      out << "orthogonals: []\n";
    } else {
      out << "orthogonals:\n";
      for (auto item : msg.orthogonals) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: state_reactors
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.state_reactors.size() == 0) {
      out << "state_reactors: []\n";
    } else {
      out << "state_reactors:\n";
      for (auto item : msg.state_reactors) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: event_generators
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.event_generators.size() == 0) {
      out << "event_generators: []\n";
    } else {
      out << "event_generators:\n";
      for (auto item : msg.event_generators) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SmaccState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace smacc2_msgs

namespace rosidl_generator_traits
{

[[deprecated("use smacc2_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const smacc2_msgs::msg::SmaccState & msg,
  std::ostream & out, size_t indentation = 0)
{
  smacc2_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use smacc2_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const smacc2_msgs::msg::SmaccState & msg)
{
  return smacc2_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<smacc2_msgs::msg::SmaccState>()
{
  return "smacc2_msgs::msg::SmaccState";
}

template<>
inline const char * name<smacc2_msgs::msg::SmaccState>()
{
  return "smacc2_msgs/msg/SmaccState";
}

template<>
struct has_fixed_size<smacc2_msgs::msg::SmaccState>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<smacc2_msgs::msg::SmaccState>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<smacc2_msgs::msg::SmaccState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_STATE__TRAITS_HPP_
