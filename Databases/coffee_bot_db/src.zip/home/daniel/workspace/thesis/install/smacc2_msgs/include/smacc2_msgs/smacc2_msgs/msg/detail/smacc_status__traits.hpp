// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from smacc2_msgs:msg/SmaccStatus.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_STATUS__TRAITS_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "smacc2_msgs/msg/detail/smacc_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace smacc2_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SmaccStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: current_states
  {
    if (msg.current_states.size() == 0) {
      out << "current_states: []";
    } else {
      out << "current_states: [";
      size_t pending_items = msg.current_states.size();
      for (auto item : msg.current_states) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: global_variable_names
  {
    if (msg.global_variable_names.size() == 0) {
      out << "global_variable_names: []";
    } else {
      out << "global_variable_names: [";
      size_t pending_items = msg.global_variable_names.size();
      for (auto item : msg.global_variable_names) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: global_variable_values
  {
    if (msg.global_variable_values.size() == 0) {
      out << "global_variable_values: []";
    } else {
      out << "global_variable_values: [";
      size_t pending_items = msg.global_variable_values.size();
      for (auto item : msg.global_variable_values) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SmaccStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: current_states
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.current_states.size() == 0) {
      out << "current_states: []\n";
    } else {
      out << "current_states:\n";
      for (auto item : msg.current_states) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: global_variable_names
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.global_variable_names.size() == 0) {
      out << "global_variable_names: []\n";
    } else {
      out << "global_variable_names:\n";
      for (auto item : msg.global_variable_names) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: global_variable_values
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.global_variable_values.size() == 0) {
      out << "global_variable_values: []\n";
    } else {
      out << "global_variable_values:\n";
      for (auto item : msg.global_variable_values) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SmaccStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace smacc2_msgs

namespace rosidl_generator_traits
{

[[deprecated("use smacc2_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const smacc2_msgs::msg::SmaccStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  smacc2_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use smacc2_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const smacc2_msgs::msg::SmaccStatus & msg)
{
  return smacc2_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<smacc2_msgs::msg::SmaccStatus>()
{
  return "smacc2_msgs::msg::SmaccStatus";
}

template<>
inline const char * name<smacc2_msgs::msg::SmaccStatus>()
{
  return "smacc2_msgs/msg/SmaccStatus";
}

template<>
struct has_fixed_size<smacc2_msgs::msg::SmaccStatus>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<smacc2_msgs::msg::SmaccStatus>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<smacc2_msgs::msg::SmaccStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_STATUS__TRAITS_HPP_
