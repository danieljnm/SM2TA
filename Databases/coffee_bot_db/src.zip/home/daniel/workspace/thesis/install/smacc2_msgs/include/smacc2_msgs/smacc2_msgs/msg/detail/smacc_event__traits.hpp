// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from smacc2_msgs:msg/SmaccEvent.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_EVENT__TRAITS_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_EVENT__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "smacc2_msgs/msg/detail/smacc_event__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace smacc2_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SmaccEvent & msg,
  std::ostream & out)
{
  out << "{";
  // member: event_type
  {
    out << "event_type: ";
    rosidl_generator_traits::value_to_yaml(msg.event_type, out);
    out << ", ";
  }

  // member: event_object_tag
  {
    out << "event_object_tag: ";
    rosidl_generator_traits::value_to_yaml(msg.event_object_tag, out);
    out << ", ";
  }

  // member: event_source
  {
    out << "event_source: ";
    rosidl_generator_traits::value_to_yaml(msg.event_source, out);
    out << ", ";
  }

  // member: label
  {
    out << "label: ";
    rosidl_generator_traits::value_to_yaml(msg.label, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SmaccEvent & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: event_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "event_type: ";
    rosidl_generator_traits::value_to_yaml(msg.event_type, out);
    out << "\n";
  }

  // member: event_object_tag
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "event_object_tag: ";
    rosidl_generator_traits::value_to_yaml(msg.event_object_tag, out);
    out << "\n";
  }

  // member: event_source
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "event_source: ";
    rosidl_generator_traits::value_to_yaml(msg.event_source, out);
    out << "\n";
  }

  // member: label
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "label: ";
    rosidl_generator_traits::value_to_yaml(msg.label, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SmaccEvent & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace smacc2_msgs

namespace rosidl_generator_traits
{

[[deprecated("use smacc2_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const smacc2_msgs::msg::SmaccEvent & msg,
  std::ostream & out, size_t indentation = 0)
{
  smacc2_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use smacc2_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const smacc2_msgs::msg::SmaccEvent & msg)
{
  return smacc2_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<smacc2_msgs::msg::SmaccEvent>()
{
  return "smacc2_msgs::msg::SmaccEvent";
}

template<>
inline const char * name<smacc2_msgs::msg::SmaccEvent>()
{
  return "smacc2_msgs/msg/SmaccEvent";
}

template<>
struct has_fixed_size<smacc2_msgs::msg::SmaccEvent>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<smacc2_msgs::msg::SmaccEvent>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<smacc2_msgs::msg::SmaccEvent>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_EVENT__TRAITS_HPP_
