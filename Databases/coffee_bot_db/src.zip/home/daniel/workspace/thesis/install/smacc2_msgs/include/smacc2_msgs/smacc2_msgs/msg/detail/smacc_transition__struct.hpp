// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from smacc2_msgs:msg/SmaccTransition.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION__STRUCT_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'event'
#include "smacc2_msgs/msg/detail/smacc_event__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__smacc2_msgs__msg__SmaccTransition __attribute__((deprecated))
#else
# define DEPRECATED__smacc2_msgs__msg__SmaccTransition __declspec(deprecated)
#endif

namespace smacc2_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SmaccTransition_
{
  using Type = SmaccTransition_<ContainerAllocator>;

  explicit SmaccTransition_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : event(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->index = 0l;
      this->transition_name = "";
      this->transition_type = "";
      this->destiny_state_name = "";
      this->source_state_name = "";
      this->history_node = false;
    }
  }

  explicit SmaccTransition_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : transition_name(_alloc),
    transition_type(_alloc),
    destiny_state_name(_alloc),
    source_state_name(_alloc),
    event(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->index = 0l;
      this->transition_name = "";
      this->transition_type = "";
      this->destiny_state_name = "";
      this->source_state_name = "";
      this->history_node = false;
    }
  }

  // field types and members
  using _index_type =
    int32_t;
  _index_type index;
  using _transition_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _transition_name_type transition_name;
  using _transition_type_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _transition_type_type transition_type;
  using _destiny_state_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _destiny_state_name_type destiny_state_name;
  using _source_state_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _source_state_name_type source_state_name;
  using _history_node_type =
    bool;
  _history_node_type history_node;
  using _event_type =
    smacc2_msgs::msg::SmaccEvent_<ContainerAllocator>;
  _event_type event;

  // setters for named parameter idiom
  Type & set__index(
    const int32_t & _arg)
  {
    this->index = _arg;
    return *this;
  }
  Type & set__transition_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->transition_name = _arg;
    return *this;
  }
  Type & set__transition_type(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->transition_type = _arg;
    return *this;
  }
  Type & set__destiny_state_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->destiny_state_name = _arg;
    return *this;
  }
  Type & set__source_state_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->source_state_name = _arg;
    return *this;
  }
  Type & set__history_node(
    const bool & _arg)
  {
    this->history_node = _arg;
    return *this;
  }
  Type & set__event(
    const smacc2_msgs::msg::SmaccEvent_<ContainerAllocator> & _arg)
  {
    this->event = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    smacc2_msgs::msg::SmaccTransition_<ContainerAllocator> *;
  using ConstRawPtr =
    const smacc2_msgs::msg::SmaccTransition_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      smacc2_msgs::msg::SmaccTransition_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      smacc2_msgs::msg::SmaccTransition_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__smacc2_msgs__msg__SmaccTransition
    std::shared_ptr<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__smacc2_msgs__msg__SmaccTransition
    std::shared_ptr<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SmaccTransition_ & other) const
  {
    if (this->index != other.index) {
      return false;
    }
    if (this->transition_name != other.transition_name) {
      return false;
    }
    if (this->transition_type != other.transition_type) {
      return false;
    }
    if (this->destiny_state_name != other.destiny_state_name) {
      return false;
    }
    if (this->source_state_name != other.source_state_name) {
      return false;
    }
    if (this->history_node != other.history_node) {
      return false;
    }
    if (this->event != other.event) {
      return false;
    }
    return true;
  }
  bool operator!=(const SmaccTransition_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SmaccTransition_

// alias to use template instance with default allocator
using SmaccTransition =
  smacc2_msgs::msg::SmaccTransition_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_TRANSITION__STRUCT_HPP_
