// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from smacc2_msgs:msg/SmaccStateReactor.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_STATE_REACTOR__BUILDER_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_STATE_REACTOR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "smacc2_msgs/msg/detail/smacc_state_reactor__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace smacc2_msgs
{

namespace msg
{

namespace builder
{

class Init_SmaccStateReactor_event_sources
{
public:
  explicit Init_SmaccStateReactor_event_sources(::smacc2_msgs::msg::SmaccStateReactor & msg)
  : msg_(msg)
  {}
  ::smacc2_msgs::msg::SmaccStateReactor event_sources(::smacc2_msgs::msg::SmaccStateReactor::_event_sources_type arg)
  {
    msg_.event_sources = std::move(arg);
    return std::move(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccStateReactor msg_;
};

class Init_SmaccStateReactor_object_tag
{
public:
  explicit Init_SmaccStateReactor_object_tag(::smacc2_msgs::msg::SmaccStateReactor & msg)
  : msg_(msg)
  {}
  Init_SmaccStateReactor_event_sources object_tag(::smacc2_msgs::msg::SmaccStateReactor::_object_tag_type arg)
  {
    msg_.object_tag = std::move(arg);
    return Init_SmaccStateReactor_event_sources(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccStateReactor msg_;
};

class Init_SmaccStateReactor_type_name
{
public:
  explicit Init_SmaccStateReactor_type_name(::smacc2_msgs::msg::SmaccStateReactor & msg)
  : msg_(msg)
  {}
  Init_SmaccStateReactor_object_tag type_name(::smacc2_msgs::msg::SmaccStateReactor::_type_name_type arg)
  {
    msg_.type_name = std::move(arg);
    return Init_SmaccStateReactor_object_tag(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccStateReactor msg_;
};

class Init_SmaccStateReactor_index
{
public:
  Init_SmaccStateReactor_index()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SmaccStateReactor_type_name index(::smacc2_msgs::msg::SmaccStateReactor::_index_type arg)
  {
    msg_.index = std::move(arg);
    return Init_SmaccStateReactor_type_name(msg_);
  }

private:
  ::smacc2_msgs::msg::SmaccStateReactor msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::smacc2_msgs::msg::SmaccStateReactor>()
{
  return smacc2_msgs::msg::builder::Init_SmaccStateReactor_index();
}

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_STATE_REACTOR__BUILDER_HPP_
