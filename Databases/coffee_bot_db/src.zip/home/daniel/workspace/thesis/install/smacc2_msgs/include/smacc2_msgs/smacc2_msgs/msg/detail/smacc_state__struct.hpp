// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from smacc2_msgs:msg/SmaccState.idl
// generated code does not contain a copyright notice

#ifndef SMACC2_MSGS__MSG__DETAIL__SMACC_STATE__STRUCT_HPP_
#define SMACC2_MSGS__MSG__DETAIL__SMACC_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'transitions'
#include "smacc2_msgs/msg/detail/smacc_transition__struct.hpp"
// Member 'orthogonals'
#include "smacc2_msgs/msg/detail/smacc_orthogonal__struct.hpp"
// Member 'state_reactors'
#include "smacc2_msgs/msg/detail/smacc_state_reactor__struct.hpp"
// Member 'event_generators'
#include "smacc2_msgs/msg/detail/smacc_event_generator__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__smacc2_msgs__msg__SmaccState __attribute__((deprecated))
#else
# define DEPRECATED__smacc2_msgs__msg__SmaccState __declspec(deprecated)
#endif

namespace smacc2_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SmaccState_
{
  using Type = SmaccState_<ContainerAllocator>;

  explicit SmaccState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->index = 0l;
      this->name = "";
      this->level = 0;
    }
  }

  explicit SmaccState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->index = 0l;
      this->name = "";
      this->level = 0;
    }
  }

  // field types and members
  using _index_type =
    int32_t;
  _index_type index;
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;
  using _children_states_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _children_states_type children_states;
  using _level_type =
    int8_t;
  _level_type level;
  using _transitions_type =
    std::vector<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator>>>;
  _transitions_type transitions;
  using _orthogonals_type =
    std::vector<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator>>>;
  _orthogonals_type orthogonals;
  using _state_reactors_type =
    std::vector<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator>>>;
  _state_reactors_type state_reactors;
  using _event_generators_type =
    std::vector<smacc2_msgs::msg::SmaccEventGenerator_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<smacc2_msgs::msg::SmaccEventGenerator_<ContainerAllocator>>>;
  _event_generators_type event_generators;

  // setters for named parameter idiom
  Type & set__index(
    const int32_t & _arg)
  {
    this->index = _arg;
    return *this;
  }
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__children_states(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->children_states = _arg;
    return *this;
  }
  Type & set__level(
    const int8_t & _arg)
  {
    this->level = _arg;
    return *this;
  }
  Type & set__transitions(
    const std::vector<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<smacc2_msgs::msg::SmaccTransition_<ContainerAllocator>>> & _arg)
  {
    this->transitions = _arg;
    return *this;
  }
  Type & set__orthogonals(
    const std::vector<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<smacc2_msgs::msg::SmaccOrthogonal_<ContainerAllocator>>> & _arg)
  {
    this->orthogonals = _arg;
    return *this;
  }
  Type & set__state_reactors(
    const std::vector<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<smacc2_msgs::msg::SmaccStateReactor_<ContainerAllocator>>> & _arg)
  {
    this->state_reactors = _arg;
    return *this;
  }
  Type & set__event_generators(
    const std::vector<smacc2_msgs::msg::SmaccEventGenerator_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<smacc2_msgs::msg::SmaccEventGenerator_<ContainerAllocator>>> & _arg)
  {
    this->event_generators = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    smacc2_msgs::msg::SmaccState_<ContainerAllocator> *;
  using ConstRawPtr =
    const smacc2_msgs::msg::SmaccState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<smacc2_msgs::msg::SmaccState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<smacc2_msgs::msg::SmaccState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      smacc2_msgs::msg::SmaccState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<smacc2_msgs::msg::SmaccState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      smacc2_msgs::msg::SmaccState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<smacc2_msgs::msg::SmaccState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<smacc2_msgs::msg::SmaccState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<smacc2_msgs::msg::SmaccState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__smacc2_msgs__msg__SmaccState
    std::shared_ptr<smacc2_msgs::msg::SmaccState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__smacc2_msgs__msg__SmaccState
    std::shared_ptr<smacc2_msgs::msg::SmaccState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SmaccState_ & other) const
  {
    if (this->index != other.index) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    if (this->children_states != other.children_states) {
      return false;
    }
    if (this->level != other.level) {
      return false;
    }
    if (this->transitions != other.transitions) {
      return false;
    }
    if (this->orthogonals != other.orthogonals) {
      return false;
    }
    if (this->state_reactors != other.state_reactors) {
      return false;
    }
    if (this->event_generators != other.event_generators) {
      return false;
    }
    return true;
  }
  bool operator!=(const SmaccState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SmaccState_

// alias to use template instance with default allocator
using SmaccState =
  smacc2_msgs::msg::SmaccState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace smacc2_msgs

#endif  // SMACC2_MSGS__MSG__DETAIL__SMACC_STATE__STRUCT_HPP_
