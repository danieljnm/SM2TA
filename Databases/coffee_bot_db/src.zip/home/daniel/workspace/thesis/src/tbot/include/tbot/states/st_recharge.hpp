#pragma once
#include "rclcpp/rclcpp.hpp"
#include "smacc2/smacc.hpp"

namespace tbot
{
using namespace smacc2::default_events;
// SMACC2 clases
using smacc2::Transition;
using smacc2::EvStateRequestFinish;
using smacc2::EvCbSuccess;
using smacc2::default_transition_tags::SUCCESS;
using cl_ros_timer::EvTimer;
using tbot::OrTimer;
// using tbot::OrBatteryManager;

// STATE DECLARATION
struct StRecharge : smacc2::SmaccState<StRecharge, Tbot>
{
  using SmaccState::SmaccState;
  
  // TRANSITION TABLE - adjust as needed
  typedef boost::mpl::list<
    Transition<EvTimer<CbTimerCountdownOnce, OrTimer>, StQueue>
  > reactions;
  
  // STATE FUNCTIONS
  static void staticConfigure()
  {
    configure_orthogonal<OrTimer, CbTimerCountdownOnce>(10);
  }
  
  void runtimeConfigure()
  {
    RCLCPP_INFO(getLogger(), " Recharging");
  }
  
  void onEntry()
  {
    RCLCPP_INFO(getLogger(), " On Entry!");
    
    cl_battery_manager::ClBatteryManager* batteryClient;
    this->requiresClient(batteryClient);
    batteryClient->recharge();
  }
  
  void onExit()
  {
    RCLCPP_INFO(getLogger(), "On Exit from Recharge! Battery full");
  }
};
}