#pragma once

#include "rclcpp/rclcpp.hpp"
#include "smacc2/smacc.hpp"

namespace tbot
{

using namespace smacc2::default_events;
// SMACC2 clases
using smacc2::Transition;
using smacc2::EvStateRequestFinish;
using smacc2::EvCbSuccess;
using smacc2::default_transition_tags::SUCCESS;

using cl_ros_timer::EvTimer;

using tbot::OrNavigation;

// STATE DECLARATION
struct StStartup : smacc2::SmaccState<StStartup, Tbot>
{
  using SmaccState::SmaccState;

  // TRANSITION TABLE - adjust as needed
  typedef boost::mpl::list<

    Transition<EvCbSuccess<CbWaitPose, OrNavigation>, StQueue>

    >reactions;

  // STATE FUNCTIONS
  static void staticConfigure()
  {
    configure_orthogonal<OrNavigation, CbWaitPose>();
  }

  void runtimeConfigure() {}

  void onEntry()
  {
    RCLCPP_INFO(getLogger(), " On Entry!");
  }

  void onExit()  
  {
    RCLCPP_INFO(getLogger(), " On Exit!");
  }
};
}
