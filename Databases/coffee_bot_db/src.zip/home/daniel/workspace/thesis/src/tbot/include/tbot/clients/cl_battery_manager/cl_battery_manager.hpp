#pragma once
#include <smacc2/smacc.hpp>
#include <algorithm>
#include <std_msgs/msg/int32.hpp>

namespace tbot
{
namespace cl_battery_manager
{
class ClBatteryManager : public smacc2::ISmaccClient
{
public:
  ClBatteryManager() = default;

  void onInitialize() override
  {
    battery_pub_ = this->getNode()->create_publisher<std_msgs::msg::Int32>("/interface/battery_level", rclcpp::ServicesQoS());
    publish_battery_level();
  }

  int get_battery_level() const
  {
    return battery_level_;
  }

  void set_battery_level(int level)
  {
    battery_level_ = std::clamp(level, 0, 100);
    publish_battery_level();
  }

  void deplete()
  {
    set_battery_level(battery_level_ - 10);
  }

  void recharge(int amount = 100)
  {
    set_battery_level(amount);
  }

  bool recharge_required() const
  {
    return battery_level_ <= 20;
  }

  bool is_critical() const
  {
    return battery_level_ <= 0;
  }

private:
  int battery_level_ = 15;
  rclcpp::Publisher<std_msgs::msg::Int32>::SharedPtr battery_pub_;

  void publish_battery_level()
  {
    auto msg = std_msgs::msg::Int32();
    msg.data = battery_level_;
    battery_pub_->publish(msg);
  }
};

} // namespace cl_battery_manager
} // namespace tbot