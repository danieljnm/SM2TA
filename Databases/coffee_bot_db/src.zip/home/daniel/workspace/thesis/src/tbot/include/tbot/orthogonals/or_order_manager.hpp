#pragma once
#include <smacc2/smacc_orthogonal.hpp>
#include "tbot/clients/cl_order_manager/cl_order_manager.hpp"

namespace tbot
{
class OrOrderManager : public smacc2::Orthogonal<OrOrderManager>
{
public:
  void onInitialize() override
  {
    auto orderClient = this->createClient<ClOrderManager>();
  }
};
} // namespace tbot