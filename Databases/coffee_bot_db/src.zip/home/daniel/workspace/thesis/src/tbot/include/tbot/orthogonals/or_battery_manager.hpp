#pragma once
#include <smacc2/smacc_orthogonal.hpp>
#include "tbot/clients/cl_battery_manager/cl_battery_manager.hpp"

namespace tbot
{
class OrBatteryManager : public smacc2::Orthogonal<OrBatteryManager>
{
public:
  void onInitialize() override
  {
    auto batteryClient = this->createClient<ClBatteryManager>();
  }
};
} // namespace tbot