#pragma once

#include "smacc2/smacc.hpp"
#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include "tbot/clients/cl_order_manager/cl_order_manager.hpp"

namespace tbot {
namespace cl_order_manager {

class CbHasNextOrder : public smacc2::SmaccAsyncClientBehavior {
public:
  CbHasNextOrder() = default;
  ~CbHasNextOrder() override = default;

  void onEntry() override {
    ClOrderManager* orderClient;
    this->requiresClient(orderClient);
    
    if (!orderClient) {
      RCLCPP_ERROR(getLogger(), "Failed to get order client");
      this->postSuccessEvent();
      return;
    }
    
    if (orderClient->has_next_order()) {
      this->postSuccessEvent();
      return;
    }

    this->postFailureEvent();
  }
};
}
}