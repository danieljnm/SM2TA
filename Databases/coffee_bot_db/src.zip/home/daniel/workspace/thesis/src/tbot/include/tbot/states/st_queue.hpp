#pragma once

#include "rclcpp/rclcpp.hpp"
#include "smacc2/smacc.hpp"

namespace tbot
{

using namespace smacc2::default_events;
// SMACC2 clases
using smacc2::Transition;
using smacc2::EvStateRequestFinish;
using smacc2::EvCbSuccess;
using smacc2::EvCbFailure;
using smacc2::default_transition_tags::SUCCESS;

using cl_ros_timer::EvTimer;

using tbot::OrNavigation;
using tbot::OrBatteryManager;
using tbot::OrOrderManager;

// STATE DECLARATION
struct StQueue : smacc2::SmaccState<StQueue, Tbot>
{
  using SmaccState::SmaccState;

  struct SrReadyToProcessOrder;
  struct SrReadyToTakeOrders;

  // TRANSITION TABLE - adjust as needed
  typedef boost::mpl::list<

    Transition<EvCbFailure<CbCanOperate, OrBatteryManager>, StBatteryDepleted>,
    Transition<EvAllGo<SrAllEventsGo, SrReadyToProcessOrder>, SSProcessOrder::SsProcessOrder>,
    Transition<EvCbSuccess<CbRechargeRequired, OrBatteryManager>, StNavigateToBase>,
    Transition<EvAllGo<SrAllEventsGo, SrReadyToTakeOrders>, StNavigateToBase>

    >reactions;

  // STATE FUNCTIONS
  static void staticConfigure()
  {
    configure_orthogonal<OrBatteryManager, CbCanOperate>();
    configure_orthogonal<OrBatteryManager, CbRechargeRequired>();
    configure_orthogonal<OrOrderManager, CbHasNextOrder>();

    static_createStateReactor<SrAllEventsGo, smacc2::state_reactors::EvAllGo<SrAllEventsGo, SrReadyToProcessOrder>,
        mpl::list<
          EvCbFailure<CbRechargeRequired, OrBatteryManager>,
          EvCbSuccess<CbHasNextOrder, OrOrderManager>
        >>();
    static_createStateReactor<SrAllEventsGo, smacc2::state_reactors::EvAllGo<SrAllEventsGo, SrReadyToTakeOrders>,
        mpl::list<
          EvCbFailure<CbRechargeRequired, OrBatteryManager>,
          EvCbFailure<CbHasNextOrder, OrOrderManager>
        >>();
  }

  void runtimeConfigure() 
  {
  }

  void onEntry()
  {
    RCLCPP_INFO(getLogger(), " On Entry!");
  }

  void onExit()  
  {
    RCLCPP_INFO(getLogger(), " On Exit!");
  }
};
}
