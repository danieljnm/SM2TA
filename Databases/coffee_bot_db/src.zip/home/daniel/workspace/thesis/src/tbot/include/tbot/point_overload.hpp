#include <iostream>
#include <geometry_msgs/msg/point.hpp>

namespace geometry_msgs {
namespace msg {

inline std::ostream & operator<<(std::ostream & os, const Point & point)
{
  os << "Point(x: " << point.x << ", y: " << point.y << ", z: " << point.z << ")";
  return os;
}

}  // namespace msg
}  // namespace geometry_msgs