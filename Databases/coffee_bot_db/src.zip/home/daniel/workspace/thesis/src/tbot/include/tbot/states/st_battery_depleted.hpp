#pragma once
#include "rclcpp/rclcpp.hpp"
#include "smacc2/smacc.hpp"

namespace tbot
{
using namespace smacc2::default_events;

// STATE DECLARATION
struct StBatteryDepleted : smacc2::SmaccState<StBatteryDepleted, Tbot>
{
  using SmaccState::SmaccState;
  
  // TRANSITION TABLE - No transitions - this is a terminal state
  typedef boost::mpl::list<
  > reactions;
  
  // STATE FUNCTIONS
  static void staticConfigure()
  {
  }
  
  void runtimeConfigure()
  {
    RCLCPP_ERROR(getLogger(), " Battery has been fully depleted");
  }
  
  void onEntry()
  {
  }
  
  void onExit()
  {
  }
};
}