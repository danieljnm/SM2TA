
#pragma once

#include <tbot/clients/cl_ask_directions/client_behaviours/cb_ask_directions_subscriber_behaviour.hpp>
#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include <boost/format.hpp>

namespace tbot {
namespace cl_ask_directions {

class CbAskDirections : public smacc2::SmaccAsyncClientBehavior {
public:
  CbAskDirections() = default;
  ~CbAskDirections() override = default;

  void onExit() override {
      _sub_control.reset();
    }

  void onEntry() override {
    rclcpp::SubscriptionOptions sub_option;
    _sub_control = getNode()->create_subscription<geometry_msgs::msg::Point>("/interface/reply", rclcpp::ServicesQoS(), std::bind(&CbAskDirections::onMessageReceived, this, std::placeholders::_1), sub_option);
    auto _askPub = getNode()->create_publisher<std_msgs::msg::String>("/interface/ask", rclcpp::ServicesQoS());
    _notifyPub = getNode()->create_publisher<std_msgs::msg::String>("/interface/notify", rclcpp::ServicesQoS());
    std_msgs::msg::String msg;
    msg.data = "Where should I go?";
    _askPub->publish(msg);
  }

private:
  void onMessageReceived(const geometry_msgs::msg::Point::SharedPtr msg) {
    try {
      geometry_msgs::msg::Point coordinate;
      coordinate.x = msg->x;
      coordinate.y = msg->y;
      coordinate.z = msg->z;
      this->getStateMachine()->setGlobalSMData("coordinate", coordinate);
      std_msgs::msg::String msg;
      msg.data = (boost::format("Moving to %.2f, %.2f, %.2f") % coordinate.x % coordinate.y % coordinate.z).str();
      _notifyPub->publish(msg);
      postSuccessEvent();
    } catch(const std::exception&) {
      postFailureEvent(); 
    }
  }

  rclcpp::Subscription<geometry_msgs::msg::Point>::SharedPtr _sub_control;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr _notifyPub;
};
}
}
