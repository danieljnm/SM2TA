#pragma once
#include <memory>
#include <string>
#include "smacc2/smacc.hpp"

namespace tbot
{
namespace process_order_states
{
// STATE DECLARATION
template <typename SS>
struct StiDeliverOrder : smacc2::SmaccState<StiDeliverOrder<SS>, SS>
{
    typedef smacc2::SmaccState<StiDeliverOrder<SS>, SS> TSti;
    using typename TSti::context_type;
    using TSti::SmaccState;
    
    // TRANSITION TABLE
    typedef boost::mpl::list<

        Transition<EvCbSuccess<CbNavigateGlobalPosition, OrNavigation>, StQueue>

    > reactions;
    
    // STATE FUNCTIONS
    static void staticConfigure()
    {
    }
    
    void runtimeConfigure() 
    {
        ClOrderManager* orderClient;
        this->requiresClient(orderClient);
        geometry_msgs::msg::Point delivery_location = orderClient->get_next_order();
        this->template configure<OrNavigation, CbNavigateGlobalPosition>(delivery_location.x, delivery_location.y, 0);
    }

    void onExit() 
    {
        cl_battery_manager::ClBatteryManager* batteryClient;
        this->requiresClient(batteryClient);
        batteryClient->deplete();
    }
};
}
}