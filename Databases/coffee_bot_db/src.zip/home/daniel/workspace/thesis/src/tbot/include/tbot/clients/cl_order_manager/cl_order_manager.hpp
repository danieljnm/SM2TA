#pragma once
#include <smacc2/smacc.hpp>
#include <queue>
#include <mutex>
#include <random>
#include "geometry_msgs/msg/point.hpp"

namespace tbot
{
namespace cl_order_manager
{
class ClOrderManager : public smacc2::ISmaccClient
{
public:
  ClOrderManager() = default;

  void onInitialize() override
  {
    generate_random_orders(10);
    // order_pub_ = this->getNode()->create_publisher<std_msgs::msg::String>("/interface/order", rclcpp::ServicesQoS());
  }

  bool has_next_order() const
  {
    std::lock_guard<std::mutex> lock(queue_mutex_);
    return !orders_.empty();
  }

  geometry_msgs::msg::Point get_next_order()
  {
    std::lock_guard<std::mutex> lock(queue_mutex_);
    if (orders_.empty()) {
      throw std::runtime_error("No orders in queue");
    }
    
    geometry_msgs::msg::Point delivery_location = orders_.front();
    orders_.pop();
    return delivery_location;
  }

  void add_order(const geometry_msgs::msg::Point& delivery_location)
  {
    std::lock_guard<std::mutex> lock(queue_mutex_);
    orders_.push(delivery_location);
  }

private:
  std::queue<geometry_msgs::msg::Point> orders_;
  // geometry_msgs::msg::Point current_order_;
  mutable std::mutex queue_mutex_;
  // rclcpp::Publisher<std_msgs::msg::Float32>::SharedPtr order_pub_;

  // void publish_order_started()
  // {
  //   auto msg = std_msgs::msg::String();
  //   msg.data = "Started working on order %f" %current_order_;
  //   order_pub_->publish(msg);
  // }

  // void publish_order_delivery() {
  //   auto msg = std_msgs::msg::String();
  //   msg.data = "Delivering order %f" %current_order_;
  //   order_pub_->publish(msg);
  // }

  // void publish_order_completed() {
  //   auto msg = std_msgs::msg::String();
  //   msg.data = "Completed order %f" %current_order_;
  //   order_pub_->publish(msg);
  // }

  void generate_random_orders(int count)
  {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<float> x_dist(1.0, 3.0);
    std::uniform_real_distribution<float> y_dist(1.0, 3.0);
    
    for (int i = 0; i < count; i++) {
      geometry_msgs::msg::Point point;
      point.x = x_dist(gen);
      point.y = y_dist(gen);
      point.z = 0.0;
      
      add_order(point);
    }
  }
};

} // namespace cl_order
} // namespace tbot