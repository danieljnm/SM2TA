#pragma once
#include "rclcpp/rclcpp.hpp"
#include "smacc2/smacc.hpp"

namespace tbot
{
namespace process_order_states
{
template <typename SS> struct StiNavigateToCoffeeMachine;
template <typename SS> struct StiWaitForOrder;
template <typename SS> struct StiDeliverOrder;
}
}

namespace tbot
{
namespace SSProcessOrder
{
using namespace process_order_states;
using namespace smacc2::default_events;

// SMACC2 classes
using smacc2::Transition;
using smacc2::EvStateRequestFinish;
using smacc2::EvCbSuccess;
using smacc2::default_transition_tags::SUCCESS;
using cl_ros_timer::EvTimer;
using tbot::OrNavigation;
using tbot::OrTimer;

// STATE DECLARATION
struct SsProcessOrder : smacc2::SmaccState<SsProcessOrder, Tbot, StiNavigateToCoffeeMachine<SsProcessOrder>>
{
    using SmaccState::SmaccState;
    
    // TRANSITION TABLE - adjust as needed
    typedef boost::mpl::list<
    > reactions;

    geometry_msgs::msg::Point delivery_location;
    
    // STATE FUNCTIONS
    static void staticConfigure()
    {
    }
    
    void runtimeConfigure() 
    {
    }
    
    void onEntry()
    {
        RCLCPP_INFO(getLogger(), " On Entry!");
    }
    
    void onExit()
    {
        RCLCPP_INFO(getLogger(), " On Exit!");
    }
};

using SS = SsProcessOrder;

}
}

#include "tbot/states/process_order_states/sti_navigate_to_coffee_machine.hpp"
#include "tbot/states/process_order_states/sti_wait_for_order.hpp"
#include "tbot/states/process_order_states/sti_deliver_order.hpp"