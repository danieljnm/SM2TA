#pragma once

#include "smacc2/smacc.hpp"
#include <smacc2/smacc_asynchronous_client_behavior.hpp>
#include "tbot/clients/cl_battery_manager/cl_battery_manager.hpp"

namespace tbot {
namespace cl_battery_manager {

class CbRechargeRequired : public smacc2::SmaccAsyncClientBehavior {
public:
  CbRechargeRequired() = default;
  ~CbRechargeRequired() override = default;

  void onEntry() override {
    ClBatteryManager* batteryClient;
    this->requiresClient(batteryClient);
    
    if (!batteryClient) {
      RCLCPP_ERROR(getLogger(), "Failed to get battery manager client");
      this->postSuccessEvent();
      return;
    }
    
    if (batteryClient->recharge_required()) {
      this->postSuccessEvent();
      return;
    }

    this->postFailureEvent();
  }
};
}
}