// Copyright 2021 MyName/MyCompany Inc.
// Copyright 2021 RobosoftAI Inc. (template)
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once
#include <memory>
#include <string>
#include "point_overload.hpp"
#include "smacc2/smacc.hpp"
#include <ros_timer_client/client_behaviors/cb_timer_countdown_once.hpp>
#include <nav2z_client/client_behaviors.hpp>
#include <nav2z_client/nav2z_client.hpp>
#include "clients/cl_ask_directions/client_behaviours/cb_ask_directions_subscriber_behaviour.hpp"
#include "clients/cl_battery_manager/client_behaviours/cb_recharge_required_behaviour.hpp"
#include "clients/cl_battery_manager/client_behaviours/cb_can_operate_behaviour.hpp"
#include "clients/cl_order_manager/client_behaviours/cb_has_next_order_behaviour.hpp"


// Import namespaces
using namespace tbot::cl_ask_directions;
using namespace tbot::cl_battery_manager;
using namespace tbot::cl_order_manager;
using namespace cl_nav2z;
using namespace smacc2::state_reactors;
using namespace cl_ros_timer;
using namespace smacc2;

//STATE REACTORS
#include <sr_all_events_go/sr_all_events_go.hpp>
using namespace smacc2::state_reactors;
using namespace smacc2::default_events;

// ORTHOGONALS
#include "tbot/orthogonals/or_timer.hpp"
#include "tbot/orthogonals/or_navigation.hpp"
#include "tbot/orthogonals/or_battery_manager.hpp"
#include "tbot/orthogonals/or_order_manager.hpp"

namespace tbot
{
// SMACC2 classes
using tbot::OrNavigation;
using tbot::OrTimer;
using tbot::OrBatteryManager;
using tbot::OrOrderManager;

// STATES
struct StStartup;
struct StQueue;
struct StNavigateToBase;
struct StAtBase;
struct StRecharge;
struct StBatteryDepleted;

// SUPERSTATE FORWARD DECLARATIONS
namespace SSProcessOrder {
    struct SsProcessOrder;
}

// STATE_MACHINE
struct Tbot : public smacc2::SmaccStateMachineBase<Tbot, StStartup>
{
    using SmaccStateMachineBase::SmaccStateMachineBase;
    
    void onInitialize() override
    {
        this->createOrthogonal<OrNavigation>();
        this->createOrthogonal<OrTimer>();
        this->createOrthogonal<OrBatteryManager>();
        this->createOrthogonal<OrOrderManager>();
    }
};
} // namespace tbot

// SUPERSTATES
#include "superstates/ss_process_order.hpp"

// STATES
#include "states/st_startup.hpp"
#include "states/st_queue.hpp"
#include "states/st_navigate_to_base.hpp"
#include "states/st_at_base.hpp"
#include "states/st_recharge.hpp"
#include "states/st_battery_depleted.hpp"