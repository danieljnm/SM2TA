#pragma once

#include "smacc2/smacc.hpp"

namespace tbot
{
  using namespace smacc2::default_events;
  // SMACC2 clases
  using smacc2::Transition;
  using smacc2::EvStateRequestFinish;
  using smacc2::EvCbSuccess;
  using smacc2::EvCbFailure;
  using smacc2::default_transition_tags::SUCCESS;

  using tbot::OrNavigation;

// STATE DECLARATION
struct StNavigateToBase : smacc2::SmaccState<StNavigateToBase, Tbot>
{
  using SmaccState::SmaccState;

  struct SrReadyToCharge;
  struct SrReadyToProcess;

  // TRANSITION TABLE - adjust as needed
  typedef boost::mpl::list<

    Transition<EvCbSuccess<CbNavigateGlobalPosition, OrNavigation>, StAtBase>

    >reactions;

  // STATE FUNCTIONS
  static void staticConfigure()
  {
    configure_orthogonal<OrNavigation, CbNavigateGlobalPosition>(1.0, 2.5, 0);
  }

  void runtimeConfigure()
  {
    RCLCPP_INFO(getLogger(), " Entering NavigateToBase");
  }

  void onEntry() 
  {
  }

  void onExit() 
  {
    RCLCPP_INFO(getLogger(), " On Exit!");
  }
};
}
