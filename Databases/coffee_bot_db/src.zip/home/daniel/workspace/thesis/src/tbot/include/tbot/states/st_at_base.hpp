#pragma once

#include "smacc2/smacc.hpp"

namespace tbot
{
  using namespace smacc2::default_events;
  // SMACC2 clases
  using smacc2::Transition;
  using smacc2::EvStateRequestFinish;
  using smacc2::EvCbSuccess;
  using smacc2::EvCbFailure;
  using smacc2::default_transition_tags::SUCCESS;

  using tbot::OrNavigation;
  using tbot::OrBatteryManager;

// STATE DECLARATION
struct StAtBase : smacc2::SmaccState<StAtBase, Tbot>
{
  using SmaccState::SmaccState;

  struct SrReadyToProcess;

  // TRANSITION TABLE - adjust as needed
  typedef boost::mpl::list<

    Transition<EvCbSuccess<CbRechargeRequired, OrBatteryManager>, StRecharge>,
    Transition<EvAllGo<SrAllEventsGo, SrReadyToProcess>, StQueue>

    >reactions;

  // STATE FUNCTIONS
  static void staticConfigure()
  {
    configure_orthogonal<OrBatteryManager, CbRechargeRequired>();
    configure_orthogonal<OrOrderManager, CbHasNextOrder>();

    static_createStateReactor<SrAllEventsGo, smacc2::state_reactors::EvAllGo<SrAllEventsGo, SrReadyToProcess>,
      mpl::list<
        EvCbFailure<CbRechargeRequired, OrBatteryManager>,
        EvCbSuccess<CbHasNextOrder, OrOrderManager>
      >>();
  }

  void runtimeConfigure()
  {
    RCLCPP_INFO(getLogger(), " Entering NavigateToBase");
  }

  void onEntry() 
  {
  }

  void onExit() 
  {
    RCLCPP_INFO(getLogger(), " On Exit!");
  }
};
}
