#pragma once
#include <memory>
#include <string>
#include "smacc2/smacc.hpp"

namespace tbot
{
namespace process_order_states
{
// STATE DECLARATION
template <typename SS>
struct StiNavigateToCoffeeMachine : smacc2::SmaccState<StiNavigateToCoffeeMachine<SS>, SS>
{
    typedef smacc2::SmaccState<StiNavigateToCoffeeMachine<SS>, SS> TSti;
    using typename TSti::context_type;
    using TSti::SmaccState;
    
    // TRANSITION TABLE
    typedef boost::mpl::list<

        Transition<EvCbSuccess<CbNavigateGlobalPosition, OrNavigation>, StiWaitForOrder<SS>>

    > reactions;
    
    // STATE FUNCTIONS
    static void staticConfigure()
    {
        TSti::template configure_orthogonal<OrNavigation, CbNavigateGlobalPosition>(2.0, 2.0, 0);
    }
    
    void runtimeConfigure() {}
};
}
}
