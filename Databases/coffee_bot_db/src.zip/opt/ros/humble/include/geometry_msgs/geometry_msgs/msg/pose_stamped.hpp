// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef GEOMETRY_MSGS__MSG__POSE_STAMPED_HPP_
#define GEOMETRY_MSGS__MSG__POSE_STAMPED_HPP_

#include "geometry_msgs/msg/detail/pose_stamped__struct.hpp"
#include "geometry_msgs/msg/detail/pose_stamped__builder.hpp"
#include "geometry_msgs/msg/detail/pose_stamped__traits.hpp"
#include "geometry_msgs/msg/detail/pose_stamped__type_support.hpp"

#endif  // GEOMETRY_MSGS__MSG__POSE_STAMPED_HPP_
