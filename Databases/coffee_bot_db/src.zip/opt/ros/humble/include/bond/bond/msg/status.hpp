// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef BOND__MSG__STATUS_HPP_
#define BOND__MSG__STATUS_HPP_

#include "bond/msg/detail/status__struct.hpp"
#include "bond/msg/detail/status__builder.hpp"
#include "bond/msg/detail/status__traits.hpp"
#include "bond/msg/detail/status__type_support.hpp"

#endif  // BOND__MSG__STATUS_HPP_
